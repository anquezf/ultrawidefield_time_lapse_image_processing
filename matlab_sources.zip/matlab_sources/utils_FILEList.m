function fileList=utils_FILEList(dirName,ext,opt)

% usage : dirName must have / at the end !!!
% ext (format) have to be writen 'tif' and not '.tif' !!!


% recursively Find all images files with extenstion 'ext'
%
% ***** input :
%		'dirName' : name of directory to screen ;
%		'ext'     : extension of the image files ; 
%		            !! use 'tif' and not '.tif' !!
%		'opt' : option recursif (opt='R'||'r') or not
% ***** output :
%		'fileList' : a List of file name ; cell array ; one line per file

% default opt='r' to be consistent with previuous verison
if nargin<3
  opt='R';
end % if

% *** Init ***
% Look at what's in the current directory
dirData = dir(dirName);
sizes=size(dirData);
% Find the index for directories
dirIndex = find([dirData.isdir]);
% some variables
fileList={};
dirList={};

% *** search in root directory ***
% Find and list with proper extension in the current directory
for f=1:sizes(1)
  if not(isempty(findstr(ext,dirData(f).name)))
    fileList=vertcat(fileList,dirData(f).name);	
  end %if
end %for
%# Prepend path to files
if ~isempty(fileList)
  fileList = cellfun(@(x) fullfile(dirName,x),fileList,'UniformOutput',false);  %# Prepend path to files
end

% *** treat sub-directories ***
if (opt=='R')||(opt=='r')
  % Find them
  for d=dirIndex
    if not(strcmp(dirData(d).name,'.'))&not(strcmp(dirData(d).name,'..'))
      dirList=vertcat(dirList,dirData(d).name);
    end
  end % for
  sizes=size(dirList);
  if not(sizes(1)==0)
    for d=1:sizes(1)
      dirname=cat(2,dirName,dirList{d});
      dirname=cat(2,dirname,'/');
      fileList=vertcat(fileList,utils_FILEList(dirname,ext));
    end % for d
  end % if
end % if

% get full path...
[Nfiles,crapint]=size(fileList);
for f=1:Nfiles
  fileList{f,1}=utils_GetFullPath(fileList{f,1});
end % for f


end % function

