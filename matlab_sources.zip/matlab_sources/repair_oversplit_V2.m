function [idxlist_modif,cellMLC_modif,cellBLC_modif,cellID_modif,idxlist_rmvd]=repair_oversplit_V2(im,sorted_celldata,sorted_cellboundLC,sorted_cellBF,sorted_cellmaskLC,Lmax,Nitemax,dpix_tol,mitoCONTRAST_TH1,deepTH,NL,NC)

% *** usefull variables
mask=zeros(NL,NC,'logical');
se2=strel('disk',2);



% *** params
Lmax_sq=power(Lmax,2);
dpix_tol_sq=power(dpix_tol,2);



% *** raw data

[Ncell,~]=size(sorted_celldata);
idxs=[1:Ncell]';

logiidx_cur=sorted_celldata(:,3)==im;
logiidx_prev=sorted_celldata(:,3)==(im-1);
%logiidx_next=sorted_celldata(:,3)==(im+1);

cur_scd=sorted_celldata(logiidx_cur,:);
prev_scd=sorted_celldata(logiidx_prev,:);
%next_scd=sorted_celldata(logiidx_next,:);

idxlist_cur=idxs(logiidx_cur,1);
idxlist_prev=idxs(logiidx_prev,1);
%idxlist_next=idxs(logiidx_next,1);



% ***********************
% *** find single_sisters
% exists at frame im
% but not at im-1
ss_scd_cand=[];
ss_cand_idxlist=[];
% *** find mother_sisters
% exists at frame im
% and also at im-1
ms_scd_cand=[];
ms_cand_idxlist=[];

[NN,~]=size(cur_scd);
for c=1:NN
  ID=cur_scd(c,12);
  logiidx=(prev_scd(:,12)==ID);
  if sum(logiidx)==0
    ss_scd_cand=cat(1,ss_scd_cand,cur_scd(c,:));
    ss_cand_idxlist=cat(1,ss_cand_idxlist,idxlist_cur(c,1));
  else
    ms_scd_cand=cat(1,ms_scd_cand,cur_scd(c,:));
    ms_cand_idxlist=cat(1,ms_cand_idxlist,idxlist_cur(c,1));
  end % if
end % for c



% ***********************************
% *** attribute mothers-sisters pairs

[Nss,~]=size(ss_scd_cand);
[Nms,~]=size(ms_scd_cand);

% LINKAGE :
cost=build_cost_sisters(single(ss_scd_cand),single(ms_scd_cand),single(Lmax),Nss,Nms);
attrib=seed_attrib_sisters(cost,single(Lmax),Nss);
[attrib,nit]=linkage_V10(cost,attrib,single(Lmax),Nitemax);

mothers_sisters=[];
sisters1=[];
sisters2=[];

% COMBINE :
ss_catched=[];
ss_lost=[];
N1=Nss+Nms;
N2=Nss+Nms;
% single sisters
for p=1:Nss
  if isempty(find(ss_catched==p))

    [L,~]=find(attrib(:,p)==single(1));
    if L==(N1+1)
      ss_lost=cat(1,ss_lost,ss_cand_idxlist(p,1));
    elseif (L>Nss)&&(L<(N1+1))
      motherIDX=ms_cand_idxlist(L-Nss,1);
      sisterIDX=ss_cand_idxlist(p,1);
      mothers_sisters=cat(1,mothers_sisters,[motherIDX,sisterIDX]);
      ss_catched=cat(1,ss_catched,p);
    elseif (L<(Nss+1))
      if isempty(find(ss_catched==L))
        sisters1=cat(1,sisters1,ss_cand_idxlist(p,:));
        sisters2=cat(1,sisters2,ss_cand_idxlist(L,:));
        ss_catched=cat(1,ss_catched,p,L);
      end % if isempty(ss_catched==L)
    end % if L==(N1+1)

  end % if isempty(ss_catched==p)
end % for p
% mother sisters
for p=(Nss+1):N1
    [L,~]=find(attrib(:,p)==single(1));
    if L<(Nss+1)&&(isempty(find(ss_catched==L)))
      motherIDX=ms_cand_idxlist(p-Nss,1);
      sisterCID=ss_cand_idxlist(L,1);
      mothers_sisters=cat(1,mothers_sisters,[motherIDX,sisterIDX]);
      ss_catched=cat(1,ss_catched,L);
    end % if L<(Nss+1)
end % for p



% ****************************
% *** measure boundary overlap

[NMS,~]=size(mothers_sisters);
OVlist=zeros(NMS,1);

for ms=1:NMS

  idxm=mothers_sisters(ms,1);
  idxs=mothers_sisters(ms,2);

  BLCm=double(sorted_cellboundLC{idxm,1});
  [Npix_m,~]=size(BLCm);
  BLCs=double(sorted_cellboundLC{idxs,1});

  ovtemp=0;
  for pix=1:Npix_m
    DD=power(BLCs(:,1)-BLCm(pix,1),2)+power(BLCs(:,2)-BLCm(pix,2),2);
    lo=DD<=dpix_tol_sq;
    if sum(lo)>0
      ovtemp=ovtemp+1;
    end %if
  end % for pix
  OVlist(ms,1)=ovtemp;

end % for ms



% ****************************
% *** select overlapping cells

logiidx=(OVlist>1);
mothers_sisters=mothers_sisters(logiidx,:);




% ***********************
% *** check mitotic cells

% criteria :
% C=sorted_cellBF(idx1_p,6)./sorted_cellBF(idx1_p,8)+sorted_cellBF(idx1_p,4)./sorted_cellBF(idx1_p,8);
% C>CTH -> mitotic
[NMS,~]=size(mothers_sisters);
ismitotic=zeros(NMS,1);

for ms=1:NMS

  idx1=mothers_sisters(ms,1);
  idx2=mothers_sisters(ms,2);

  % *** is it mitotic ?

  % BF contrast of mother at im-1
  CID1=sorted_celldata(idx1,12);
  lo_1=prev_scd(:,12)==CID1;
  idx1p=idxlist_prev(lo_1,1);
  CBF1_p=sorted_cellBF(idx1p,6)./sorted_cellBF(idx1p,8)+sorted_cellBF(idx1p,4)./sorted_cellBF(idx1p,8);
  % BF contrast of mother at im
  CBF1_c=sorted_cellBF(idx1,6)./sorted_cellBF(idx1,8)+sorted_cellBF(idx1,4)./sorted_cellBF(idx1,8);
  % BF contrast of sister
  CBF2=sorted_cellBF(idx2,6)./sorted_cellBF(idx2,8)+sorted_cellBF(idx2,4)./sorted_cellBF(idx2,8);

  if (CBF1_p>mitoCONTRAST_TH1)|(CBF1_c>mitoCONTRAST_TH1)|(CBF2>mitoCONTRAST_TH1)
    ismitotic(ms,1)=1;
  end
  
end % for ms



% ****************************
% *** select non-mitotic cells

logiidx=(ismitotic==0);
mothers_sisters=mothers_sisters(logiidx,:);
[NMS,~]=size(mothers_sisters);



% *************************
% *** detect over splitting

isoversplitted=zeros(NMS,1,'logical');
idxlist_modif=nan(NMS,1);
cellID_modif=nan(NMS,1);
cellBLC_modif=cell(NMS,1);
cellMLC_modif=cell(NMS,1);
idxlist_rmvd=nan(NMS,1);


for ms=1:NMS

  % *** raw data
  idxm=mothers_sisters(ms,1);
  idxs=mothers_sisters(ms,2);
  pm=sorted_celldata(idxm,10);
  ps=sorted_celldata(idxs,10);

  if pm==ps

    % *** create merged mask
    mask=zeros(NL,NC,'logical');
    MLCm=sorted_cellmaskLC{idxm,1};
    MLCs=sorted_cellmaskLC{idxs,1};
    [Npixm,~]=size(MLCm);
    [Npixs,~]=size(MLCs);
    for pix=1:Npixm mask(MLCm(pix,1),MLCm(pix,2))=1; end % for pix
    for pix=1:Npixs mask(MLCs(pix,1),MLCs(pix,2))=1; end % for pix
    mask=imfill(mask,'holes');

    % *** get boundaries
    B=bwboundaries(mask);
    [Nb,~]=size(B);
    if Nb>0
      % select biggest bound
      Npix_list=zeros(Nb,1);
      for b=1:Nb
        BBLC=B{b,1};
        [Nppix,~]=size(BBLC(:,1));
        Npix_list(b,1)=Nppix;
      end % for b
      [Npixmax,bsel]=max(Npix_list);
      BLCmerged=B{bsel,1};

      % *** measure deepness
      [dBxB,dBxC,~,~,~,~,~,~,~,~,~]=measure_max_boundary_deepness_V3(BLCmerged);
      if (dBxB/dBxC)<deepTH

        % *** smooth mask
        mask=imdilate(mask,se2);
        mask=imerode(mask,se2);
        % get boundaries
        B2=bwboundaries(mask);
        [Nb2,~]=size(B2);
        if Nb2>0
          if Nb2>1
            % select biggest bound
            Npix_list2=zeros(Nb2,1);
            for b2=1:Nb2
              BBLC2=B2{b2,1};
              [Nppix2,~]=size(BBLC2(:,1));
              Npix_list2(b2,1)=Nppix2;
            end % for b
            [Npixmax2,bsel2]=max(Npix_list2);
            BLCmerged2=B2{bsel2,1};
          else
            BLCmerged2=B2{1,1};
          end % if Nb2>1
          % get maskLC
          [Ll,Cl]=find(mask);

          % *** store oversplitted
          isoversplitted(ms,1)=1;
          if Npixs>Npixm
            idxlist_modif(ms,1)=idxs;
            idxlist_rmvd(ms,1)=idxm;
          else
            idxlist_modif(ms,1)=idxm;
            idxlist_rmvd(ms,1)=idxs;
          end % if Npixs>Npixm
          cellID_modif(ms,1)=sorted_celldata(idxm,12);
          cellBLC_modif{ms,1}=int16(BLCmerged2);
          cellMLC_modif{ms,1}=cat(2,uint16(Ll),uint16(Cl));
        end % if Nb2>0
        
      end % if (dBxB/dBxC)<deepTH_2
    end % if Nb>0

  end % if p1==p2

end % for ms



% **********************
% *** select oversplited

idxlist_modif=idxlist_modif(isoversplitted,1);
idxlist_rmvd=idxlist_rmvd(isoversplitted,1);
cellBLC_modif=cellBLC_modif(isoversplitted,1);
cellMLC_modif=cellMLC_modif(isoversplitted,1);
cellID_modif=cellID_modif(isoversplitted,1);

end % function


