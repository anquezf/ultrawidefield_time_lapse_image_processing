function bkg_foreg_avg_FLUO(ana_path,chanFluo,Npos,NL,NC,imoffset,flipUD,flipLR,im)


% outputs
cumu_BKG=zeros(NL,NC);
cumu_FOREG=zeros(NL,NC);
theimage=zeros(NL,NC);

im_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/','images_infos/',num2str(im,'%0.5d'),'/');
load(cat(2,im_ana_dir,'fileListF_pos.mat'),'fileListF_pos');

for pos=1:Npos

  load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/',num2str(pos-1,'%0.5d'),'/bkg_mask.mat'));
  load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/',num2str(pos-1,'%0.5d'),'/foreg_mask.mat'));

  % *** load raw data
  theimage=double(imread(fileListF_pos{pos,1}));
  % init_FLUO is preparing fileListF_pos with imdx and not lidx
  theimage=(theimage-imoffset);
  % flip ?
  if flipUD>0 theimage=flipud(theimage); end % if
  % flip ?
  if flipLR>0 theimage=fliplr(theimage); end % if

  cumu_BKG(bkg_mask)=cumu_BKG(bkg_mask)+theimage(bkg_mask);
  cumu_FOREG(foreg_mask)=cumu_FOREG(foreg_mask)+theimage(foreg_mask);

end % for pos

load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/','Nfound_BKG.mat'),'Nfound_BKG');
load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/','Nfound_FOREG.mat'),'Nfound_FOREG');

save(cat(2,im_ana_dir,'cumu_BKG.mat'),'cumu_BKG','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'cumu_FOREG.mat'),'cumu_FOREG','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'Nfound_BKG.mat'),'Nfound_BKG','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'Nfound_FOREG.mat'),'Nfound_FOREG','-v7.3','-nocompression');

end % function
