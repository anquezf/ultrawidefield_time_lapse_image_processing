function [mask_out,Nreg_out]=make_mask_check_empty(mask_in,Nreg_in,NL,NC)

mask_out=zeros(NL,NC);
logiidx=false(NL,NC);

Nreg_out=0;
for c=1:Nreg_in

  logiidx=(mask_in==c);
  if sum(logiidx(:)>0)
    Nreg_out=Nreg_out+1;
    mask_out(logiidx)=Nreg_out;
  end % if

end % for c

end % fucniton
