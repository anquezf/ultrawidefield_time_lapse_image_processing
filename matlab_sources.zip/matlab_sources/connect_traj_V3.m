function [enders_starters,NES]=connect_traj_V3(im,sorted_celldata,sorted_cellBF,mem,Lmax,Nitemax,mitoCONTRAST_TH1)


% *** params
Lmax_sq=power(Lmax,2);


% *** raw data

[Ncell,~]=size(sorted_celldata);
idxs=[1:Ncell]';

logiidx_cur=sorted_celldata(:,3)==im;
logiidx_before_im=sorted_celldata(:,3)<im;
logiidx_after_im=sorted_celldata(:,3)>im;
%
logiidx_in_next_range=(sorted_celldata(:,3)>im)&(sorted_celldata(:,3)<(im+2+mem));

cur_scd=sorted_celldata(logiidx_cur,:);
befim_scd=sorted_celldata(logiidx_before_im,:);
aftim_scd=sorted_celldata(logiidx_after_im,:);
%
INR_scd=sorted_celldata(logiidx_in_next_range,:);

idxlist_cur=idxs(logiidx_cur,1);
idxlist_befim=idxs(logiidx_before_im,1);
idxlist_aftim=idxs(logiidx_after_im,1);
%
idxlist_INR=idxs(logiidx_in_next_range,1);

% ***********************
% *** find enders
% exists at frame im
% exists before frame im
% but not at frame>im
%
%is not mitotic
enders_scd_cand=[];
enders_cand_idxlist=[];
[NN,~]=size(cur_scd);
for c=1:NN
  ID=cur_scd(c,12);
  logiidx=(befim_scd(:,12)==ID);
  if sum(logiidx)>0 % is find before im
    logiidx2=(aftim_scd(:,12)==ID);
    if sum(logiidx2)==0
      idx1=idxlist_cur(c,1);
      % is mitotic ?
      CBF=sorted_cellBF(idx1,6)./sorted_cellBF(idx1,8)+sorted_cellBF(idx1,4)./sorted_cellBF(idx1,8);
      if CBF<mitoCONTRAST_TH1
        enders_scd_cand=cat(1,enders_scd_cand,cur_scd(c,:));
        enders_cand_idxlist=cat(1,enders_cand_idxlist,idx1);
      end % if (BF/stdBF)<round_Nsig
    end % if sum(logiidx2)>0
  end % if sum(logiidx)>0
end % for c

% *** find starters
% exists between frame im+1 and im+1+mem
% do not exist at frame im
% do not exist before its frame_index in next range
%
% is not mitotic
starters_scd_cand=[];
starters_cand_idxlist=[];
[NN,~]=size(INR_scd);
for c=1:NN
  ID=INR_scd(c,12);
  logiidx=(cur_scd(:,12)==ID);
  if sum(logiidx)==0
    frame_idx=INR_scd(c,3);
    logiidx2=(sorted_celldata(:,3)<frame_idx)&(sorted_celldata(:,12)==ID);
    if sum(logiidx2)==0
      idx1=idxlist_INR(c,1);
      % is mitotic ?
      CBF=sorted_cellBF(idx1,6)./sorted_cellBF(idx1,8)+sorted_cellBF(idx1,4)./sorted_cellBF(idx1,8);
      if CBF<mitoCONTRAST_TH1
        starters_scd_cand=cat(1,starters_scd_cand,INR_scd(c,:));
        starters_cand_idxlist=cat(1,starters_cand_idxlist,idx1);
      end % if (BF/stdBF)<round_Nsig
    end % if sum(logiidx)==0
  end % if sum(logiidx2)==0
end % for c




% ***********************************
% *** attribute mothers-sisters pairs

[Nsta,~]=size(starters_scd_cand);
[Nend,~]=size(enders_scd_cand);

enders_starters=[];

if (Nsta>0)&&(Nend>0)

  % LINKAGE :
  cost=build_cost_V5(single(starters_scd_cand),single(enders_scd_cand),single(Lmax),0,0,0);
  attrib=seed_attrib_V3(cost,single(Lmax));
  [attrib,nit]=linkage_V10(cost,attrib,single(Lmax),Nitemax);



  % COMBINE :
  e_catched=[];
  % single sisters
  for p=1:Nend
    if isempty(find(e_catched==p))

      [L,~]=find(attrib(:,p)==single(1));
      if L<(Nsta+1)
        starterIDX=starters_cand_idxlist(L,1);
        enderIDX=enders_cand_idxlist(p,1);
        enders_starters=cat(1,enders_starters,[enderIDX,starterIDX]);
        e_catched=cat(1,e_catched,p);
      end % if

    end % if isempty(find(e_catched==p))
  end % for p

end % if (Nsta>0)&&(Nend>0)
      
[NES,~]=size(enders_starters);


end % function


