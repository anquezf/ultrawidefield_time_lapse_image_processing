function remove_duplicates_V4(ana_path,im,Dborder,Lmax,SOVTH)

Lmax_sq=power(Lmax,2);

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% *** load data

load(cat(2,ana_path,'Npos.mat'),'Npos');
load(cat(2,ana_path,'pos_UDLR.mat'),'pos_UDLR');
% pos_UDLR return pos idx and not p ; p=pos-1=idx-1

load(cat(2,ana_path,'XYlist.mat'),'XYlist');
load(cat(2,ana_path,'pixsize.mat'),'pixsize');
load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

load(cat(2,ana_path,'flipUD.mat'),'flipUD');
load(cat(2,ana_path,'flipLR.mat'),'flipLR');

Lc_abs=NL/2;
Cc_abs=NC/2;

WX=(NC*pixsize)/2;
WY=(NL*pixsize)/2;

% *** INPUTS
dup_ana_dir=cat(2,ana_path,'RMVDUP/',num2str(im,'%0.5d'),'/');

save(cat(2,dup_ana_dir,'Dborder.mat'),'Dborder','-v7.3','-nocompression');
save(cat(2,dup_ana_dir,'Lmax.mat'),'Lmax','-v7.3','-nocompression');
save(cat(2,dup_ana_dir,'SOVTH.mat'),'SOVTH','-v7.3','-nocompression');


load(cat(2,dup_ana_dir,'short_celldata.mat'),'short_celldata');
load(cat(2,dup_ana_dir,'short_cellmaskLC.mat'),'short_cellmaskLC');
load(cat(2,dup_ana_dir,'short_cellboundLC.mat'),'short_cellboundLC');
load(cat(2,dup_ana_dir,'short_idxlist.mat'),'short_idxlist');


% *** OUTPUTS

short_celldata_modified=[];
short_idx_rmvd=[];
short_idx_modified=[];


for pos=1:Npos

  Xc1=XYlist(pos,1);
  Yc1=XYlist(pos,2);

  % **************************************************
  % *** process up
  % pos_UDLR return pos idx and not p ; p=pos-1=idx-1
  posup=pos_UDLR(pos,1);

  if ~(isnan(posup))

    Xc2=XYlist(posup,1);
    Yc2=XYlist(posup,2);

    % find up cells for pos mid
    logiidx_up1=(short_celldata(:,10)==(pos-1))&((short_celldata(:,2)-Yc1)>(WY-Dborder));
    % find lower cells for pos up
    % pos_UDLR return pos idx and not p ; p=pos-1=idx-1
    logiidx_up2=(short_celldata(:,10)==(posup-1))&((short_celldata(:,2)-Yc2)<(-(WY-Dborder)));

    N1=sum(logiidx_up1(:)); N2=sum(logiidx_up2(:));
    srcd1=short_celldata(logiidx_up1,:);
    srcd2=short_celldata(logiidx_up2,:);
    rmlc1=short_cellmaskLC(logiidx_up1,:);
    rmlc2=short_cellmaskLC(logiidx_up2,:);
    rblc1=short_cellboundLC(logiidx_up1,:);
    rblc2=short_cellboundLC(logiidx_up2,:);
    idx1=short_idxlist(logiidx_up1,1);
    idx2=short_idxlist(logiidx_up2,1);

    for c1=1:N1
      for c2=1:N2

        DD=power(srcd1(c1,1)-srcd2(c2,1),2)+power(srcd1(c1,2)-srcd2(c2,2),2);
	if DD<Lmax_sq

	  %check overlap
          % get maskLC; boundLC
	  MLC1=rmlc1{c1,1};

          BLC1=rblc1{c1,1};
          
          [Npts1,~]=size(MLC1);

	  MLC2=rmlc2{c2,1};

          [Npts2,~]=size(MLC2);

          OVpix=measure_cells_overlap_V3(BLC1,MLC1,Xc1,Yc1,MLC2,Xc2,Yc2,Lc_abs,Cc_abs,pixsize);

          if OVpix>0
            if Npts1<Npts2
              if (OVpix/Npts1)>SOVTH
	        short_idx_rmvd=cat(1,short_idx_rmvd,idx1(c1,1));
	        lologiidx=(idx2(c2,1)==short_idx_modified);
	        if sum(lologiidx)==0
                   srcdm=cat(2,srcd2(c2,:),srcd1(c1,10));
	           short_celldata_modified=cat(1,short_celldata_modified,srcdm);
	           short_idx_modified=cat(1,short_idx_modified,idx2(c2,1));
	        end % if sum
	      end % if s/N>SOVTH
	    else
              if (OVpix/Npts2)>SOVTH
	        short_idx_rmvd=cat(1,short_idx_rmvd,idx2(c2,1));
	        lologiidx=(idx1(c1,1)==short_idx_modified);
	        if sum(lologiidx)==0
                   srcdm=cat(2,srcd1(c1,:),srcd2(c2,10));
	           short_celldata_modified=cat(1,short_celldata_modified,srcdm);
	           short_idx_modified=cat(1,short_idx_modified,idx1(c1,1));
	        end % if sum
	      end % if s/N>SOVTH
            end % if Npts1>Npts2
          end % if OVpix>0

	end % if DD<Lmax_sq

      end % for c2
    end % for c1

  end % if ~isnan


  % **************************************************
  % *** process left
  % pos_UDLR return pos idx and not p ; p=pos-1=idx-1
  posup=pos_UDLR(pos,3);

  if ~(isnan(posup))

    Xc2=XYlist(posup,1);
    Yc2=XYlist(posup,2);

    % find left cells for pos mid
    logiidx_up1=(short_celldata(:,10)==(pos-1))&((short_celldata(:,1)-Xc1)<(-(WX-Dborder)));
    % find right cells for pos left
    % pos_UDLR return pos idx and not p ; p=pos-1=idx-1
    logiidx_up2=(short_celldata(:,10)==(posup-1))&((short_celldata(:,1)-Xc2)>(WX-Dborder));

    N1=sum(logiidx_up1(:)); N2=sum(logiidx_up2(:));
    srcd1=short_celldata(logiidx_up1,:);
    srcd2=short_celldata(logiidx_up2,:);
    rmlc1=short_cellmaskLC(logiidx_up1,:);
    rmlc2=short_cellmaskLC(logiidx_up2,:);
    rblc1=short_cellboundLC(logiidx_up1,:);
    rblc2=short_cellboundLC(logiidx_up2,:);
    idx1=short_idxlist(logiidx_up1,1);
    idx2=short_idxlist(logiidx_up2,1);

    for c1=1:N1
      for c2=1:N2

        DD=power(srcd1(c1,1)-srcd2(c2,1),2)+power(srcd1(c1,2)-srcd2(c2,2),2);
	if DD<Lmax_sq

	  %check overlap

          % get maskLC; boundLC
	  MLC1=rmlc1{c1,1};

          BLC1=rblc1{c1,1};
          
          [Npts1,~]=size(MLC1);

	  MLC2=rmlc2{c2,1};

          [Npts2,~]=size(MLC2);

          OVpix=measure_cells_overlap_V3(BLC1,MLC1,Xc1,Yc1,MLC2,Xc2,Yc2,Lc_abs,Cc_abs,pixsize);

          if OVpix>0
            if Npts1<Npts2
              if (OVpix/Npts1)>SOVTH
	        short_idx_rmvd=cat(1,short_idx_rmvd,idx1(c1,1));
	        lologiidx=(idx2(c2,1)==short_idx_modified);
	        if sum(lologiidx)==0
                   srcdm=cat(2,srcd2(c2,:),srcd1(c1,10));
	           short_celldata_modified=cat(1,short_celldata_modified,srcdm);
	           short_idx_modified=cat(1,short_idx_modified,idx2(c2,1));
	        end % if sum
	      end % if s/N>SOVTH
	    else
              if (OVpix/Npts2)>SOVTH
	        short_idx_rmvd=cat(1,short_idx_rmvd,idx2(c2,1));
	        lologiidx=(idx1(c1,1)==short_idx_modified);
	        if sum(lologiidx)==0
                   srcdm=cat(2,srcd1(c1,:),srcd2(c2,10));
	           short_celldata_modified=cat(1,short_celldata_modified,srcdm);
	           short_idx_modified=cat(1,short_idx_modified,idx1(c1,1));
	        end % if sum
	      end % if s/N>SOVTH
            end % if Npts1>Npts2
          end % if OVpix>0

	end % if DD<Lmax_sq

      end % for c2
    end % for c1

  end % if ~isnan


end % for pos

save(cat(2,dup_ana_dir,'short_celldata_modified.mat'),'short_celldata_modified','-v7.3','-nocompression');
save(cat(2,dup_ana_dir,'short_idx_rmvd.mat'),'short_idx_rmvd','-v7.3','-nocompression');
save(cat(2,dup_ana_dir,'short_idx_modified.mat'),'short_idx_modified','-v7.3','-nocompression');


end % funciton





