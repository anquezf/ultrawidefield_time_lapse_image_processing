function [CC,AFP,IFP,ATP,ITP]=optimize_shape_params_bound(H2D,edgesI,edgesA,IBS,ABS,CC0,AFP0,IFP0)

Ntot=sum(H2D(:));
[Imesh,Amesh]=meshgrid(edgesI-IBS/2,edgesA-ABS/2);

% ********************
% *** optmize CC value
% ********************

Nd=30;
CCmin=CC0/2;
CCmax=2*CC0;
deltaC=(CCmax-CCmin)/Nd;
SIGB_sq=zeros(Nd+1,1);
for dc=1:(Nd+1)
  ATH=(CCmin+(dc-1)*deltaC)./(Imesh-IFP0)+AFP0;
  logiFP=Amesh<ATH;
  logiTP=~logiFP;
  wfp=sum(H2D(logiFP))/Ntot;
  wtp=sum(H2D(logiTP))/Ntot;
  afp=sum(H2D(logiFP).*Amesh(logiFP))/Ntot;
  ifp=sum(H2D(logiFP).*Imesh(logiFP))/Ntot;
  atp=sum(H2D(logiTP).*Amesh(logiTP))/Ntot;
  itp=sum(H2D(logiTP).*Imesh(logiTP))/Ntot;
  SIGB_sq(dc,1)=wfp*wtp*(power(afp-atp,2)+power(ifp-itp,2));
end % for dc
[~,dcoptim]=max(SIGB_sq);
CC=CCmin+(dcoptim-1)*deltaC;



% ************************
% re-estimate AFP,ATP,IFP,ITP
% ************************
[Imesh,Amesh]=meshgrid(edgesI-IBS/2,edgesA-ABS/2);
ATH=CC./(Imesh-IFP0)+AFP0;
logiFP=Amesh<ATH;
logiTP=~logiFP;

Ntot=sum(H2D(:));
AFP=sum(H2D(logiFP).*Amesh(logiFP))/Ntot;
IFP=sum(H2D(logiFP).*Imesh(logiFP))/Ntot;
ATP=sum(H2D(logiTP).*Amesh(logiTP))/Ntot;
ITP=sum(H2D(logiTP).*Imesh(logiTP))/Ntot;


Nd=30;
CCmin=CC/2;
CCmax=2*CC;
deltaC=(CCmax-CCmin)/Nd;
SIGB_sq=zeros(Nd+1,1);
for dc=1:(Nd+1)
  ATH=(CCmin+(dc-1)*deltaC)./(Imesh-IFP)+AFP;
  logiFP=Amesh<ATH;
  logiTP=~logiFP;
  wfp=sum(H2D(logiFP))/Ntot;
  wtp=sum(H2D(logiTP))/Ntot;
  afp=sum(H2D(logiFP).*Amesh(logiFP))/Ntot;
  ifp=sum(H2D(logiFP).*Imesh(logiFP))/Ntot;
  atp=sum(H2D(logiTP).*Amesh(logiTP))/Ntot;
  itp=sum(H2D(logiTP).*Imesh(logiTP))/Ntot;
  SIGB_sq(dc,1)=wfp*wtp*(power(afp-atp,2)+power(ifp-itp,2));
end % for dc
[~,dcoptim]=max(SIGB_sq);
CC=CCmin+(dcoptim-1)*deltaC;


% ************************
% re-estimate AFP,ATP,IFP,ITP
% ************************
[Imesh,Amesh]=meshgrid(edgesI-IBS/2,edgesA-ABS/2);
ATH=CC./(Imesh-IFP)+AFP;
logiFP=Amesh<ATH;
logiTP=~logiFP;

Ntot=sum(H2D(:));
AFP=sum(H2D(logiFP).*Amesh(logiFP))/Ntot;
IFP=sum(H2D(logiFP).*Imesh(logiFP))/Ntot;
ATP=sum(H2D(logiTP).*Amesh(logiTP))/Ntot;
ITP=sum(H2D(logiTP).*Imesh(logiTP))/Ntot;

end % function
