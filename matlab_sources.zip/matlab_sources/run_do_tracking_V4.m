function run_do_tracking_V4(ana_path,NBMAX_str)

fprintf('RUN tracking...\n')

warning off

tstart=now;

% *** inputs
[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% load
NBMAX=str2double(NBMAX_str);

load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

POOLOBJ=parpool('local',NBMAX,'IdleTimeout',360);

parfor im=(im_start+1):im_stop

  do_tracking_V3(ana_path,im);

end % for pos

delete(POOLOBJ);

fprintf('tracking : DONE ! \n')
fprintf('\n');

exit(0)

end % function
