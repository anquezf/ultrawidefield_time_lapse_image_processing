function combine_NUC_bkg_foreg_V2(ana_path,im)

save_dir=cat(2,ana_path,'NUC_BKG_FOREG/',num2str(im,'%05d'),'/');
mkdir(save_dir);

load(cat(2,ana_path,'Npos.mat'),'Npos');
load(cat(2,ana_path,'imoffset.mat'),'imoffset');
load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

bkg_mask=zeros(NL,NC,'logical');
foreg_mask=zeros(NL,NC,'logical');

cumu_BKG=zeros(NL,NC);
cumu_FOREG=zeros(NL,NC);

Nfound_BKG=zeros(NL,NC);
Nfound_FOREG=zeros(NL,NC);

for pos=1:Npos

  bkg_mask_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/MASK_NUC/bkg_masks/');
  foreg_mask_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/MASK_NUC/foreg_masks/');
  load(cat(2,bkg_mask_ana_dir,'mask_im',num2str(im,'%05d'),'.mat'),'bkg_mask');
  load(cat(2,foreg_mask_ana_dir,'mask_im',num2str(im,'%05d'),'.mat'),'foreg_mask');

  pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
  load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');
  load(cat(2,pos_ana_dir,'fileListN.mat'),'fileListN');

  % *** find idx
  idx=imidx_2_lidx(im,1);
  % *** load raw data
  theimage=double(imread(fileListN{idx,1}));
  theimage=(theimage-imoffset);

  cumu_BKG(bkg_mask)=cumu_BKG(bkg_mask)+theimage(bkg_mask);
  cumu_FOREG(foreg_mask)=cumu_FOREG(foreg_mask)+theimage(foreg_mask);
  Nfound_BKG(bkg_mask)=Nfound_BKG(bkg_mask)+1;
  Nfound_FOREG(foreg_mask)=Nfound_FOREG(foreg_mask)+1;

end % for pos

save(cat(2,save_dir,'cumu_BKG.mat'),'cumu_BKG','-v7.3','-nocompression');
save(cat(2,save_dir,'cumu_FOREG.mat'),'cumu_FOREG','-v7.3','-nocompression');
save(cat(2,save_dir,'Nfound_BKG.mat'),'Nfound_BKG','-v7.3','-nocompression');
save(cat(2,save_dir,'Nfound_FOREG.mat'),'Nfound_FOREG','-v7.3','-nocompression');

end % function

