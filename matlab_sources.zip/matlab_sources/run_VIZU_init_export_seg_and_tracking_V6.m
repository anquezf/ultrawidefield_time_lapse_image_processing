function run_VIZU_init_export_seg_and_tracking_V6(ana_path,NBMAX_str)

fprintf('\n');
fprintf('\n');
fprintf('\n');

fprintf('************************\n');
fprintf('*** Initialze Export ***\n');
fprintf('************************\n');
fprintf('\n');


warning off
vizu_version='V6';

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

NBMAX=str2double(NBMAX_str);
POOLOBJ=parpool('local',NBMAX);


% *** display parameters
% **********************

% *** size of display at full width
dNL_max=1024;
dNC_max=1440;

NMAG=5;
MAG_list=[1,2,4,8,16];

bit_depth=8;

fprintf('\n');
fprintf('*** Prepare Export ***\n');



fprintf('Load data ...');

% *** load expe parameters
% ************************
Npos=0;
load(cat(2,ana_path,'Npos.mat'));
pixsize=0;
load(cat(2,ana_path,'pixsize.mat'));

load(cat(2,ana_path,'NL.mat'));
load(cat(2,ana_path,'NC.mat'));

load(cat(2,ana_path,'deltaXpos.mat'));
load(cat(2,ana_path,'deltaYpos.mat'));

load(cat(2,ana_path,'XYlist.mat'));

im_start=0; im_stop=0;
load(cat(2,ana_path,'im_start.mat'));
load(cat(2,ana_path,'im_stop.mat'));

WX=NC*pixsize;
WY=NL*pixsize;

pWX=WX+deltaXpos;
pWY=WY+deltaYpos;

fprintf('DONE !\n');

% *** arrange panels
% ******************

fprintf('Arrange Panels ...');

% *** make the grids
[posGRID,NposX_tot,NposY_tot]=get_posGRID_V2(Npos,XYlist,deltaXpos,deltaYpos,WX,WY);

% *** find display sizes
if NposY_tot>=NposX_tot
  dNL=dNL_max;
  dNC=round(((NposX_tot*WX+deltaXpos)/(NposY_tot*WY+deltaYpos))*dNL);
else
  dNC=dNC_max;
  dNL=round(((NposY_tot*WY+deltaYpos)/(NposX_tot*WX+deltaXpos))*dNC);
end

% *** scales/binnings, Npanels , panel_sizes

% number of panels for each MAG
NpanelX_list=zeros(1,NMAG);
NpanelY_list=zeros(1,NMAG);
for m=1:NMAG
  MAG=MAG_list(1,m);
  NpanelX_list(1,m)=round(NposX_tot/MAG);
  NpanelY_list(1,m)=round(NposY_tot/MAG);
end % for m
  
% number panel pixels for each MAG
pNC_list=zeros(1,NMAG);
pNL_list=zeros(1,NMAG);
for m=1:NMAG
  NpanelX=NpanelX_list(1,m);
  NpanelY=NpanelY_list(1,m);
  pNC_list(1,m)=floor(dNC/NpanelX);
  pNL_list(1,m)=floor(dNL/NpanelY);
end % for m

% number of BLC points to skip
deltaX_pix=deltaXpos/pixsize;
deltaY_pix=deltaYpos/pixsize;

blctoskip_list=zeros(1,NMAG);
for m=1:NMAG
  if NposY_tot>=NposX_tot
    blctoskip_list(1,m)=floor((NL+deltaY_pix)/pNL_list(1,m));
  else
    blctoskip_list(1,m)=floor((NC+deltaX_pix)/pNC_list(1,m));
  end % if
end % for

fprintf('DONE !\n');

% *** build grids
% ***************

fprintf('build grids ...');

Xgrid=zeros(NposY_tot,NposX_tot);
Ygrid=zeros(NposY_tot,NposX_tot);
Xmingrid=zeros(NposY_tot,NposX_tot);
Xmaxgrid=zeros(NposY_tot,NposX_tot);
Ymingrid=zeros(NposY_tot,NposX_tot);
Ymaxgrid=zeros(NposY_tot,NposX_tot);

for posX=1:NposX_tot
  for posY=1:NposY_tot
    pos=posGRID(posY,posX);
    if ~isnan(pos)
      Xgrid(posY,posX)=XYlist(pos,1);
      Ygrid(posY,posX)=XYlist(pos,2);
      Xmingrid(posY,posX)=XYlist(pos,1)-WX/2-deltaXpos;
      Xmaxgrid(posY,posX)=XYlist(pos,1)+WX/2;
      Ymingrid(posY,posX)=XYlist(pos,2)-WY/2-deltaYpos;
      Ymaxgrid(posY,posX)=XYlist(pos,2)+WY/2;
    end % if
  end %for posY
end % for posX

fprintf('DONE !\n');

% *** save data
% *************

fprintf('save data ...');

startIndex = regexp(ana_path,'/');
[~,Nsi]=size(startIndex);
[~,Nchar]=size(ana_path);
if startIndex(1,Nsi)==Nchar
  idx=startIndex(1,Nsi-1)+1;
  motif=ana_path(1,idx:(Nchar-1));
else
  idx=startIndex(1,Nsi)+1;
  motif=ana_path(1,idx:(Nchar-1));
end

save_path=cat(2,ana_path,'VIZU_',vizu_version,'_',motif,'/');
%save_path=cat(2,'VIZU_',vizu_version,'_',motif,'/');

mkdir(save_path)

save(cat(2,save_path,'dNL.mat'),'dNL','-v7.3','-nocompression');
save(cat(2,save_path,'dNC.mat'),'dNC','-v7.3','-nocompression');

save(cat(2,save_path,'im_start.mat'),'im_start','-v7.3','-nocompression');
save(cat(2,save_path,'im_stop.mat'),'im_stop','-v7.3','-nocompression');

save(cat(2,save_path,'NposX_tot.mat'),'NposX_tot','-v7.3','-nocompression');
save(cat(2,save_path,'NposY_tot.mat'),'NposY_tot','-v7.3','-nocompression');

save(cat(2,save_path,'NMAG.mat'),'NMAG','-v7.3','-nocompression');
save(cat(2,save_path,'MAG_list.mat'),'MAG_list','-v7.3','-nocompression');

save(cat(2,save_path,'bit_depth'),'bit_depth','-v7.3','-nocompression');

save(cat(2,save_path,'NpanelX_list.mat'),'NpanelX_list','-v7.3','-nocompression');
save(cat(2,save_path,'NpanelY_list.mat'),'NpanelY_list','-v7.3','-nocompression');
save(cat(2,save_path,'pNC_list.mat'),'pNC_list','-v7.3','-nocompression');
save(cat(2,save_path,'pNL_list.mat'),'pNL_list','-v7.3','-nocompression');

save(cat(2,save_path,'blctoskip_list.mat'),'blctoskip_list','-v7.3','-nocompression');

save(cat(2,save_path,'posGRID.mat'),'posGRID','-v7.3','-nocompression');

save(cat(2,save_path,'Xgrid.mat'),'Xgrid','-v7.3','-nocompression');
save(cat(2,save_path,'Ygrid.mat'),'Ygrid','-v7.3','-nocompression');
save(cat(2,save_path,'Xmingrid.mat'),'Xmingrid','-v7.3','-nocompression');
save(cat(2,save_path,'Ymingrid.mat'),'Ymingrid','-v7.3','-nocompression');
save(cat(2,save_path,'Xmaxgrid.mat'),'Xmaxgrid','-v7.3','-nocompression');
save(cat(2,save_path,'Ymaxgrid.mat'),'Ymaxgrid','-v7.3','-nocompression');

save(cat(2,save_path,'deltaXpos.mat'),'deltaXpos','-v7.3','-nocompression');
save(cat(2,save_path,'deltaYpos.mat'),'deltaYpos','-v7.3','-nocompression');

save(cat(2,save_path,'pixsize.mat'),'pixsize','-v7.3','-nocompression');

save(cat(2,save_path,'pWX.mat'),'pWX','-v7.3','-nocompression');
save(cat(2,save_path,'pWY.mat'),'pWY','-v7.3','-nocompression');

fprintf('DONE !\n');

fprintf('\n');
fprintf('*** Export Cell Nuc Seg ***\n');


% *** prepare mask data
% *********************

% *** load data
fprintf('load raw data ...');

load(cat(2,ana_path,'im_start.mat'));
load(cat(2,ana_path,'im_stop.mat'));

sorted_celldata=[];
load(cat(2,ana_path,'combined_data/sorted_celldata.mat'));
[Ncell,~]=size(sorted_celldata);
sorted_cellboundLC={};
load(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'));

fprintf(' DONE !\n');


fprintf('save data ...');

% *** save data
save(cat(2,save_path,'sorted_celldata.mat'),'sorted_celldata','-v7.3','-nocompression');

fprintf(' DONE !\n');

fprintf('prepare directories ...');

% ** path
mkdir(cat(2,save_path,'nuc_masks'));

% *** prepare dirs
parfor pos=1:Npos
  mkdir(cat(2,save_path,'nuc_masks/',num2str(pos),'/'));
  for im=im_start:im_stop
    mkdir(cat(2,save_path,'nuc_masks/',num2str(pos),'/',num2str(im),'/'));
    for m=1:NMAG
      MAG=MAG_list(1,m);
      mkdir(cat(2,save_path,'nuc_masks/',num2str(pos),'/',num2str(im),'/',num2str(MAG),'/'));
    end % for m
  end % for im
end % for pos

fprintf('DONE !\n');


% *** build colormap
% ******************
fprintf('build masks colormap ...');

std_cmap=parula(100)*0.5+0.5;

max_cid=max(sorted_celldata(:,12));
mask_cmap=zeros(max_cid,3);
ll=zeros(Ncell,1,'logical');
for pos=1:Npos
  ll=(sorted_celldata(:,10)==(pos-1))|(sorted_celldata(:,11)==(pos-1));
  cids=unique(sorted_celldata(ll,12));
  [NN,~]=size(cids);
  cmap_idx=randi(100,NN,1);
  mask_cmap(cids,:)=std_cmap(cmap_idx,:);
end % for pos
mask_cmap=single(mask_cmap);
save(cat(2,save_path,'mask_cmap.mat'),'mask_cmap','-v7.3','-nocompression');

fprintf('DONE !\n')


% *** save mask data
% *********************
fprintf('save masks ...');

Lc_abs=NL/2;
Cc_abs=NC/2;
parfor im=im_start:im_stop
%parfor im=im_start:15
  export_nuc_SEG_V6(save_path,NposX_tot,NposY_tot,sorted_celldata,sorted_cellboundLC,pixsize,Lc_abs,Cc_abs,posGRID,Xgrid,Ygrid,NMAG,MAG_list,blctoskip_list,im);
end % parfor

fprintf('DONE !\n')



fprintf('\n');
fprintf('\n');
fprintf('\n');
delete(POOLOBJ);
fprintf('*** Export INIT DONE ! ***\n');





