function preproc_foreg_histo_FLUO(ana_path,chanFluo,NL,NC,imoffset,flipUD,flipLR,FF_bkg,b,iedges,Npos,im);


% outputs
theimage=zeros(NL,NC);
[Npts,~]=size(iedges);

histo_FLUO=zeros(Npts,1);


im_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/','images_infos/',num2str(im,'%0.5d'),'/');
load(cat(2,im_ana_dir,'fileListF_pos.mat'),'fileListF_pos');

for pos=1:Npos

  load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/',num2str(pos-1,'%0.5d'),'/foreg_mask.mat'));

  % *** load raw data
  theimage=double(imread(fileListF_pos{pos,1}));
  % init_FLUO is preparing fileListF_pos with imdx and not lidx
  theimage=(theimage-imoffset);
  % flip ?
  if flipUD>0 theimage=flipud(theimage); end % if
  % flip ?
  if flipLR>0 theimage=fliplr(theimage); end % if

  theimage=theimage-b*FF_bkg;

  n=(histc(theimage(:),iedges));
  histo_FLUO=histo_FLUO+n;

end % for pos

save(cat(2,im_ana_dir,'histo_FLUO.mat'),'histo_FLUO','-v7.3','-nocompression');

end % function
