function process_BF_V4(ana_path,pos)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'Nsig_BF.mat'),'Nsig_BF');

load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

load(cat(2,ana_path,'flipUD.mat'),'flipUD');
load(cat(2,ana_path,'flipLR.mat'),'flipLR');
load(cat(2,ana_path,'imoffset.mat'));

load(cat(2,ana_path,'NL.mat'));
load(cat(2,ana_path,'NC.mat'));

theimage=zeros(NL,NC);
maskBF=zeros(NL,NC);
[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);


load(cat(2,ana_path,'pixsize.mat'));
load(cat(2,ana_path,'fW2.mat'));
radius_sq=power(fW2/pixsize,2);

% load data
pos_ana_dir=cat(2,ana_path,'BFproc/',num2str(pos-1,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'short_celldata.mat'),'short_celldata');

pos_ana_dir=cat(2,ana_path,'BFbkg_estimate/POSITIONS/',num2str(pos-1,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'fileListBF.mat'),'fileListBF');
load(cat(2,pos_ana_dir,'mu_bf_vs_im.mat'),'mu_bf_vs_im');
load(cat(2,pos_ana_dir,'sig_bf_vs_im.mat'),'sig_bf_vs_im');

pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');



[Ncell,~]=size(short_celldata);
short_cellBF=zeros(Ncell,8);

logiidx=zeros(Ncell,1,'logical');
idxs=[1:Ncell]';

for im=im_start:im_stop

  ll=imidx_2_lidx(im,1);

  % load BFavg
  im_ana_dir=cat(2,ana_path,'BFbkg_estimate/IMAGES/',num2str(im,'%05d'),'/');
  load(cat(2,im_ana_dir,'BFrawAVG.mat'),'BFrawAVG');

  % *** load raw data
  theimage=double(imread(fileListBF{ll,1}));
  theimage=(theimage-imoffset)-BFrawAVG;
  % flip ?
  if flipUD>0 theimage=flipud(theimage); end % if
  % flip ?
  if flipLR>0 theimage=fliplr(theimage); end % if

  % *** select cells
  logiidx=short_celldata(:,3)==im;
  NN=sum(logiidx);
  idxlist=idxs(logiidx,1);


  if NN>0
    % maskBF
    maskBF=make_mask_BF_V2(short_celldata(logiidx,:),NN,NL,NC,Lmesh,Cmesh,radius_sq);

    % Bf histo
    mu0=mu_bf_vs_im(1,im);
    sig0=sig_bf_vs_im(1,im);
    lim_mini=mu0-Nsig_BF*sig0;
    lim_maxi=mu0+Nsig_BF*sig0;

    % process cells 
    for c=1:NN

      idx=idxlist(c,1);

      [Ll,Cl]=find(maskBF==c);
      [Npix,~]=size(Ll);
      BFdata=zeros(Npix,1);
      for pix=1:Npix BFdata(pix,1)=theimage(Ll(pix,1),Cl(pix,1)); end % for pix

      %                  1    2               3              4           5        6           7        8
      % sorted_cellBF = [BF , meanBF (vsim) , stdBF (vsim) , Npix_mini , BFmini , Npix_maxi , BFmaxi , BFAREA]
      short_cellBF(idx,1)=sum(BFdata(:))/Npix;

      ll=BFdata<lim_mini;
      Npix_mini=sum(ll);
      BFmini=sum(BFdata(ll,1))/Npix_mini;
      short_cellBF(idx,4)=Npix_mini;
      short_cellBF(idx,5)=BFmini;

      ll=BFdata>lim_maxi;
      Npix_maxi=sum(ll);
      BFmaxi=sum(BFdata(ll,1))/Npix_maxi;
      short_cellBF(idx,6)=Npix_maxi;
      short_cellBF(idx,7)=BFmaxi;

      short_cellBF(idx,8)=Npix;

    end % for c

  end % if NN>0

end % for im

pos_ana_dir=cat(2,ana_path,'BFproc/',num2str(pos-1,'%0.5d'),'/');
save(cat(2,pos_ana_dir,'short_cellBF.mat'),'short_cellBF','-v7.3','-nocompression');

end % funciton
