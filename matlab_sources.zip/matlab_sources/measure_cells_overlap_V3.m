function OVpix=measure_cells_overlap_V3(BLC1,MLC1,Xref1,Yref1,MLC2,Xref2,Yref2,Lc_abs,Cc_abs,pixsize)

% convert mask LC into abs coordinates (pix units)
[Npix2,~]=size(MLC2);
aMLC2=zeros(Npix2,2);
aMLC2(:,1)=-(double(MLC2(:,1))-Lc_abs)+round(Yref2/pixsize);
aMLC2(:,2)=double(MLC2(:,2))-Cc_abs+round(Xref2/pixsize);

[Npix1,~]=size(BLC1);
aBLC1=zeros(Npix1,2);
aBLC1(:,1)=-(double(BLC1(:,1))-Lc_abs)+round(Yref1/pixsize);
aBLC1(:,2)=double(BLC1(:,2))-Cc_abs+round(Xref1/pixsize);
% calculate overlap in number of pixels
OVtemp=0;
for pix=1:Npix1
  logiidx=(aBLC1(pix,1)==aMLC2(:,1))&(aBLC1(pix,2)==aMLC2(:,2));
  OVtemp=OVtemp+sum(logiidx(:));
end % for pix

% if boundary overlap, then calculate...
OVpix=0;
if OVtemp>0

  [Npix1,~]=size(MLC1);
  aMLC1=zeros(Npix1,2);
  aMLC1(:,1)=-(double(MLC1(:,1))-Lc_abs)+round(Yref1/pixsize); % lines
  aMLC1(:,2)=double(MLC1(:,2))-Cc_abs+round(Xref1/pixsize); % cols

  % calculate overlap in number of pixels
  for pix=1:Npix1
    logiidx=(aMLC1(pix,1)==aMLC2(:,1))&(aMLC1(pix,2)==aMLC2(:,2));
    OVpix=OVpix+sum(logiidx(:));
  end % for pix
end % if

end % function

