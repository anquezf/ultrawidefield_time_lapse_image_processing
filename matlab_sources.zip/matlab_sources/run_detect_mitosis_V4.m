function run_detect_mitosis_V3(ana_path,mito_miniD_str)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

mito_miniD=str2double(mito_miniD_str);
save(cat(2,ana_path,'mito_miniD.mat'),'mito_miniD','-v7.3','-nocompression');

fprintf('* detect mitosis : \n');

% ***
% *** load data

fprintf('load data ...');

load(cat(2,ana_path,'mitoCONTRAST_TH1.mat'),'mitoCONTRAST_TH1');

load(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata')
load(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF')

sorted_cellCONTRAST=sorted_cellBF(:,6)./sorted_cellBF(:,8)+sorted_cellBF(:,4)./sorted_cellBF(:,8);

load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

load(cat(2,ana_path,'tracking/Nitemax.mat'),'Nitemax');
load(cat(2,ana_path,'tracking/Lmax2.mat'),'Lmax2');

fprintf('DONE !\n');


cellLINES=[];
% cellLINES = [ mother_CID , daughter1_CID , daughter2_CID , im]

% ***
% *** detect mitosis

fprintf('detect mitosis for image %5d of %5d',0,Nim);
for im=(im_start+1):im_stop

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',im,Nim);

  [mothers_sisters,NMS]=detect_mitosis_V3(im,sorted_celldata,Lmax2,Nitemax,sorted_cellCONTRAST,mitoCONTRAST_TH1);

  for ms=1:NMS
    idxm=mothers_sisters(ms,1);
    idxs=mothers_sisters(ms,2);
    m_CID=sorted_celldata(idxm,12);
    d2_CID=sorted_celldata(idxs,12);
    cellLINES=cat(1,cellLINES,[m_CID,m_CID,d2_CID,im]);
  end % for ms

end % for im
fprintf(' DONE !\n');



fprintf('remove too short mitosis events...');
cellLINES_old=cellLINES;
cellLINES=clean_short_mitosis_events(cellLINES,mito_miniD,sorted_celldata,sorted_cellCONTRAST,im_start,im_stop);
fprintf(' DONE!\n');



fprintf('combine mitosis for image %5d of %5d',0,Nim);
maxCID=max(sorted_celldata(:,12));
[NCL,~]=size(cellLINES);
idxs=[1:NCL]';
for im=(im_start+1):im_stop

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',im,Nim);

  logiidx=cellLINES(:,4)==im;
  NN=sum(logiidx);
  if NN>0

    idxlist=idxs(logiidx,1);
    for ii=1:NN

      idx=idxlist(ii,1);

      m_CID=cellLINES(idx,1);
      d2_CID=cellLINES(idx,3);

      % create new CID for mother-daughter
      d1_CID=maxCID+1;
      ll1=(sorted_celldata(:,12)==m_CID)&(sorted_celldata(:,3)>(im-1));

      if sum(ll1)>0
      
        maxCID=maxCID+1;
        cellLINES(idx,2)=d1_CID;

        % correct sorted_celldata for frame>=im
        sorted_celldata(ll1,12)=d1_CID;

        % correct cellLINEs for next frames M
        ll=(cellLINES(:,1)==m_CID)&(cellLINES(:,4)>im);
        if sum(ll)>0 cellLINES(ll,1)=d1_CID; end%if
        % correct cellLINEs for next frames D1
        ll=(cellLINES(:,2)==m_CID)&(cellLINES(:,4)>im);
        if sum(ll)>0 cellLINES(ll,2)=d1_CID; end%if
        % correct cellLINEs for next frames D2
        ll=(cellLINES(:,3)==m_CID)&(cellLINES(:,4)>im);
        if sum(ll)>0 cellLINES(ll,3)=d1_CID; end%if

      end % if sum(ll1)>0

    end % for idx

  end % if NN>0

end % for im

save(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellLINES.mat'),'cellLINES','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellLINES_old.mat'),'cellLINES_old','-v7.3','-nocompression');



end % function
