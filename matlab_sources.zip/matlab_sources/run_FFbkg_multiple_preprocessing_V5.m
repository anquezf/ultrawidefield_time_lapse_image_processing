function run_FFbkg_multiple_preprocessing_V5

warning off
FS=12;


% ********************************************
% *** get  current ana_path_list and NBmax ***
% ********************************************

run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if
load(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe');



% ******************************
% *** some usefull variables ***
% ******************************

% 1st FF smoothing : NL,NC
ana_path=ana_path_list{1,1};

load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

% mesh grid
[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);

BKGtot=zeros(NL,NC);
NBKGtot=zeros(NL,NC);
BKGAVGtot=zeros(NL,NC);
holes_mask_tot=zeros(NL,NC,'logical');

AVGtot=zeros(NL,NC);

BKG=zeros(NL,NC);
NBKG=zeros(NL,NC);
BKGAVG=zeros(NL,NC);
holes_mask=zeros(NL,NC,'logical');

FFtemp=zeros(NL,NC);
padded_image=zeros(3*NL,3*NC);



% ************************************************************************************************************************************************

% ******************************
% *** exctract BKG FlatField ***
% ******************************

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ******************************* ***\n');
fprintf('*** MULTIPLE exctract BKG FlatField ***\n');
fprintf('*** ******************************* ***\n');
fprintf('\n');




for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* load BKG FlatField - experiment %d : ',ana_path,'\n'),expe);


  % *** load params
  % ***************
  load(cat(2,ana_path,'deltai.mat'),'deltai');
  load(cat(2,ana_path,'imaxi.mat'),'imaxi');
  load(cat(2,ana_path,'imini.mat'),'imini');
  load(cat(2,ana_path,'iedges.mat'),'iedges');

  load(cat(2,ana_path,'FFmini.mat'),'FFmini');
  load(cat(2,ana_path,'pad_dpix.mat'),'pad_dpix');
  load(cat(2,ana_path,'fWFF.mat'),'fWFF');

  load(cat(2,ana_path,'Nsig.mat'),'Nsig');

  load(cat(2,ana_path,'fW1.mat'),'fW1');
  load(cat(2,ana_path,'fW2.mat'),'fW2');

  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');


  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- exctract BKG FlatField : ');

  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fprintf(fid,'\n');
  fclose(fid);


  % *************************

  % *** load AVG
  % ************


  % *** write log file

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'exctract BKG FlatField (');
  fprintf(fid,'fWFF (um) = ');
  fprintf(fid,num2str(fWFF));
  fprintf(fid,';');
  fprintf(fid,'pad_dpix = ');
  fprintf(fid,num2str(pad_dpix));
  fprintf(fid,';');
  fprintf(fid,'FFmini = ');
  fprintf(fid,num2str(FFmini));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** load data for expe

  BKG=zeros(NL,NC);
  NBKG=zeros(NL,NC);
  for im=im_start:im_stop
    save_dir=cat(2,ana_path,'NUC_BKG_FOREG/',num2str(im,'%05d'),'/');
    load(cat(2,save_dir,'cumu_BKG.mat'),'cumu_BKG');
    load(cat(2,save_dir,'Nfound_BKG.mat'),'Nfound_BKG');
    BKG=BKG+cumu_BKG;
    NBKG=NBKG+Nfound_BKG;
  end % for im 

  % *** combine with other experiments
  BKGtot=BKGtot+BKG;
  NBKGtot=NBKGtot+NBKG;

  % *** get holes for this experiment
  BKGAVG=BKG./NBKG;
  FFtemp=BKGAVG/max(BKGAVG(:));
  holes_mask=(FFtemp<FFmini)|isnan(FFtemp)|isinf(FFtemp)|(NBKG==0);

  % save data
  save_dir=cat(2,ana_path,'NUC_BKG_FOREG/');
  save(cat(2,save_dir,'BKG.mat'),'BKG','-v7.3','-nocompression');
  save(cat(2,save_dir,'NBKG.mat'),'NBKG','-v7.3','-nocompression');
  save(cat(2,save_dir,'BKGAVG.mat'),'BKGAVG','-v7.3','-nocompression');
  save(cat(2,save_dir,'holes_mask.mat'),'holes_mask','-v7.3','-nocompression');

end % for exp
fprintf('\n')




% ************************************************************************************************************************************************

% *****************************
% *** process BKG FlatField ***
% *****************************


fprintf('* process BKG FlatField...');

% load params
ana_path=ana_path_list{1,1};
load(cat(2,ana_path,'pad_dpix.mat'),'pad_dpix');
load(cat(2,ana_path,'fWFF.mat'),'fWFF');
load(cat(2,ana_path,'FFmini.mat'),'FFmini');

load(cat(2,ana_path,'pixsize.mat'));
fWFF_pix=fWFF/pixsize;
[Npts,~]=size(iedges);

% repair holes
BKGAVGtot=BKGtot./NBKGtot;
FFtemp=BKGAVGtot/max(BKGAVGtot(:));
holes_mask_tot=(FFtemp<FFmini)|isnan(FFtemp)|isinf(FFtemp)|(NBKG==0);

AVGtot=zeros(NL,NC);
NN=sum(holes_mask_tot(:));
if NN>0
  if NN>(0.5*NL*NC)
    BKGAVGtot=zeros(NL,NC);
  else
    BKGAVGtot=repair_FF_hole_V2(BKGtot,NBKGtot,holes_mask_tot);
  end % if
end % if

if ~(NN>(0.5*NL*NC))
% *** remove outliers
  BKGAVGtot=medfilt2(BKGAVGtot,[3 3],'symmetric');
% *** LP filter
  padded_image=do_padding(BKGAVGtot,pad_dpix,NL,NC,Lmesh,Cmesh);
  padded_image=imgaussfilt(padded_image,fWFF_pix);
  AVGtot=padded_image((NL+1):(2*NL),(NC+1):(2*NC));
end % if

% *** normalize
if (sum(AVGtot(:))==0)||(sum(isnan(AVGtot(:)))>0)
  FF_bkg=ones(NL,NC);
else
  FF_bkg=AVGtot/max(AVGtot(:));
end % if

fprintf(' DONE ! \n')




% ************************************************************************************************************************************************

% *** save FF for each EXPE
% *************************

% figure
hf=figure('Units','centimeters','PaperSize', [60 60],'visible','off');
ax=subplot(1,1,1);
set(ax,'FontSize',FS,'FontWeight','Bold');
xlabel(ax,'X (\mu m)','FontSize',FS,'FontWeight','Bold');
ylabel(ax,'Y (\mu m)','FontSize',FS,'FontWeight','Bold');
imagesc(ax,'XData',[0:(NC-1)]*pixsize,'YData',[0:(NL-1)]*pixsize,'CData',FF_bkg);
axis(ax,'equal');
axis(ax,[0 (NC-1)*pixsize 0 (NL-1)*pixsize]);
caxis(ax,[0 1]);
colormap(ax,hot);
colorbar;

% save loop
fprintf('* save BKG FlatField and measure b0 for experiment %5d of %5d',0,0);
for expe=1:Nexpe

  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',expe,Nexpe);

  ana_path=ana_path_list{expe,1};
  save(cat(2,ana_path,'FF_bkg.mat'),'FF_bkg','-v7.3','-nocompression');
  print(cat(2,ana_path,'FlatFieldCorrection_FFbkg.png'),'-dpng','-r300');

  save_dir=cat(2,ana_path,'NUC_BKG_FOREG/');
  save(cat(2,save_dir,'BKGAVG_tot.mat'),'AVGtot','-v7.3','-nocompression');
  save(cat(2,save_dir,'BKGAVGtot.mat'),'BKGAVGtot','-v7.3','-nocompression');
  save(cat(2,save_dir,'BKGtot.mat'),'BKGtot','-v7.3','-nocompression');
  save(cat(2,save_dir,'NBKGtot.mat'),'NBKGtot','-v7.3','-nocompression');
  save(cat(2,save_dir,'holes_mask_tot.mat'),'holes_mask_tot','-v7.3','-nocompression');

  save_dir=cat(2,ana_path,'NUC_BKG_FOREG/');
  load(cat(2,save_dir,'BKG.mat'),'BKG');
  load(cat(2,save_dir,'NBKG.mat'),'NBKG');
  load(cat(2,save_dir,'holes_mask.mat'),'holes_mask');
  b0=mean( (BKG(~holes_mask)./NBKG(~holes_mask))./FF_bkg(~holes_mask) );
  save(cat(2,ana_path,'b0.mat'),'b0','-v7.3','-nocompression');

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  t=now;
  fprintf(fid,' --- combined : ');
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fclose(fid);

end % for exp
fprintf(' DONE ! \n')

close(hf);


for expe=1:Nexpe

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'* estimate delta_b(t) - experiment %d : ',ana_path,'\n'),expe);

  load(cat(2,ana_path,'b0.mat'),'b0');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');
  load(cat(2,ana_path,'FFmini.mat'),'Ffmini');


  % *************************

  % *** get delta_b vsim
  % ********************

  delta_b_vsim=zeros(1,Nim);

  for im=im_start:im_stop
    save_dir=cat(2,ana_path,'NUC_BKG_FOREG/',num2str(im,'%05d'),'/');
    load(cat(2,save_dir,'cumu_BKG.mat'),'cumu_BKG');
    load(cat(2,save_dir,'Nfound_BKG.mat'),'Nfound_BKG');

    BKGAVG=cumu_BKG./Nfound_BKG;
    FFtemp=BKGAVG/max(BKGAVG(:));
    holes_mask=(FFtemp<FFmini)|isnan(FFtemp)|isinf(FFtemp)&(Nfound_BKG==0);
    
    delta_b_vsim(1,im)=mean((cumu_BKG(~holes_mask)./Nfound_BKG(~holes_mask))./FF_bkg(~holes_mask))-b0;
  end % for im 

  save(cat(2,ana_path,'delta_b_vsim.mat'),'delta_b_vsim','-v7.3','-nocompression');


  % *************************

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- exctract BKG FlatField ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

  
end % for expe


fprintf('\n\n\n We have pre-processed %5d experiments... GOODLUCK !\n',Nexpe);
fprintf('\n\n');



end % funciton
