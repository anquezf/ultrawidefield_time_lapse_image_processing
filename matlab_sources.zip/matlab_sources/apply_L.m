function dataF=apply_L(data,N)

[Ncell,Npts]=size(data);
dataF=zeros(Ncell,Npts);

for c=1:Ncell
  XF=Lope3(data(c,:),N);
  dataF(c,:)=XF;
end % for c

end % fucntion
