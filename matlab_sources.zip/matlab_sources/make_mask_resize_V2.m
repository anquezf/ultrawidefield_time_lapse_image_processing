function [mask_out]=make_mask_resize_V2(mask_in,Nreg,NL,NC,rscale)

mask_out=zeros(NL,NC);

for c=1:Nreg
  mask_out(imresize((mask_in==c),rscale)>0)=c;
end % for c

end % function
