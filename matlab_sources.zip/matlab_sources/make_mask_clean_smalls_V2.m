function [mask_out]=make_mask_clean_smalls_V2(mask_in,Nreg,NL,NC)

mask_out=zeros(NL,NC);
mask_temp=zeros(NL,NC);
Lmask_temp=zeros(NL,NC);

for c=1:Nreg

  mask_temp=(mask_in==c);
  [Lmask_temp,NN]=bwlabel(mask_temp);

  if NN>1
    area_list=zeros(NN,1);
    for s=1:NN
      mask_temp=(Lmask_temp==s);
      area_list(s,1)=sum(mask_temp(:));
    end % for s
    [~,sel]=max(area_list);
    mask_out((Lmask_temp==sel))=c;
  else
    mask_out((Lmask_temp==1))=c;
  end % if NN>1

end % for c

end % funciton

