function run_avgBKGFOREG_multiple_FLUO_V3(chanFluo,NBMAX_str)

warning off

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ****************************************** ***\n');
fprintf('*** MULTIPLE PRE-PROCESSING BKG/FOREG Averages ***\n');
fprintf('*** ****************************************** ***\n');
fprintf('\n');



% ********************************************
% *** get  current ana_path_list and NBmax ***
% ********************************************

run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if
load(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe');

[Nexpe,~]=size(ana_path_list);
for expe=1:Nexpe
  ana_path=ana_path_list{expe,1};
  [~,Nchar]=size(ana_path);
  if ~(strcmp(ana_path(1,Nchar),'/'))
    ana_path=cat(2,ana_path,'/');
  end % if
  ana_path_list{expe,1}=ana_path;
  fprintf(cat(2,ana_path,'\n'));
end % for exp
fprintf('\n');

% ******************************
% *** some usefull variables ***
% ******************************

% 1st FF smoothing : NL,NC
ana_path=ana_path_list{1,1};

load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');


% ***************************************
% *** run avg processing of bkg/foreg ***
% ***************************************


NBMAX=str2double(NBMAX_str);
POOLOBJ=parpool('local',NBMAX,'IdleTimeout',360);



for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'* bkg/foreg average - experiment %d : ',ana_path,'\n'),expe);

  % *** load params
  % ***************

  Npos=0; Nim=0; im_start=0; im_stop=0;
  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');

  NL=0; NC=0;
  load(cat(2,ana_path,'NL.mat'),'NL');
  load(cat(2,ana_path,'NC.mat'),'NC');

  imoffset=zeros(NL,NC);
  flipUD=0; flipLR=0;
  load(cat(2,ana_path,'imoffset.mat'),'imoffset');
  load(cat(2,ana_path,'flipUD.mat'),'flipUD');
  load(cat(2,ana_path,'flipLR.mat'),'flipLR');


  % *************************

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- Fluo Analysis ');
  fprintf(fid,chanFluo);
  fprintf(fid,' - pre-processing bkg/foreg averages : ');
  tstart=now;
  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fclose(fid);

  % process
  fprintf('run pre-processing...')
  parfor im=im_start:im_stop
    bkg_foreg_avg_FLUO(ana_path,chanFluo,Npos,NL,NC,imoffset,flipUD,flipLR,im);
  end % par for
  fprintf(' DONE ! \n')

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- Fluo Analysis ');
  fprintf(fid,chanFluo);
  fprintf(fid,' - pre-processing bkg/foreg averages : ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for exp


fprintf('\n\n We have pre-processed %5d experiments... GOODLUCK !\n',Nexpe);
delete(POOLOBJ);
fprintf('\n\n');


end % funciton

