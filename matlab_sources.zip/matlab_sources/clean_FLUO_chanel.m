function clean_FLUO_chanel(ana_path,chanFluo)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

fluo_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/');
  
if exist(cat(2,fluo_ana_dir,'positions_infos/'))
  rmdir(cat(2,fluo_ana_dir,'positions_infos/'),'s');
end % if

if exist(cat(2,fluo_ana_dir,'images_infos/'));
  rmdir(cat(2,fluo_ana_dir,'images_infos/'),'s');
end % if

end % function
