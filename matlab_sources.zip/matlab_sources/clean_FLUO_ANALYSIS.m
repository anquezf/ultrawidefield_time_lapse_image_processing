function clean_FLUO_ANALYSIS(ana_path)
warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if


% *** load infos

fprintf('*** load infos ...');

load(cat(2,ana_path,'im_start.mat'));
load(cat(2,ana_path,'im_stop.mat'));
load(cat(2,ana_path,'Npos.mat'));

fprintf('DONE ! \n\n');




% *** get cellDATA and chanels

fprintf('*** search chanels :\n')

% get all dirs
dirList=utils_DIRList(cat(2,ana_path,'Fluo_Ana/'));
[Ndir,~]=size(dirList);

% find cellDATA dir
d_cd=0;
for d=1:Ndir
  thedir=dirList{d,1};
  % make sure it end with a /
  [~,Nchar]=size(thedir);
  if ~(strcmp(thedir(1,Nchar),'/'))
    thedir=cat(2,thedir,'/');
  end % if
  slashpos=regexp(thedir,'/');
  [~,Nslash]=size(slashpos);
  idx2=slashpos(1,Nslash)-1;
  idx1=slashpos(1,Nslash-1)+1;
  thename=thedir(1,idx1:idx2);
  fprintf(cat(2,thename,'\n'));
  if strcmp(thename,'cellDATA')
    d_cd=d;
  end % if
end % for d

% build chanList
chanList=dirList;
if d_cd>0
  chanList(d_cd,:)=[];
  fprintf('-> cellDATA found !\n');
end % if
[Nchan,~]=size(chanList);
fprintf(cat(2,'-> found : ',num2str(Nchan),' channels !\n\n'));


% *** clean cellDATA
if exist(cat(2,ana_path,'Fluo_Ana/cellDATA/'))

  fprintf('*** clean cellDATA ...')

  for im=im_start:im_stop

    % remove files  
    for pos=1:Npos
      delete(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%05d'),'/',num2str(pos-1,'%05d'),'/bkg_mask.mat'));
      delete(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%05d'),'/',num2str(pos-1,'%05d'),'/cell_mask.mat'));
      delete(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%05d'),'/',num2str(pos-1,'%05d'),'/forege_mask.mat'));
    end % for pos
    % remove directory
    rmdir(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%05d'),'/',num2str(pos-1,'%05d'),'/'), 's');
    
    % remove files
    delete(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%05d'),'/','Nfound_BKG.mat'));
    delete(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%05d'),'/','Nfound_FOREG.mat'));
    delete(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%05d'),'/','short_cellboundLC.mat'));
    delete(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%05d'),'/','short_celldata.mat'));
    delete(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%05d'),'/','short_cellmaskLC.mat'));
    % remove directory
    rmdir(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%05d'),'/'), 's');
    
  end % for im
  
  % remove directory
  rmdir(cat(2,ana_path,'Fluo_Ana/cellDATA/'), 's');
  
  fprintf('DONE ! \n\n');
  
end % if



% *** clean chanels
if Nchan>0

  fprintf('*** clean channels :\n')

  for chan=1:Nchan
  
    chan_dir=chanList{chan,1};
    
    fprintf(chan_dir)
    fprintf('\n');
    
    % make sure it end with a /
    [~,Nchar]=size(chan_dir);
    if ~(strcmp(chan_dir(1,Nchar),'/'))
      chan_dir=cat(2,chan_dir,'/');
    end % if
    
    % clean images infos
    for im=im_start:im_stop
    
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','AREA_im.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','BKG_cor_im.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','BKG_dns_im.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','BKG_raw_im.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','BKG_sub_im.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','cumu_BKG.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','cumu_FOREG.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','cumu_FOREG2.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','fileListF_pos.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','histo_FLUO.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','INTEN_cor_im.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','INTEN_dns_im.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','INTEN_raw_im.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','INTEN_sub_im.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','Nfound_BKG.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','Nfound_FOREG.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','Nfound_FOREG2.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','time_s_pos.mat'));
      delete(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/','TIMES_im.mat'));
      
      rmdir(cat(2,chan_dir,'images_infos/',num2str(im,'%05d'),'/'),'s');
      
    end % for im
    rmdir(cat(2,chan_dir,'images_infos/'),'s');
    
    delete(cat(2,chan_dir,'BKG.mat'));
    delete(cat(2,chan_dir,'BKGAVG.mat'));
    delete(cat(2,chan_dir,'BKGAVG_tot.mat'));
    delete(cat(2,chan_dir,'BKGAVGtot.mat'));
    delete(cat(2,chan_dir,'BKGtot.mat'));
    
    delete(cat(2,chan_dir,'FOREG.mat'));
    delete(cat(2,chan_dir,'FOREGAVG.mat'));
    delete(cat(2,chan_dir,'FOREGAVG_tot.mat'));
    delete(cat(2,chan_dir,'FOREGAVGtot.mat'));
    delete(cat(2,chan_dir,'FOREGtot.mat'));
    
    delete(cat(2,chan_dir,'holes_mask.mat'));
    delete(cat(2,chan_dir,'holes_mask_foreg.mat'));
    delete(cat(2,chan_dir,'holes_mask_foreg_tot.mat'));
    delete(cat(2,chan_dir,'holes_mask_tot.mat'));
    
    delete(cat(2,chan_dir,'NBKG.mat'));
    delete(cat(2,chan_dir,'NBKGtot.mat'));
    delete(cat(2,chan_dir,'NFOREG.mat'));
    delete(cat(2,chan_dir,'NFOREGtot.mat'));
    
    fprintf('-> DONE ! \n');
    
  end % for chan
  
  fprintf('\n\n');
  
end % if Nchan>0


end % funciton
    
    
    
    
    
    
    
