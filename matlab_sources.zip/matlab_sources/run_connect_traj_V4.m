function run_connect_traj_V3(ana_path,mem_str,NBMAX_str)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

mem=str2double(mem_str);
save(cat(2,ana_path,'mem.mat'),'mem','-v7.3','-nocompression');

fprintf('* connect trajectories : \n');


NBMAX=str2double(NBMAX_str);
% *** create parallel computing
POOLOBJ=parpool('local',NBMAX,'IdleTimeout',240);


% ***
% *** load data

fprintf('load data ...');

load(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata')
load(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC')
load(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC')
load(cat(2,ana_path,'combined_data/sorted_cellAP.mat'),'sorted_cellAP')
load(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF')

load(cat(2,ana_path,'combined_data/celldata_fp.mat'),'celldata_fp')
load(cat(2,ana_path,'combined_data/cellmaskLC_fp.mat'),'cellmaskLC_fp')
load(cat(2,ana_path,'combined_data/cellboundLC_fp.mat'),'cellboundLC_fp')

load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

load(cat(2,ana_path,'mitoCONTRAST_TH1.mat'),'mitoCONTRAST_TH1');

load(cat(2,ana_path,'tracking/Nitemax.mat'),'Nitemax');
load(cat(2,ana_path,'tracking/Lmax2.mat'),'Lmax2');

load(cat(2,ana_path,'XYlist.mat'),'XYlist');
load(cat(2,ana_path,'pixsize.mat'),'pixsize');
load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');
Lc_abs=NL/2;
Cc_abs=NC/2;

load(cat(2,ana_path,'rscAREA_tol.mat'),'rscAREA_tol');

fprintf('DONE !\n');

[NFP,~]=size(celldata_fp);
idxs_fp=[1:NFP]';

maxCID=max(sorted_celldata(:,12));
connected_traj=[];

fprintf('connect trajectories for image %5d of %5d',0,Nim);
for im=(im_start+1):(im_stop)

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',im,Nim-1);

  [enders_starters,NES]=connect_traj_V3(im,sorted_celldata,sorted_cellBF,mem,Lmax2,Nitemax,mitoCONTRAST_TH1);

  % *** edit CID
  for es=1:NES
    idxe=enders_starters(es,1);
    idxs=enders_starters(es,2);
    e_CID=sorted_celldata(idxe,12);
    s_CID=sorted_celldata(idxs,12);
    s_im=sorted_celldata(idxs,3);
    logiidx=(sorted_celldata(:,12)==s_CID)&(sorted_celldata(:,3)>(s_im-1));
    sorted_celldata(logiidx,12)=e_CID;
    connected_traj=cat(1,connected_traj,[e_CID,im]);
  end % for ms

  % *** rescue FP ?
  for es=1:NES
    idxe=enders_starters(es,1);
    idxs=enders_starters(es,2);

    ie=sorted_celldata(idxe,3);
    pe=sorted_celldata(idxe,10);
    is=sorted_celldata(idxs,3);
    ps=sorted_celldata(idxs,10);

    if ps==pe
      Xe=sorted_celldata(idxe,1);
      Ye=sorted_celldata(idxe,2);
      Xs=sorted_celldata(idxs,1);
      Ys=sorted_celldata(idxs,2);
      e_CID=sorted_celldata(idxe,12);

      for ii=(ie+1):(is-1)
        logiidx=(celldata_fp(:,3)==ii)&(celldata_fp(:,10)==ps);
        idxlist=idxs_fp(logiidx,1);
        dsq_list=power(Xs-celldata_fp(idxlist,1),2)+power(Ys-celldata_fp(idxlist,2),2)+power(Xe-celldata_fp(idxlist,1),2)+power(Ye-celldata_fp(idxlist,2),2);
        [dsq_mini,jj]=min(dsq_list);
        idx=idxlist(jj,1);
        if ~(isempty(idx))
          dsq_s=power(Xs-celldata_fp(idx,1),2)+power(Ys-celldata_fp(idx,2),2);
          dsq_e=power(Xe-celldata_fp(idx,1),2)+power(Ye-celldata_fp(idx,2),2);
          if (dsq_s<Lmax2)&&(dsq_e<Lmax2)
            % measure overlap E/S
            mlc_e=sorted_cellmaskLC{idxe,1};
            [AREA_e,~]=size(mlc_e);
            mlc_s=sorted_cellmaskLC{idxs,1};
            [AREA_s,~]=size(mlc_s);
            % measure overlap FP
            r_cd=cat(2,celldata_fp(idx,:),nan,e_CID);
            r_mlc=cellmaskLC_fp{idx,1};
            r_blc=cellboundLC_fp{idx,1};
            [r_A,~]=size(r_mlc);
            if (r_A>((1-rscAREA_tol)*AREA_e))&&(r_A<((1+rscAREA_tol)*AREA_e))&&(r_A>((1-rscAREA_tol)*AREA_s))&&(r_A<((1+rscAREA_tol)*AREA_s))
              Xref=XYlist(ps+1,1);
              Yref=XYlist(ps+1,2);
              sharedAREA_e=measure_cells_overlap_V3(r_blc,r_mlc,Xref,Yref,mlc_e,Xref,Yref,Lc_abs,Cc_abs,pixsize);
              sharedAREA_s=measure_cells_overlap_V3(r_blc,r_mlc,Xref,Yref,mlc_s,Xref,Yref,Lc_abs,Cc_abs,pixsize);
              if (sharedAREA_e>0)&&(sharedAREA_s>0)
                [r_P,~]=size(r_blc);
                r_AP=cat(2,r_A,r_P);
                r_bf=nan(1,8);
                sorted_celldata=cat(1,sorted_celldata,r_cd);
                sorted_cellmaskLC=cat(1,sorted_cellmaskLC,r_mlc);
                sorted_cellboundLC=cat(1,sorted_cellboundLC,r_blc);
                sorted_cellAP=cat(1,sorted_cellAP,r_AP);
                sorted_cellBF=cat(1,sorted_cellBF,r_bf);
              end % if (sharedAREA_e>0)&&(sharedAREA_s>0)
            end % if (r_A>((1-rscAREA_tol)*AREA_e))&&(r_A<((1+rscAREA_tol)*AREA_e))&&(r_A>((1-rscAREA_tol)*AREA_s))&&(r_A<((1+rscAREA_tol)*AREA_s))
          end % if (dsq_s<Lmax2)&&(dsq_e<Lmax2)
        end % if
      end % for ii

    end % if ps==pe

  end % for es

  % *** correct BF
  [Ncell,~]=size(sorted_celldata);
  idxs_tp=[1:Ncell]';
  logiidx=(isnan(sorted_cellBF(:,4)))&(isnan(sorted_cellBF(:,6)))&(isnan(sorted_cellBF(:,8)));
  Nmodif=sum(logiidx(:));
  new_BF_list=zeros(Nmodif,8);
  idxlist=idxs_tp(logiidx,1);
  if Nmodif>0
    parfor modi=1:Nmodif
      idx=idxlist(modi,1);
      newBF=repair_cellBF_V3(ana_path,sorted_celldata,idx,[]);
      new_BF_list(modi,:)=newBF;
    end % par for
    for modi=1:Nmodif
      idx=idxlist(modi,1);
      sorted_cellBF(idx,:)=new_BF_list(modi,:);
    end % for modi
  end % if Nmodif

end % for im
fprintf(' DONE !\n');




fprintf('save data ...');
save(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellAP.mat'),'sorted_cellAP','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/connected_traj.mat'),'connected_traj','-v7.3','-nocompression');
fprintf(' DONE !\n');

delete(POOLOBJ);

end % function


