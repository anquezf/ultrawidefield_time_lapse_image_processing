function init_remove_duplicate_V2(ana_path,deltaXpos_str,deltaYpos_str)

warning off


[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

fprintf('intializing duplicate removal ... \n')

% *** INPUTS
deltaXpos=str2double(deltaXpos_str);
deltaYpos=str2double(deltaYpos_str);
save(cat(2,ana_path,'deltaXpos.mat'),'deltaXpos','-v7.3','-nocompression');
save(cat(2,ana_path,'deltaYpos.mat'),'deltaYpos','-v7.3','-nocompression');

% *** load data
load(cat(2,ana_path,'Npos.mat'),'Npos')
load(cat(2,ana_path,'XYlist.mat'),'XYlist')
load(cat(2,ana_path,'pixsize.mat'),'pixsize')
load(cat(2,ana_path,'NL.mat'),'NL')
load(cat(2,ana_path,'NC.mat'),'NC')

save_path=cat(2,ana_path,'combined_data/');
load(cat(2,save_path,'celldata.mat'),'celldata')
load(cat(2,save_path,'cellmaskLC.mat'),'cellmaskLC')
load(cat(2,save_path,'cellboundLC.mat'),'cellboundLC')

% *** some variables
% number of cells
[Ncell,~]=size(celldata);
idxs=[1:Ncell]';
% some data
WX=NC*pixsize+deltaXpos;
WY=NL*pixsize+deltaYpos;
hWX_sq=power(WX/2,2);
hWY_sq=power(WY/2,2);

% *** OUTPUTS
% position_UDLR= [ [posUP_0 , posDOWN_0 , posLEFT_0 , posRIGHT_0] ; ...]
position_UDLR=zeros(Npos,4);

% *** Build position array with up,down,left,right

fprintf('assembling position %5d of %5d',0,Npos);
for pos=1:Npos

  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',pos,Npos);

  Xp=XYlist(pos,1);
  Yp=XYlist(pos,2);
  % search UP
  [mini,idx]=min(power(XYlist(:,1)-Xp,2)+power(XYlist(:,2)-(Yp+WY),2));
  if mini<hWY_sq
    pos_UDLR(pos,1)=idx;
  else
    pos_UDLR(pos,1)=nan;
  end % if
  % search DOWN
  [mini,idx]=min(power(XYlist(:,1)-Xp,2)+power(XYlist(:,2)-(Yp-WY),2));
  if mini<hWY_sq
    pos_UDLR(pos,2)=idx;
  else
    pos_UDLR(pos,2)=nan;
  end % if
  % search LEFT
  [mini,idx]=min(power(XYlist(:,1)-(Xp-WX),2)+power(XYlist(:,2)-Yp,2));
  if mini<hWX_sq
    pos_UDLR(pos,3)=idx;
  else
    pos_UDLR(pos,3)=nan;
  end % if
  % search RIGHT
  [mini,idx]=min(power(XYlist(:,1)-(Xp+WX),2)+power(XYlist(:,2)-Yp,2));
  if mini<hWX_sq
    pos_UDLR(pos,4)=idx;
  else
    pos_UDLR(pos,4)=nan;
  end % if

end % for p
fprintf('\n')

save(cat(2,ana_path,'pos_UDLR.mat'),'pos_UDLR','-v7.3','-nocompression');


short_celldata=[];
short_cellmaskLC=[];
short_cellboundLC=[];
idxlist=[];

% *** prepare data for each postion
dup_ana_dir=cat(2,ana_path,'RMVDUP/');
mkdir(dup_ana_dir);

load(cat(2,ana_path,'Nim.mat'),'Nim')
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

fprintf('initialize image %5d of %5d',0,Nim);
for im=im_start:im_stop

  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',im,Nim);

  % *** select cell data
  logiidx=(celldata(:,3)==im);
  short_idxlist=idxs(logiidx,1);
  short_celldata=celldata(logiidx,:);
  short_cellmaskLC=cellmaskLC(logiidx,:);
  short_cellboundLC=cellboundLC(logiidx,:);

  dup_ana_dir=cat(2,ana_path,'RMVDUP/',num2str(im,'%0.5d'),'/');
  mkdir(dup_ana_dir);
  save(cat(2,dup_ana_dir,'short_celldata.mat'),'short_celldata','-v7.3','-nocompression');
  save(cat(2,dup_ana_dir,'short_cellmaskLC.mat'),'short_cellmaskLC','-v7.3','-nocompression');
  save(cat(2,dup_ana_dir,'short_cellboundLC.mat'),'short_cellboundLC','-v7.3','-nocompression');
  save(cat(2,dup_ana_dir,'short_idxlist.mat'),'short_idxlist','-v7.3','-nocompression');

end % for im
fprintf(' DONE !\n')


end % funciton
