function run_FFforeg_multiple_FLUO_V3(chanFluo)

warning off
FS=12;

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ********************************* ***\n');
fprintf('*** MULTIPLE exctract FOREG FlatField ***\n');
fprintf('*** ********************************* ***\n');
fprintf('\n');

% ********************************************
% *** get  current ana_path_list and NBmax ***
% ********************************************

run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if
load(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe');

[Nexpe,~]=size(ana_path_list);
for expe=1:Nexpe
  ana_path=ana_path_list{expe,1};
  [~,Nchar]=size(ana_path);
  if ~(strcmp(ana_path(1,Nchar),'/'))
    ana_path=cat(2,ana_path,'/');
  end % if
  ana_path_list{expe,1}=ana_path;
  fprintf(cat(2,ana_path,'\n'));
end % for exp
fprintf('\n');

% ******************************
% *** some usefull variables ***
% ******************************

% 1st FF smoothing : NL,NC
ana_path=ana_path_list{1,1};

load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

% mesh grid
[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);

FOREGtot=zeros(NL,NC);
NFOREGtot=zeros(NL,NC);
FOREAVGtot=zeros(NL,NC);
holes_mask_foreg_tot=zeros(NL,NC,'logical');

AVGtot=zeros(NL,NC);

FOREG=zeros(NL,NC);
NFOREG=zeros(NL,NC);
FOREAVG=zeros(NL,NC);
holes_mask_foreg=zeros(NL,NC,'logical');

FFtemp=zeros(NL,NC);
padded_image=zeros(3*NL,3*NC);

% ************************************************************************************************************************************************

% ********************************
% *** exctract FOREG FlatField ***
% ********************************


for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* load FOREG FlatField - experiment %d : ',ana_path,'\n'),expe);

  load(cat(2,ana_path,'pad_dpix.mat'),'pad_dpix');
  load(cat(2,ana_path,'fWFF.mat'),'fWFF');
  load(cat(2,ana_path,'FFmini.mat'),'FFmini');

  load(cat(2,ana_path,'pixsize.mat'));

  fWFF_pix=fWFF/pixsize;

  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');

  load(cat(2,ana_path,'Fluo_Ana/',chanFluo,'/','b0.mat'),'b0');
  load(cat(2,ana_path,'Fluo_Ana/',chanFluo,'/','FF_bkg.mat'),'FF_bkg');
  load(cat(2,ana_path,'Fluo_Ana/',chanFluo,'/','delta_b_vsim.mat'),'delta_b_vsim');

  % *************************

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- Fluo Analysis ');
  fprintf(fid,chanFluo);
  fprintf(fid,' - extract FOREG FlatField : ');
  tstart=now;
  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fclose(fid);


  % *************************

  % *** load AVG
  % ************

  % *** load data for expe
  FOREG=zeros(NL,NC);
  NFOREG=zeros(NL,NC);
  for im=im_start:im_stop
    im_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/','images_infos/',num2str(im,'%0.5d'),'/');
    load(cat(2,im_ana_dir,'cumu_FOREG2.mat'),'cumu_FOREG2');
    load(cat(2,im_ana_dir,'Nfound_FOREG2.mat'),'Nfound_FOREG2');
    FOREG=FOREG+cumu_FOREG2;
    NFOREG=NFOREG+Nfound_FOREG2;
  end % for im 

  % *** combine with other experiments
  FOREGtot=FOREGtot+FOREG;
  NFOREGtot=NFOREGtot+NFOREG;

  % *** combine with other experiments
  FOREGAVG=FOREG./NFOREG;
  FFtemp=FOREGAVG/max(FOREGAVG(:));
  holes_mask_foreg=(FFtemp<FFmini)|isnan(FFtemp)|isinf(FFtemp)|(NFOREG==0);

  % save data
  save_dir=cat(2,cat(2,ana_path,'Fluo_Ana/',chanFluo,'/'));
  save(cat(2,save_dir,'FOREG.mat'),'FOREG','-v7.3','-nocompression');
  save(cat(2,save_dir,'NFOREG.mat'),'NFOREG','-v7.3','-nocompression');
  save(cat(2,save_dir,'FOREGAVG.mat'),'FOREGAVG','-v7.3','-nocompression');
  save(cat(2,save_dir,'holes_mask_foreg.mat'),'holes_mask_foreg','-v7.3','-nocompression');

end % for exp
fprintf('\n')







% ************************************************************************************************************************************************

% *******************************
% *** process FOREG FlatField ***
% *******************************

fprintf('* process FOREG FlatField...');

% load params
ana_path=ana_path_list{1,1};
load(cat(2,ana_path,'pad_dpix.mat'),'pad_dpix');
load(cat(2,ana_path,'fWFF.mat'),'fWFF');
load(cat(2,ana_path,'FFmini.mat'),'FFmini');

load(cat(2,ana_path,'pixsize.mat'));
fWFF_pix=fWFF/pixsize;
%[Npts,~]=size(iedges);

% *** repair holes
FOREGAVGtot=FOREGtot./NFOREGtot;
FFtemp=FOREGAVGtot/max(FOREGAVGtot(:));
holes_mask_foreg_tot=(FFtemp<FFmini)|isnan(FFtemp)|isinf(FFtemp)|(NFOREG==0);

AVGtot=zeros(NL,NC);
NN=sum(holes_mask_foreg_tot(:));
if NN>0
  if NN>(0.5*NL*NC)
    FOREGAVGtot=zeros(NL,NC);
  else
    FOREGAVGtot=repair_FF_hole_V2(FOREGtot,NFOREGtot,holes_mask_foreg_tot);
  end % if
end % if

if ~(NN>(0.5*NL*NC))
% *** remove outliers
  FOREGAVGtot=medfilt2(FOREGAVGtot,[3 3],'symmetric');
% *** LP filter
  padded_image=do_padding(FOREGAVGtot,pad_dpix,NL,NC,Lmesh,Cmesh);
  padded_image=imgaussfilt(padded_image,fWFF_pix);
  AVGtot=padded_image((NL+1):(2*NL),(NC+1):(2*NC));
end % if

% *** normalize
if (sum(AVGtot(:))==0)||(sum(isnan(AVGtot(:)))>0)
  FF_foreg=ones(NL,NC);
else
  FF_foreg=AVGtot/max(AVGtot(:));
end % if

fprintf(' DONE ! \n')


% ************************************************************************************************************************************************

% *** save FF for each EXPE
% *************************

% figure
hf=figure('Units','centimeters','PaperSize', [60 60],'visible','off');
ax=subplot(1,1,1);
set(ax,'FontSize',FS,'FontWeight','Bold');
xlabel(ax,'X (\mu m)','FontSize',FS,'FontWeight','Bold');
ylabel(ax,'Y (\mu m)','FontSize',FS,'FontWeight','Bold');
imagesc(ax,'XData',[0:(NC-1)]*pixsize,'YData',[0:(NL-1)]*pixsize,'CData',FF_foreg);
axis(ax,'equal');
axis(ax,[0 (NC-1)*pixsize 0 (NL-1)*pixsize]);
caxis(ax,[0 1]);
colormap(ax,hot);
colorbar;

% save loop
fprintf('\n * save FOREG FlatField for experiment %5d of %5d',0,0);
for expe=1:Nexpe

  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',expe,Nexpe);

  ana_path=ana_path_list{expe,1};
  save_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/');
  save(cat(2,save_dir,'FF_foreg.mat'),'FF_foreg','-v7.3','-nocompression');
  print(cat(2,save_dir,'FlatFieldCorrection_FFforeg.png'),'-dpng','-r300');
  save(cat(2,save_dir,'FOREGAVG_tot.mat'),'AVGtot','-v7.3','-nocompression');
  save(cat(2,save_dir,'FOREGAVGtot.mat'),'FOREGAVGtot','-v7.3','-nocompression');
  save(cat(2,save_dir,'FOREGtot.mat'),'FOREGtot','-v7.3','-nocompression');
  save(cat(2,save_dir,'NFOREGtot.mat'),'NFOREGtot','-v7.3','-nocompression');
  save(cat(2,save_dir,'holes_mask_foreg_tot.mat'),'holes_mask_foreg_tot','-v7.3','-nocompression');

  % *************************

  % *** write log file
  % ******************

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- Fluo Analysis ');
  fprintf(fid,chanFluo);
  fprintf(fid,' - extract FOREG FlatField : ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for exp
fprintf(' DONE ! \n')

close(hf);

fprintf('\n\n\n We have pre-processed %5d experiments... GOODLUCK !\n',Nexpe);
fprintf('\n\n');
