function export_cellTRACK_V5(ana_path,pos,memplot)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'FF_NUC.mat'),'FF');
load(cat(2,ana_path,'FF_NUC_bkg.mat'),'FF_bkg');
load(cat(2,ana_path,'FF_NUC_foreg.mat'),'FF_foreg');
load(cat(2,ana_path,'imoffset.mat'));
load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');
load(cat(2,ana_path,'pixsize.mat'),'pixsize');
load(cat(2,ana_path,'flipUD.mat'),'flipUD');
load(cat(2,ana_path,'flipLR.mat'),'flipLR');
load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

% load bkg pdf
load(cat(2,ana_path,'mu_all.mat'),'mu_all');
load(cat(2,ana_path,'sig_all.mat'),'sig_all');
load(cat(2,ana_path,'mu_cor_all.mat'),'mu_cor_all');
load(cat(2,ana_path,'sig_cor_all.mat'),'sig_cor_all');

Lc_abs=NL/2;
Cc_abs=NC/2;

pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'));
load(cat(2,pos_ana_dir,'fileListN.mat'));

load(cat(2,ana_path,'XYlist.mat'),'XYlist');
Xc=XYlist(pos,1);
Yc=XYlist(pos,2);

% *** inputs

load(cat(2,ana_path,'data_vizucelltracking/dup_color.mat'),'dup_color');
load(cat(2,ana_path,'data_vizucelltracking/cmap.mat'),'cmap');

load(cat(2,ana_path,'combined_data/cellLINES.mat'),'cellLINES');
[NcellLINES,~]=size(cellLINES);

data_ana_dir=cat(2,ana_path,'data_vizucelltracking/',num2str(pos-1,'%0.5d'),'/');
load(cat(2,data_ana_dir,'short_scd.mat'),'short_scd');
load(cat(2,data_ana_dir,'short_mlc.mat'),'short_mlc');
load(cat(2,data_ana_dir,'short_blc.mat'),'short_blc');

load(cat(2,data_ana_dir,'short_cd_rmvd.mat'),'short_cd_rmvd');
load(cat(2,data_ana_dir,'short_mlc_rmvd.mat'),'short_mlc_rmvd');

RO_ana_dir=cat(2,ana_path,'vizu_cell_tracking/',num2str(pos-1,'%0.5d'),'/');


image_cur=uint8(zeros(NL,NC,3));


queue=logical(false(NL,NC));

for im=im_start:im_stop

  % *** load raw data

  idx=imidx_2_lidx(im,1);
  theimage=double(imread(fileListN{idx,1}));
  theimage=(theimage-imoffset);

  bkg0=mu_all(1,im)+mu_cor_all(1,im);

  theimage=theimage-bkg0.*FF_bkg;
  theimage=theimage./FF_foreg;

  logiidx=(theimage<0);
  theimage(logiidx)=0;

  % flip ?
  if flipUD>0
    theimage=flipud(theimage);
  end % if
  % flip ?
  if flipLR>0
    theimage=fliplr(theimage);
  end % if

  % *** find contrast
  % *** plot gray scale
  logiidx=(short_scd(:,3)==im)&(short_scd(:,10)==(pos-1));
  Imaxi=quantile(short_scd(:,5),0.7);  
  for cc=1:3 image_cur(:,:,cc)=uint8((255/Imaxi)*theimage); end % for cc



  % *********************
  % *** removed cells ***
  % *********************

  % *** get duplicates of im
  logiidx=(short_cd_rmvd(:,3)==im)&(short_cd_rmvd(:,10)==(pos-1));
  mlcl=short_mlc_rmvd(logiidx,1);

  [Nrmvd,~]=size(mlcl);
  for c=1:Nrmvd
    mlc=mlcl{c,1};
    mlc=round(mlc);
    [Npix,~]=size(mlc);
    for pix=1:Npix
      llc=mlc(pix,1);
      ccc=mlc(pix,2);
      % fill all cell
      for cc=1:3 image_cur(llc,ccc,cc)=dup_color(1,cc); end % for cc
    end % for pix
  end % for c

  % *********************
  % *** tracked cells ***
  % *********************

  logiidx=(short_scd(:,3)==im)&(short_scd(:,10)==(pos-1));
  scdata=short_scd(logiidx,:);
  bLCl=short_blc(logiidx,1);
    %            1  2   3      4     5          6   7   8   9   10 
    %cell_List=[ X ,Y , imidx, Area, Intensity, L,  C,  wB, wS, p  ]
    %            um um  idx    Npix  a.u.       pix pix um  um  idx
  [Ncell,~]=size(scdata);
  % plot tracked cell contour
  for c=1:Ncell

    % *********************************
    % *** plot boundary of current cell
    % get cell data
    cid=scdata(c,12);
    LL=scdata(c,6);
    CC=scdata(c,7);
    % boundary
    BLC=bLCl{c,1};
    [Npix,~]=size(BLC);
    % draw each pixel
    for pp=1:Npix
      % mark boundary pixels
      for cc=1:3 image_cur(BLC(pp,1),BLC(pp,2),cc)=cmap(cid,cc); end % for cc
      % thicken boundary
      if (BLC(pp,1)>LL)&(BLC(pp,1)<NL)
        for cc=1:3 image_cur(BLC(pp,1)+1,BLC(pp,2),cc)=cmap(cid,cc); end % for cc
      elseif (BLC(pp,1)<LL)&(BLC(pp,1)>1)
        for cc=1:3 image_cur(BLC(pp,1)-1,BLC(pp,2),cc)=cmap(cid,cc); end % for cc
      end % if
      % thicken boundary
      if (BLC(pp,2)>CC)&(BLC(pp,2)<NC)
        for cc=1:3 image_cur(BLC(pp,1),BLC(pp,2)+1,cc)=cmap(cid,cc); end % for cc
      elseif (BLC(pp,2)<CC)&(BLC(pp,2)>1)
        for cc=1:3 image_cur(BLC(pp,1),BLC(pp,2)-1,cc)=cmap(cid,cc); end % for cc
      end % if
    end % for pp

    % ************************
    % *** plot previous frames
    % get all centers of mass
    logiidx2=(short_scd(:,3)<=im)&(short_scd(:,3)>(im-memplot))&(short_scd(:,12)==cid);
    Xlist=short_scd(logiidx2,1);
    Ylist=short_scd(logiidx2,2);
    Llist=round(-(Ylist-Yc)/pixsize+Lc_abs);
    Clist=round((Xlist-Xc)/pixsize+Cc_abs);
    Llist=Llist;
    Clist=Clist;
    % create trajectory
    [Npts,~]=size(Llist);
    if Npts>1
      vL=zeros(2,Npts-1); vC=zeros(2,Npts-1);
      for pp=1:(Npts-1)
        vL(1,pp)=Llist(pp,1); vL(2,pp)=Llist(pp+1,1);
        vC(1,pp)=Clist(pp,1); vC(2,pp)=Clist(pp+1,1);
      end % for pp
      % draw vertices on image
      for vv=1:(Npts-1)
        % create line function between 2 points
        f = makelinefun(vC(1,vv),vL(1,vv),vC(2,vv),vL(2,vv),2);
        % get distance between 2 points
        dist=round(1.5*sqrt(diff(vL(:,vv)).^2+diff(vC(:,vv)).^2));
        % create 'dist' points on the line
        [vcLine,vlLine]=f(dist);
        % round the line
        vlLine=round(vlLine);
        vcLine=round(vcLine);
        % contrain line to be within the image
        validInd=(vlLine>=1)&(vlLine<=NL)&(vcLine>=1)&(vcLine<=NC);
        vlLine=vlLine(validInd);
        vcLine=vcLine(validInd);
        %% draw the line on image
        [~,nnp]=size(vlLine);
        for pp=1:nnp
          for cc=1:3 image_cur(vlLine(1,pp),vcLine(1,pp),cc)=cmap(cid,cc); end % for cc
        end % for pp
      end % for vv
    end % if Npts>1




    if NcellLINES>0

    % ****************
    % *** plot mitosis
    % mother ?
    
      lolo=(cellLINES(:,1)==cid)&(cellLINES(:,4)==(im+1));
      if sum(lolo(:))>0
        Cmaxi=round(min([CC+2,NC]));
        Cmini=round(max([CC-2,1]));
        Lmaxi=round(min([LL+2,NL]));
        Lmini=round(max([LL-2,1]));
        for ccc=Cmini:Cmaxi
          for lll=Lmini:Lmaxi
            for cc=1:3 image_cur(lll,ccc,cc)=cmap(cid,cc); end % for cc
          end % for lll
        end % for ccc
      end % if sum(lolo(:))>0 

    % ****************
    % *** plot mitosis
    % sister ?
    lolo=((cellLINES(:,2)==cid)|(cellLINES(:,3)==cid))&(cellLINES(:,4)==im);
    if sum(lolo(:))>0
      cidmother=cellLINES(lolo,1);
      Cmaxi=round(min([CC+2,NC]));
      Cmini=round(max([CC-2,1]));
      Lmaxi=round(min([LL+2,NL]));
      Lmini=round(max([LL-2,1]));
      for ccc=Cmini:Cmaxi
        for lll=Lmini:Lmaxi
          for cc=1:3
            ccmap=cmap(cidmother,cc);
            ccmap=ccmap(1,1);
            image_cur(lll,ccc,cc)=ccmap;
          end % for cc
        end % for lll
      end % for ccc
    end % if sum(lolo(:))>0

    end % if NcellLINES>0
    

  end % for c

  imwrite(image_cur,cat(2,RO_ana_dir,'image_',num2str(im,'%05d'),'.Tiff'));

end % for im

end % function



function fun=makelinefun(x1,y1,x2,y2,o)
%ref http://stackoverflow.com/questions/13209373/matlab-straight-line-between-2-points-with-n-points-between
if nargin < 5
  o = 1;
end % if
if o == 2,
  fun  = @(N) deal(linspace(x1,x2,N), linspace(y1,y2,N));
else
  fun  = @(N) [linspace(x1,x2,N) ; linspace(y1,y2,N)];
end % if
end % funciton
