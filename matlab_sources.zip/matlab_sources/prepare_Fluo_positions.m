function prepare_Fluo_positions(ana_path,chanFluo,pos)

warning off

load(cat(2,ana_path,'pos_List.mat'));
load(cat(2,ana_path,'Nim.mat'));

fluo_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/');

pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'lidx_2_imidx.mat'));
load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'));

% get raw data dir
posdatadir=pos_List{pos,1};
[~,Nchar]=size(posdatadir);
if ~(strcmp(posdatadir(1,Nchar),'/'))
    posdatadir=cat(2,posdatadir,'/');
end % if
% make file List
fileListF=utils_FILEList(cat(2,posdatadir,chanFluo,'/'),'tif');
fileListF=fileListF([1:Nim]',1);

% create pos ana dir
pos_ana_dir=cat(2,fluo_ana_dir,'positions_infos/',num2str(pos-1,'%0.5d'),'/');
mkdir(pos_ana_dir)

save(cat(2,pos_ana_dir,'lidx_2_imidx.mat'),'lidx_2_imidx','-v7.3','-nocompression');
save(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx','-v7.3','-nocompression');
save(cat(2,pos_ana_dir,'fileListF.mat'),'fileListF','-v7.3','-nocompression');
time_s=get_time_s(fileListF)';
save(cat(2,pos_ana_dir,'time_s.mat'),'time_s','-v7.3','-nocompression');

end % function
