function [IMAXI,AMAXI,AFP,IFP,C,dI,dA,hmax,LW]=display_and_move_FPbounds(ax,hmax0,dI0,dA0,IMAXI0,AMAXI0,IFP0,AFP0,C0,LW0)

LW=LW0;
LCOL=[1,1,1];

% *************************
% *** output parameters ***
% paramters for bound definition
% *******************************
dI=dI0;
dA=dA0;
IMAXI=IMAXI0;
AMAXI=AMAXI0;
AFP=AFP0;
IFP=IFP0;
C=C0;

dC=C/10;

% **************************
% *** display parameters ***
hmax=hmax0;



% **************************
% *** get intial polygon ***
% **************************
% curvy part
XC=[IFP+dI:dI:IMAXI]';
YC=AFP+C./(XC-IFP);
logiidx=(YC<=AMAXI);
XC=XC(logiidx,1); YC=YC(logiidx,1);
% top side
%XT=flipud(XC);
%[Npts,~]=size(XC);
%YT=ones(Npts,1)*AMAXI;
% combine
%X=cat(1,XT,XC);
%Y=cat(1,YT,YC);

X=XC;
Y=YC;

% *** display
axis(ax,[0 1.2*IMAXI 0 1.2*AMAXI]);
caxis([0 hmax]);
hold(ax,'on'); hl=plot(X,Y,'-','LineWidth',LW,'Color',LCOL);

% **************************
% *** User Interface ***
% **************************
dostop=0;
while dostop==0

% *** get user command
  k=waitforbuttonpress;
  returned=double(get(gcf,'CurrentCharacter'));
  switch returned
    case 30 % up
      AFP=AFP+dA;
    case 31 % down
      AFP=AFP-dA;
    case 29 % right
      IFP=IFP+dI;
    case 28 % left
      IFP=IFP-dI;
    case 105 % i
      IMAXI=IMAXI+dI;
    case 111 % o
      IMAXI=IMAXI-dI;
    case 97 % a
      AMAXI=AMAXI+dA;
    case 122 % z
      AMAXI=AMAXI-dA;
    case 115 % s
      C=C-dC;
    case 100 % d
      C=C+dC;
    case 99 % c
      hmax=hmax/2;
    case 118 % v
      hmax=hmax*2;
    case 114 %r
      dI=dI/2; dA=dA/2;
    case 116 %t
      dI=dI*2; dA=dA*2;
    case 108 %l
      if LW>1 LW=LW-1; end
    case 109 %m
      LW=LW+1;
    case 113 % q
      dostop=1;
  end % switch

% *** recompute boundary
  % curvy part
  XC=[IFP+dI:dI:IMAXI]';
  YC=AFP+C./(XC-IFP);
  logiidx=(YC<=AMAXI);
  XC=XC(logiidx,1); YC=YC(logiidx,1);
  % top side
%  XT=flipud(XC);
%  [Npts,~]=size(XC);
%  YT=ones(Npts,1)*AMAXI;
  % combine
%  X=cat(1,XT,XC);
%  Y=cat(1,YT,YC);
  X=XC;
  Y=YC;
% *** replot
  axis(ax,[0 1.2*IMAXI 0 1.2*AMAXI]);
  caxis([0 hmax]);
  delete(hl);
  hold(ax,'on'); hl=plot(X,Y,'-','LineWidth',LW,'Color',LCOL);

end % whilde

end % function

