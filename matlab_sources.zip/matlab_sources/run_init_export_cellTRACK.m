function init_export_cellTRACK(ana_path)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'Npos.mat'),'Npos');
mkdir(cat(2,ana_path,'vizu_cell_tracking/'));
mkdir(cat(2,ana_path,'data_vizucelltracking/'));

% load data
fprintf('load data ...')
load(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata');
load(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC');
load(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC');
fprintf(' : DONE!\n')

number_CID=max(sorted_celldata(:,12));
dup_color=[1 0 0];
dup_bound_color=[0 0 0];
save(cat(2,ana_path,'data_vizucelltracking/number_CID.mat'),'number_CID','-v7.3','-nocompression');
save(cat(2,ana_path,'data_vizucelltracking/dup_color.mat'),'dup_color','-v7.3','-nocompression');
save(cat(2,ana_path,'data_vizucelltracking/dup_bound_color.mat'),'dup_bound_color','-v7.3','-nocompression');


[Ncelltot,~]=size(sorted_celldata);

fprintf('intializing position %5d of %5d',0,Npos);
for pos=1:Npos

  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',pos,Npos);

  RO_ana_dir=cat(2,ana_path,'vizu_cell_tracking/',num2str(pos-1,'%0.5d'),'/');
  mkdir(RO_ana_dir);

  data_ana_dir=cat(2,ana_path,'data_vizucelltracking/',num2str(pos-1,'%0.5d'),'/');
  mkdir(data_ana_dir);

  % find cells appearing at p=pos-1
  logiidx=(sorted_celldata(:,10)==(pos-1))|(sorted_celldata(:,11)==(pos-1));
  % find their tracking CID
  posCID=sorted_celldata(:,12);
  posCID=unique(posCID);
  [NCID,~]=size(posCID);
  % we will add all celldata for each CID
  logiidx=logical(zeros(Ncelltot,1));
  for ii=1:NCID
    ll=(sorted_celldata(:,12)==posCID(ii,1));
    logiidx=(logiidx|ll);
  end % for ii
  short_scd=sorted_celldata(logiidx,:);
  short_mlc=sorted_cellmaskLC(logiidx,:);
  short_blc=sorted_cellboundLC(logiidx,:);

  save(cat(2,data_ana_dir,'short_scd.mat'),'short_scd','-v7.3','-nocompression');
  save(cat(2,data_ana_dir,'short_mlc.mat'),'short_mlc','-v7.3','-nocompression');
  save(cat(2,data_ana_dir,'short_blc.mat'),'short_blc','-v7.3','-nocompression');

end % for pos
fprintf('\n')

end % funciton
