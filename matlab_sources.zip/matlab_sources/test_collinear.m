function score=test_collinear(X,Y,Npts)

X0=X(1,1);
Y0=Y(1,1);

XX=X(2:Npts,1);
YY=Y(2:Npts,1);

keep_going=1;

% vertical
logiidx=(XX==X0);
if sum(logiidx)==(Npts-1)
  score=0;
  keep_going=0;
end % if

% horizontal
logiidx=(YY==Y0);
if sum(logiidx)==(Npts-1)
  score=0;
  keep_going=0;
end % if

if keep_going>0

  % find slope
  slope=(YY-Y0)./(XX-X0);
  logiidx=(~isnan(slope))&(~isinf(slope));
  NN=sum(logiidx);
  if NN>3
    score=abs(std(slope(logiidx,1))/mean(slope(logiidx,1)));
  else
    score=0;
  end % if

end % if


if isinf(score)
  score=0;
end % if

if isnan(score)
  score=0;
end % if


end % funciton


