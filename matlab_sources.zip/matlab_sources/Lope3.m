function XF=Lope3(X,N)

[~,Npts]=size(X);

XX=zeros(1,Npts+2*N);
XX(1,(1+N):Npts+N)=X;
XX(1,1:(1+N))=X(1,1);
XX(1,(Npts+1):(Npts+2*N))=X(1,Npts);

XF=zeros(1,Npts);

slist=zeros(N+1,N+1);

for p=1:Npts

  pp=p+N;

  for k=1:N+1
    start=pp-(N-k+1);
    stop=pp+(k-1);
    slist(k,:)=XX(1,start:stop);
  end % for k
  
  smm=min(slist,[],2);

  XF(1,p)=max(smm);

end % for p

end % function
