function prepare_Fluo_images(ana_path,chanFluo,im)

warning off

fluo_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/');

load(cat(2,ana_path,'Npos.mat'));

fileListF_pos=cell(Npos,1);
time_s_pos=zeros(Npos,1);
im_ana_dir=cat(2,fluo_ana_dir,'images_infos/',num2str(im,'%0.5d'),'/');
mkdir(im_ana_dir);
  
for pos=1:Npos
  pos_ana_dir=cat(2,fluo_ana_dir,'positions_infos/',num2str(pos-1,'%0.5d'),'/');
  load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');
  ll=imidx_2_lidx(im,1);
  load(cat(2,pos_ana_dir,'fileListF.mat'),'fileListF');
  fileListF_pos{pos,1}=fileListF{ll,1};
  load(cat(2,pos_ana_dir,'time_s.mat'),'time_s');
  time_s_pos(pos,1)=time_s(1,ll);
end % for pos

save(cat(2,im_ana_dir,'fileListF_pos.mat'),'fileListF_pos','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'time_s_pos.mat'),'time_s_pos','-v7.3','-nocompression');

end % function
