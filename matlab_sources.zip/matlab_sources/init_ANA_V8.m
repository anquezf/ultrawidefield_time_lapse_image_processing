function init_ANA_V8(softversion_str,save_dir,ana_dir_motif,data_dir,chanFluoN,pixsize_str,flipUD_str,flipLR_str,swapXY_str,im_start_str,im_stop_str)

warning off


fprintf('Please select A DIRECTORY to save the analysis\n');
ana_path=uipickfiles('FilterSpec',save_dir)';
ana_path=ana_path{1,1};
[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if
ana_path=cat(2,ana_path,ana_dir_motif);
[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if
fprintf(cat(2,ana_path,'\n'));
mkdir(ana_path)
mkdir(cat(2,ana_path,'LOGS/'));


fprintf('Please select THE directory containing all Positions to analyse\n');
data_path=uipickfiles('FilterSpec',data_dir)';
data_path=data_path{1,1};
[~,Nchar]=size(data_path);
if ~(strcmp(data_path(1,Nchar),'/'))
data_path=cat(2,data_path,'/');
end % if
fprintf(cat(2,data_path,'\n'));
pos_List=utils_DIRList(data_path);

fprintf('\n')

fprintf('Please select A FILE for camera offset correction\n')
offset_file=uipickfiles('FilterSpec',save_dir)';
fprintf(cat(2,offset_file{1,1},'\n'));
load(offset_file{1,1});

fprintf('\n')


pixsize=str2num(pixsize_str);
save(cat(2,ana_path,'pixsize.mat'),'pixsize','-v7.3','-nocompression');

flipUD=str2double(flipUD_str);
flipLR=str2double(flipLR_str);
swapXY=str2double(swapXY_str);
save(cat(2,ana_path,'flipUD.mat'),'flipUD','-v7.3','-nocompression');
save(cat(2,ana_path,'flipLR.mat'),'flipLR','-v7.3','-nocompression');
save(cat(2,ana_path,'swapXY.mat'),'swapXY','-v7.3','-nocompression');

im_start=str2double(im_start_str);
im_stop=str2double(im_stop_str);
save(cat(2,ana_path,'im_start.mat'),'im_start','-v7.3','-nocompression');
save(cat(2,ana_path,'im_stop.mat'),'im_stop','-v7.3','-nocompression');


[Npos,~]=size(pos_List);

save(cat(2,ana_path,'pos_List.mat'),'pos_List','-v7.3','-nocompression');
save(cat(2,ana_path,'Npos.mat'),'Npos','-v7.3','-nocompression');
save(cat(2,ana_path,'data_path.mat'),'data_path','-v7.3','-nocompression');

save(cat(2,ana_path,'imoffset.mat'),'imoffset','-v7.3','-nocompression');

save(cat(2,ana_path,'chanFluoN.mat'),'chanFluoN','-v7.3','-nocompression');

XYlist_path=cat(2,data_path,'XY_positions.txt');
XYlist_temp=loadXYlist_V2(XYlist_path);
XYlist=XYlist_temp;
if swapXY>0
  XYlist(:,1)=XYlist_temp(:,2);
  XYlist(:,2)=XYlist_temp(:,1);
end % if swapXY
save(cat(2,ana_path,'XYlist.mat'),'XYlist','-v7.3','-nocompression');


Nim=inf;

fprintf('intializing number of images, check position %5d of %5d',0,Npos);
for p=0:(Npos-1)

  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',p+1,Npos);

  thepos=pos_List{(p+1),1};
  [~,Nchar]=size(thepos);
  if ~(strcmp(thepos(1,Nchar),'/'))
  thepos=cat(2,thepos,'/');
  end % if

  chan_List=utils_DIRList(thepos);
  [Nchan,~]=size(chan_List);
  for chan=1:Nchan
    thechan=chan_List{chan,1};
    [~,Nchar]=size(thechan);
    if ~(strcmp(thechan(1,Nchar),'/'))
      thechan=cat(2,thechan,'/');
    end % if
    fileList=utils_FILEList(thechan,'tif');
    [NF,~]=size(fileList);
    if (NF>0)&&(Nim>NF)
      Nim=NF;
    end % if
  end % for chan

end % for p
fprintf('\n')
fprintf('found at least %d images for all chanels !\n',Nim)
save(cat(2,ana_path,'Nim.mat'),'Nim','-v7.3','-nocompression');

if im_stop>Nim
  old_imstop=im_stop;
  im_stop=Nim;
  save(cat(2,ana_path,'im_stop.mat'),'im_stop','-v7.3','-nocompression');
  fprintf('im_stop changed from %d to %d !\n',old_imstop,im_stop);
end % if



mkdir(cat(2,ana_path,'DATA/'))
fprintf('intializing position %5d of %5d',0,Npos);
for p=0:(Npos-1)

  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',p+1,Npos);


  thepos=pos_List{(p+1),1};
  [~,Nchar]=size(thepos);
  if ~(strcmp(thepos(1,Nchar),'/'))
  thepos=cat(2,thepos,'/');
  end % if

  pos_ana_dir=cat(2,ana_path,'DATA/',num2str(p,'%0.5d'),'/');
  mkdir(pos_ana_dir)

  XYfield=XYlist((p+1),:);
  save(cat(2,pos_ana_dir,'XYfield.mat'),'XYfield','-v7.3','-nocompression');

  fileListN=utils_FILEList(cat(2,thepos,chanFluoN,'/'),'tif');
  fileListN=fileListN([1:Nim]',1);

  save(cat(2,pos_ana_dir,'fileListN.mat'),'fileListN','-v7.3','-nocompression');
  save(cat(2,pos_ana_dir,'Nim.mat'),'Nim','-v7.3','-nocompression');
  
  time_s=get_time_s(fileListN);
  [~,imidx_2_lidx]=sort(time_s);
  lidx_2_imidx=zeros(Nim,1);
  for imidx=1:Nim
    ii=imidx_2_lidx(imidx,1);
    lidx_2_imidx(ii,1)=imidx;
  end % for imidx
  save(cat(2,pos_ana_dir,'time_s.mat'),'time_s','-v7.3','-nocompression');
  save(cat(2,pos_ana_dir,'lidx_2_imidx.mat'),'lidx_2_imidx','-v7.3','-nocompression');
  save(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx','-v7.3','-nocompression');

end % for p
fprintf('\n')

theimageN=imread(fileListN{1,1});
[NL,NC]=size(theimageN);
save(cat(2,ana_path,'NL.mat'),'NL','-v7.3','-nocompression');
save(cat(2,ana_path,'NC.mat'),'NC','-v7.3','-nocompression');


fid = fopen(cat(2,ana_path,'what_was_done.log'), 'wt' );
fprintf(fid,cat(2,'Soft ImProc CSC',softversion_str,'\n'));
fprintf(fid,cat(2,'init_ANA_V7 (',chanFluoN,' ; pixsize = %f; flipUD = %d; flipLR = %d; swapXY = %d)'),pixsize,flipUD,flipLR,swapXY);
t=now;
fprintf(fid,cat(2,' : ',datestr(t),'\n'));
fprintf(fid,'\n');
fclose(fid);

exit(0)

end % function
