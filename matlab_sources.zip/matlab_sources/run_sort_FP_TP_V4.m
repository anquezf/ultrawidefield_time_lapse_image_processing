function run_sort_FP_TP_V4(ana_path)

LW=3;
FS=15;
warning off


fprintf('--- False Positve and True Positive cells sorting --- \n')
fprintf('\n')

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% *** process
fprintf('*** Loading data ... \n')

load(cat(2,ana_path,'combined_data/rawcelldata.mat'),'rawcelldata')
load(cat(2,ana_path,'combined_data/rawcellmaskLC.mat'),'rawcellmaskLC')
load(cat(2,ana_path,'combined_data/rawcellboundLC.mat'),'rawcellboundLC')

load(cat(2,ana_path,'CLEANCELLDATA/Nbunch.mat'),'Nbunch');

load(cat(2,ana_path,'Nim.mat'),'Nim')
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

load(cat(2,ana_path,'CLEANCELLDATA/IMAXI_list.mat'),'IMAXI_list');
load(cat(2,ana_path,'CLEANCELLDATA/AMAXI_list.mat'),'AMAXI_list');
load(cat(2,ana_path,'CLEANCELLDATA/AFP_list.mat'),'AFP_list');
load(cat(2,ana_path,'CLEANCELLDATA/IFP_list.mat'),'IFP_list');
load(cat(2,ana_path,'CLEANCELLDATA/C_list.mat'),'C_list');

load(cat(2,ana_path,'CLEANCELLDATA/edgesI.mat'),'edgesI')
load(cat(2,ana_path,'CLEANCELLDATA/edgesA.mat'),'edgesA')
load(cat(2,ana_path,'CLEANCELLDATA/IBS.mat'),'IBS')
load(cat(2,ana_path,'CLEANCELLDATA/ABS.mat'),'ABS')
load(cat(2,ana_path,'CLEANCELLDATA/HISTO2D_IA.mat'),'HISTO2D_IA')

fprintf(' : DONE ! \n')



fprintf('*** SORTING FP/TP :\n')

IMAXItot=max(IMAXI_list(:));
AMAXItot=max(AMAXI_list(:));
IFPtot=mean(IFP_list(:));
AFPtot=mean(AFP_list(:));
[~,idxi]=min(abs(edgesI-IFPtot)); idxi=idxi(1,1);
[~,idxa]=min(abs(edgesA-AFPtot)); idxa=idxa(1,1);
[NptsA,NptsI]=size(HISTO2D_IA);
data=HISTO2D_IA(idxa:NptsA,idxi:NptsI);
data=data(:);
logiidx=data>0;
data=data(logiidx,1);
[NN,~]=size(data);
if NN>0
  hmax0=quantile(data(:),0.995);
else
  hmax0=max(HISTO2D_IA(:))/2;
end % if
hfout=figure('Units','centimeters','PaperSize', [60 60],'visible','off'); ax=subplot(1,1,1);
imagesc(ax,'XData',edgesI,'YData',edgesA,'CData',HISTO2D_IA); colormap(ax,hot); colorbar(ax); axis(ax,[0 IMAXItot 0 AMAXItot]); caxis(ax,[0 hmax0]);
xlabel(ax,'Intensity (U.A.)','FontSize',FS,'FontWeight','Bold');
ylabel(ax,'Nucleus Area (\mu m^2)','FontSize',FS,'FontWeight','Bold');
cmap=jet(Nim);

celldata=[];
cellmaskLC=[];
cellboundLC=[];
celldata_fp=[];
cellmaskLC_fp=[];
cellboundLC_fp=[];

for im=im_start:im_stop

  clean_ana_dir=cat(2,ana_path,'CLEANCELLDATA/',num2str(im,'%0.5d'),'/');
  load(cat(2,clean_ana_dir,'short_idxlist.mat'),'short_idxlist');
  load(cat(2,clean_ana_dir,'short_INTENlist.mat'),'short_INTENlist');
  load(cat(2,clean_ana_dir,'short_AREAlist.mat'),'short_AREAlist');

  [NNcc,~]=size(short_idxlist);

  if NNcc>0
  
  cellImax=max(short_INTENlist(:));
  cellAmax=max(short_AREAlist)+2*ABS;

  IMAXI=IMAXI_list(im,1);
  AMAXI=AMAXI_list(im,1);
  AFP=AFP_list(im,1);
  IFP=IFP_list(im,1);
  C=C_list(im,1);

  % curvy part
  logiidx=((edgesI+IBS/2)>IFP)&((edgesI+IBS/2)<cellImax);
  XC=edgesI(logiidx,1)+IBS/2;
  YC=AFP+C./(XC-IFP);
  logiidx=(YC<=AMAXI);
  XC=XC(logiidx,1); YC=YC(logiidx,1);
  % top side
  XT=flipud(XC);
  [Npts,~]=size(XC);
  YT=ones(Npts,1)*cellAmax;
  % right/down corner
  XRDC=cellImax;
  YRDC=min(YC(:));
  % right/up corner
  XRUC=cellImax;
  YRUC=cellAmax;
  % combine
  Xplot=cat(1,XT,XC);
  Yplot=cat(1,YT,YC);
  X=cat(1,XT,XC,XRDC,XRUC);
  Y=cat(1,YT,YC,YRDC,YRUC);

  isTP=inpolygon(short_INTENlist,short_AREAlist,X,Y);
  celldata=cat(1,celldata,rawcelldata(short_idxlist(isTP,1),:));
  cellmaskLC=cat(1,cellmaskLC,rawcellmaskLC(short_idxlist(isTP,1),:));
  cellboundLC=cat(1,cellboundLC,rawcellboundLC(short_idxlist(isTP,1),:));
  
  isFP=~isTP;
  celldata_fp=cat(1,celldata_fp,rawcelldata(short_idxlist(isFP,1),:));
  cellmaskLC_fp=cat(1,cellmaskLC_fp,rawcellmaskLC(short_idxlist(isFP,1),:));
  cellboundLC_fp=cat(1,cellboundLC_fp,rawcellboundLC(short_idxlist(isFP,1),:));

  hold(ax,'on'); plot(X,Y,'-','Color',cmap(im,:),'LineWidth',LW);

  end % if NNcc>0

end % for im

fprintf('DONE !\n')


fprintf('*** SAVING data...')
save(cat(2,ana_path,'combined_data/celldata.mat'),'celldata','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellmaskLC.mat'),'cellmaskLC','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellboundLC.mat'),'cellboundLC','-v7.3','-nocompression');

save(cat(2,ana_path,'combined_data/celldata_fp.mat'),'celldata_fp','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellmaskLC_fp.mat'),'cellmaskLC_fp','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellboundLC_fp.mat'),'cellboundLC_fp','-v7.3','-nocompression');

save(cat(2,ana_path,'CLEANCELLDATA/IMAXI_list.mat'),'IMAXI_list','-v7.3','-nocompression');
save(cat(2,ana_path,'CLEANCELLDATA/AMAXI_list.mat'),'AMAXI_list','-v7.3','-nocompression');
save(cat(2,ana_path,'CLEANCELLDATA/AFP_list.mat'),'AFP_list','-v7.3','-nocompression');
save(cat(2,ana_path,'CLEANCELLDATA/IFP_list.mat'),'IFP_list','-v7.3','-nocompression');
save(cat(2,ana_path,'CLEANCELLDATA/C_list.mat'),'C_list','-v7.3','-nocompression');

print(cat(2,ana_path,'selected_regions.png'),'-dpng','-r300')
print(cat(2,ana_path,'selected_regions.eps'),'-depsc2','-r300')
close(hfout);

fprintf(' DONE ! \n')

[NTP,~]=size(celldata);
[NFP,~]=size(celldata_fp);
fprintf('*** FOUND : \n')
fprintf('%09d true positive cells\n',NTP)
fprintf('%09d false positive features\n',NFP)




end % funciton

