function cellLINES_out=clean_short_mitosis_events(cellLINES_in,miniD,sorted_celldata,sorted_cellCONTRAST,im_start,im_stop)

cellLINES_out=cellLINES_in;


for im=im_stop:-1:(im_start+1)

  logiidx=(cellLINES_out(:,4)==im);
  Ndiv=sum(logiidx(:));

  [NCL,~]=size(cellLINES_out);
  idxs=[1:NCL]';
  idxlist=idxs(logiidx,1);

  idx_to_rmv=[];
  for div=1:Ndiv

    idx=idxlist(div,1);
    CIDm=cellLINES_out(idx,1);

    % *** check daughters 1
    % find when its been a daughter
    % and for which frame>(im-miniD)
    ll=(cellLINES_out(:,2)==CIDm)&(cellLINES_out(:,4)>(im-miniD))&(cellLINES_out(:,4)<(im));
    NN=sum(ll);
    % compare contrast of both events
    if NN>0
      ll2=(sorted_celldata(:,12)==CIDm)&(sorted_celldata(:,3)==(im-1));
      CONTRAST1=sorted_cellCONTRAST(ll2,1);
      % we look for the closest event
      if NN>1
        idx_temp=idxs(ll,1);
        fim=0; idx_found=nan;
        for ii=1:NN
          if cellLINES_out(idx_temp(ii,1),4)>fim
            idx_found=idx_temp(ii,1);
            fim=cellLINES_out(idx_temp(ii,1),4);
          end % if
        end % for ii
      else
        idx_found=idxs(ll,1);
      end
      % get mother contrast
      CID2=cellLINES_out(idx_found,1);
      im2=cellLINES_out(idx_found,4);
      ll2=(sorted_celldata(:,12)==CID2)&(sorted_celldata(:,3)==(im2-1));
      CONTRAST2=sorted_cellCONTRAST(ll2,1);
      % select best CONTRAST
      if CONTRAST1>CONTRAST2
        idx_to_rmv=cat(1,idx_to_rmv,idx_found);
      else
        idx_to_rmv=cat(1,idx_to_rmv,idx);
      end % if
    end % if NN      

    % *** check daughters 2
    % find when its been a daughter
    % and for which frame>(im-miniD)
    ll=(cellLINES_out(:,3)==CIDm)&(cellLINES_out(:,4)>(im-miniD))&(cellLINES_out(:,4)<(im));
    NN=sum(ll);
    % compare contrast of both events
    if NN>0
      ll2=(sorted_celldata(:,12)==CIDm)&(sorted_celldata(:,3)==(im-1));
      CONTRAST1=sorted_cellCONTRAST(ll2,1);
      % we look for the closest event
      if NN>1
        idx_temp=idxs(ll,1);
        fim=0; idx_found=nan;
        for ii=1:NN
          if cellLINES_out(idx_temp(ii,1),4)>fim
            idx_found=idx_temp(ii,1);
            fim=cellLINES_out(idx_temp(ii,1),4);
          end % if
        end % for ii
      else
        idx_found=idxs(ll,1);
      end
      % get mother contrast
      CID2=cellLINES_out(idx_found,1);
      im2=cellLINES_out(idx_found,4);
      ll2=(sorted_celldata(:,12)==CID2)&(sorted_celldata(:,3)==(im2-1));
      CONTRAST2=sorted_cellCONTRAST(ll2,1);
      % select best contrast
      if CONTRAST1>CONTRAST2
        idx_to_rmv=cat(1,idx_to_rmv,idx_found);
      else
        idx_to_rmv=cat(1,idx_to_rmv,idx);
      end % if
    end % if NN      

  end % for div

  cellLINES_out(idx_to_rmv,:)=[];

end % for im

end % function
