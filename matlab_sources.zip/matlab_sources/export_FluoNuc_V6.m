function export_FluoNuc_V6(save_path,ana_path,Imaxi,bit_depth,deltaX_pix,deltaY_pix,Npos,pNC,pNL,NL,NC,b0,delta_b,mu_cor,imoffset,FF_bkg,useFFforeg,FF_foreg,flipUD,flipLR,MAG,im)

warning off

theimage=zeros(NL,NC);
pimage=zeros(pNL,pNC);

for pos=1:Npos

  load(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/fileListN.mat'));
  load(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/imidx_2_lidx.mat'));

  % *** find idx
  idx=imidx_2_lidx(im,1);
  % *** load raw data
  theimage=double(imread(fileListN{idx,1}));
  theimage=(theimage-imoffset);
  % *** image restoration
  theimage=theimage-(b0+delta_b)*FF_bkg;
  if useFFforeg>0
    theimage=theimage./FF_foreg;
  end % if useFFforeg
  theimage=theimage-mu_cor;
  % flip ?
  if flipUD>0 theimage=flipud(theimage); end % if
  % flip ?
  if flipLR>0 theimage=fliplr(theimage); end % if

  pimage=imresize(theimage(deltaY_pix:NL,deltaX_pix:NC),[pNL,pNC]);

  mask=pimage<0;
  pimage(mask)=0;
  mask=pimage>Imaxi;
  pimage(mask)=Imaxi;

  if bit_depth==16
    pimage_out=(pimage/Imaxi)*65535;
    pimage_out=uint16(pimage_out);
  else
    pimage_out=(pimage/Imaxi)*255;
    pimage_out=uint8(pimage_out);
  end % if

  save(cat(2,save_path,'nuc_images/',num2str(MAG),'X/',num2str(pos),'/',num2str(im,'%05d'),'.mat'),'pimage_out','-v7.3','-nocompression');

end % for pos

end % fucntion

