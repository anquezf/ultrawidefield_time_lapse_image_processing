function run_estimate_BFbkg_V2(ana_path,chanBF,NBMAX_str)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

NBMAX=str2double(NBMAX_str);

% ***
% *** Load data

load(cat(2,ana_path,'Nim.mat'),'Nim')
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

load(cat(2,ana_path,'Npos.mat'),'Npos')
load(cat(2,ana_path,'pos_List.mat'),'pos_List');

save(cat(2,ana_path,'chanBF.mat'),'chanBF','-v7.3','-nocompression');

% ***
% *** init analysis

fprintf('* INITIALIZE BrightField averaging : \n');

save_dir=cat(2,ana_path,'BFbkg_estimate/');
mkdir(save_dir);

mkdir(cat(2,save_dir,'POSITIONS/'))
mkdir(cat(2,save_dir,'IMAGES/'))

% *** positions
fprintf('intializing position %5d of %5d',0,Npos);
for pos=1:Npos

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',pos,Npos);

  % create ana_dir
  pos_ana_dir=cat(2,save_dir,'POSITIONS/',num2str(pos-1,'%0.5d'),'/');
  mkdir(pos_ana_dir)

  % get images list for pos
  thepos=pos_List{pos,1};
    [~,Nchar]=size(thepos);
    if ~(strcmp(thepos(1,Nchar),'/'))
      thepos=cat(2,thepos,'/');
    end % if
  fileListBF=utils_FILEList(cat(2,thepos,chanBF,'/'),'tif');
  fileListBF=fileListBF([1:Nim]',1);
  save(cat(2,pos_ana_dir,'fileListBF.mat'),'fileListBF','-v7.3','-nocompression');

end % for pos
fprintf(' DONE! \n')

% *** images
fprintf('initializing image %5d of %5d',0,0)
for im=im_start:im_stop

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',im,Nim);

  im_ana_dir=cat(2,save_dir,'IMAGES/',num2str(im,'%05d'),'/');
  mkdir(im_ana_dir);

  fileListBF_pos=cell(Npos,1);
  for pos=1:Npos
    pos_ana_dir=cat(2,save_dir,'POSITIONS/',num2str(pos-1,'%0.5d'),'/');
    load(cat(2,pos_ana_dir,'fileListBF.mat'),'fileListBF');
    pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
    load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');
    ll=imidx_2_lidx(im,1);
    fileListBF_pos{pos,1}=fileListBF{ll,1};
  end % for pos

  save(cat(2,im_ana_dir,'fileListBF_pos.mat'),'fileListBF_pos','-v7.3','-nocompression');

end % for im
fprintf(' DONE ! \n')



% ***
% *** process raw AVG

fprintf('* RUN BrightField averaging : \n');

POOLOBJ=parpool('local',NBMAX,'IdleTimeout',120);
parfor im=im_start:im_stop
 BFbkg_rawAVG(ana_path,im);
end % par for
delete(POOLOBJ);

end % function
