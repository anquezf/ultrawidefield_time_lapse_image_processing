function [cells,LClist,BOUNDlist]=get_cellFEAT_V8(Nreg,mask,theimage,NL,NC,Xc,Yc,im,Lc_abs,Cc_abs,pixsize,p)

  %            1  2   3      4     	 5          6   7   8   9   10 
  %cell_List=[ X ,Y , imidx, ConvexArea, Intensity, L,  C,  wB, wS, p  ]
  %            um um  idx    Npix  	 a.u.       pix pix um  um  idx
  cells=zeros(Nreg,10);
  % LClist={ [L1,C1 ; L2,C2 ; ... LA,CA] ; ... }
  LClist=cell(Nreg,1);
  % BOUNDlist={ [Lb1,Cb1 ; Lb2,Cb2 ; ... Lbn,Cbn] ; ... }
  BOUNDlist=cell(Nreg,1);

  reg_props=regionprops(mask,'MajorAxisLength','MinorAxisLength','ConvexArea');

  mm=logical(zeros(NL,NC));
  
  for c=1:Nreg

    mm=(mask==c);
    Area=sum(mm(:));
    INTEN=(sum(theimage(mm))/Area);
    [Ll,Cl]=find(mm);
    L=mean(Ll); C=mean(Cl);
    X=( (C-Cc_abs)*pixsize )+Xc;
    Y=( -(L-Lc_abs)*pixsize )+Yc;

    B=bwboundaries(mm);
    %[B,mask_dummy,Nbound]=bwboundaries(mask_prev);
    [Nb,~]=size(B);
    if Nb>0
      % select biggest bound
      Npix_list=zeros(Nb,1);
      for b=1:Nb
        BLC=B{b,1};
        [Npix,~]=size(BLC(:,1));
        Npix_list(b,1)=Npix;
      end % for b
      [Npixmax,bsel]=max(Npix_list);
      BLC=B{bsel,1};
      % process WB,WS
    else
      BLC=[];
    end % if

    RP=reg_props(c,1);
    wB=(RP.MajorAxisLength)*pixsize;
    wS=(RP.MinorAxisLength)*pixsize;
    ConvexArea=(RP.ConvexArea);

    cells(c,:)=[X,Y,im,ConvexArea,INTEN,L,C,wB,wS,p];
    LClist{c,1}=cat(2,uint16(Ll),uint16(Cl));
    BOUNDlist{c,1}=uint16(BLC);

  end % for c

end % function
        

