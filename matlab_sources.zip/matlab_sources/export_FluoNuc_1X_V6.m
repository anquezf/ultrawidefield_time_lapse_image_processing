function export_FluoNuc_1X_V6(save_path,ana_path,Imaxi,bit_depth,dNL,dNC,deltaX_pix,deltaY_pix,NposX,NposY,posGRID,pNC,pNL,NL,NC,b0,delta_b,mu_cor,imoffset,FF_bkg,useFFforeg,FF_foreg,flipUD,flipLR,im)

warning off

theimage_d=zeros(dNL,dNC);

theimage=zeros(NL,NC);
pimage=zeros(pNL,pNC);

for posX=1:NposX
  for posY=1:NposY

    pos=posGRID(posY,posX);
    if ~isnan(pos)

      load(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/fileListN.mat'));
      load(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/imidx_2_lidx.mat'));

      % *** find idx
      idx=imidx_2_lidx(im,1);
      % *** load raw data
      theimage=double(imread(fileListN{idx,1}));
      theimage=(theimage-imoffset);
      % *** image restoration
      theimage=theimage-(b0+delta_b)*FF_bkg;
      if useFFforeg>0
        theimage=theimage./FF_foreg;
      end % if useFFforeg
      theimage=theimage-mu_cor;
      % flip ?
      if flipUD>0 theimage=flipud(theimage); end % if
      % flip ?
      if flipLR>0 theimage=fliplr(theimage); end % if

      pimage=imresize(theimage(deltaY_pix:NL,deltaX_pix:NC),[pNL,pNC]);

      lstart=(posY-1)*pNL+1;
      lstop=posY*pNL;
      cstart=(posX-1)*pNC+1;
      cstop=posX*pNC;
      theimage_d(lstart:lstop,cstart:cstop)=pimage;

    end % if

  end % for posY
end % for posX

mask=theimage_d<0;
theimage_d(mask)=0;
mask=theimage_d>Imaxi;
theimage_d(mask)=Imaxi;

if bit_depth==16
  theimage_out=(theimage_d/Imaxi)*65535;
  theimage_out=uint16(theimage_out);
else
  theimage_out=(theimage_d/Imaxi)*255;
  theimage_out=uint8(theimage_out);
end % if


save(cat(2,save_path,'nuc_images/1X/',num2str(im,'%05d'),'.mat'),'theimage_out','-v7.3','-nocompression');


end % fucntion

