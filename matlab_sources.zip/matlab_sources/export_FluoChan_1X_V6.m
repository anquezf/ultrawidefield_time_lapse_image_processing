function export_FluoChan_1X_V6(save_path,chanF,ana_path,Imini,Imaxi,bit_depth,dNL,dNC,deltaX_pix,deltaY_pix,NposX,NposY,posGRID,pNC,pNL,NL,NC,imoffset,FF_bkg,FF_foreg,b,useFF,useDNS,flipUD,flipLR,im)

warning off

theimage_d=zeros(dNL,dNC);

theimage=zeros(NL,NC);
pimage=zeros(pNL,pNC);

for posX=1:NposX
  for posY=1:NposY

    pos=posGRID(posY,posX);
    if ~isnan(pos)

      load(cat(2,ana_path,'Fluo_Ana/',chanF,'/positions_infos/',num2str(pos-1,'%05d'),'/imidx_2_lidx.mat'));
      ll=imidx_2_lidx(im,1);

      load(cat(2,ana_path,'Fluo_Ana/',chanF,'/positions_infos/',num2str(pos-1,'%05d'),'/fileListF.mat'));

      % *** load raw data
      theimage=double(imread(fileListF{ll,1}));
      theimage=(theimage-imoffset);
      % flip ?
      if flipUD>0 theimage=flipud(theimage); end % if
      % flip ?
      if flipLR>0 theimage=fliplr(theimage); end % if

      % *** pre proc DATA
      % *****************

      if useFF>0
        % remove background
        theimage=theimage-b*FF_bkg;
        % correct FF
        theimage=theimage./FF_foreg;
      else
        theimage=theimage-b;
      end % if useFF

      if useDNS>0 
        % denoise
        theimage=medfilt2(theimage,[3 3],'symmetric');
      end % if useDNS

      pimage=imresize(theimage(deltaY_pix:NL,deltaX_pix:NC),[pNL,pNC]);

      lstart=(posY-1)*pNL+1;
      lstop=posY*pNL;
      cstart=(posX-1)*pNC+1;
      cstop=posX*pNC;
      theimage_d(lstart:lstop,cstart:cstop)=pimage;

    end % if

  end % for posY
end % for posX


mask=theimage_d<Imini;
theimage_d(mask)=Imini;
mask=theimage_d>Imaxi;
theimage_d(mask)=Imaxi;

theimage_d=(theimage_d-Imini)/(Imaxi-Imini);

if bit_depth==16
  theimage_out=theimage_d*65535;
  theimage_out=uint16(theimage_out);
else
  theimage_out=theimage_d*255;
  theimage_out=uint8(theimage_out);
end % if

save(cat(2,save_path,chanF,'_images/1X/',num2str(im,'%05d'),'.mat'),'theimage_out','-v7.3','-nocompression');


end % fucntion

