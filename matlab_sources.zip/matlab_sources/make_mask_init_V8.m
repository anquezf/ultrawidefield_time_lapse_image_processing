function [mask_ini_neighbhd,Nreg]=make_mask_init_V8(filtered_image,theimage,NL,NC,Lmesh,Cmesh,ITH,delta_pix,radius)

FACTOR=1/50;


mm2=logical(zeros(NL,NC));
mm=logical(zeros(NL,NC));
Lmask=zeros(NL,NC);
Lmask2=zeros(NL,NC);

radius_sq=power(radius,2);

% *** find local maxima
mm2=logical(zeros(NL,NC));
mm=imregionalmax(filtered_image);
[Lmask,Ng]=bwlabel(mm);

% *** init outputrs to zeros
mask_ini_neighbhd=zeros(NL,NC); % small mask around local max


% *** select regions
Lc_list=[];
Cc_list=[];
Nreg=0;

for c=1:Ng

  % get locl infos
  mm=(Lmask==c);
  [Lc,Cc]=find(mm); Lc=mean(Lc); Cc=mean(Cc);
  lmin=max([(Lc-delta_pix),1]);
  lmax=min([(Lc+delta_pix),NL]);
  cmin=max([(Cc-delta_pix),1]);
  cmax=min([(Cc+delta_pix),NC]);
  data=theimage(lmin:lmax,cmin:cmax);

  Ifmax=filtered_image(Lc,Cc);

  % check and store
  if mean(data(:))>=ITH
    % new region
    Nreg=Nreg+1;
    % large mask around local max
    mm2=((power(Lmesh-Lc,2)+power(Cmesh-Cc,2))<radius_sq)&(filtered_image>(Ifmax*FACTOR));

    [Lmask2,NNN]=bwlabel(mm2);
    if NNN>1
      rrr=Lmask2(Lc,Cc);
      mm2=(Lmask2==rrr);
    end

    mask_ini_neighbhd(mm2)=1;
    
    Lc_list=cat(1,Lc_list,Lc);
    Cc_list=cat(1,Cc_list,Cc);
    
  end % if

end % for c


cid_map=make_cid_map_V7(Lc_list,Cc_list,NL,NC,Nreg,Cmesh,Lmesh);

% *** outputs
mask_ini_neighbhd=mask_ini_neighbhd.*cid_map;


end % funciton
