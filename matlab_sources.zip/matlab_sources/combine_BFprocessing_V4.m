function combine_BFprocessing_V4(ana_path)

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if



fprintf('* COMBINE BrightField Signals : \n');



% ***
% *** load data

fprintf('load data ...');

load(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata');
load(cat(2,ana_path,'Npos.mat'),'Npos');
[Ncell,~]=size(sorted_celldata);

%                  1    2        3
% sorted_cellBF = [BF , meanBF , stdBF]
sorted_cellBF=zeros(Ncell,8);

fprintf(' DONE! \n');



% ***
% *** positions

fprintf('combine position %5d of %5d',0,Npos);
for pos=1:Npos

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',pos,Npos);

  % create ana_dir
  pos_ana_dir=cat(2,ana_path,'BFproc/',num2str(pos-1,'%0.5d'),'/');

  load(cat(2,pos_ana_dir,'logiidx.mat'),'logiidx');
  load(cat(2,pos_ana_dir,'short_cellBF.mat'),'short_cellBF');

  sorted_cellBF(logiidx,:)=short_cellBF;

end % for pos
fprintf(' DONE! \n')

fprintf('save data ...')
save(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF','-v7.3','-nocompression');
fprintf(' DONE! \n');
