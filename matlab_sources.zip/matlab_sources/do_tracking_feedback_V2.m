function [isoptim,nit]=do_tracking_feedback_V2(ana_path,im)

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% *** INPUTS
% tracking params
track_path=cat(2,ana_path,'tracking/');
load(cat(2,track_path,'useWB.mat'),'useWB');
load(cat(2,track_path,'useWS.mat'),'useWS');
load(cat(2,track_path,'Lmax.mat'),'Lmax');
Lmax=single(Lmax);
load(cat(2,track_path,'WBSweight.mat'),'WBSweight');
WBSweight=single(WBSweight);
load(cat(2,track_path,'Nitemax.mat'),'Nitemax');

% *** load data

ROdir=cat(2,ana_path,'tracking_collision_feedback/');
ROcoll_dir=cat(2,ROdir,'collision_detection/');
ROtrack_dir=cat(2,ROdir,'linkage/');

save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');

load(cat(2,save_path,'short_celldata_c.mat'),'short_celldata_c');
load(cat(2,save_path,'short_celldata_p.mat'),'short_celldata_p');
short_celldata_c=single(short_celldata_c);
short_celldata_p=single(short_celldata_p);

load(cat(2,save_path,'Nc.mat'),'Nc');
load(cat(2,save_path,'Np.mat'),'Np');

% *** create cost

cost=build_cost_V5(short_celldata_c,short_celldata_p,Lmax,useWB,useWS,WBSweight);

attrib=seed_attrib_V3(cost,Lmax);

% *** do tracking

[attrib,nit]=linkage_V10(cost,attrib,Lmax,Nitemax);

% *** save data

save(cat(2,save_path,'attrib.mat'),'attrib','-v7.3','-nocompression');
save(cat(2,save_path,'nit.mat'),'nit','-v7.3','-nocompression');

if nit<Nitemax
  isoptim=1;
else
  isoptim=0;
end % if

end % function
