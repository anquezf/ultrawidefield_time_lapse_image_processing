function init_export_cellTRACK(ana_path)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'Npos.mat'),'Npos');
load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

mkdir(cat(2,ana_path,'vizu_cell_tracking/'));
mkdir(cat(2,ana_path,'data_vizucelltracking/'));

% load data
fprintf('load data ...')
load(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata');
load(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC');
load(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC');

load(cat(2,ana_path,'combined_data/celldata.mat'),'celldata');
load(cat(2,ana_path,'combined_data/cellmaskLC.mat'),'cellmaskLC');

% load removed celldata
rmvd_idxs=[];
for im=im_start:im_stop
  dup_ana_dir=cat(2,ana_path,'RMVDUP/',num2str(im,'%0.5d'),'/');
  load(cat(2,dup_ana_dir,'short_idx_rmvd.mat'),'short_idx_rmvd');
  rmvd_idxs=cat(1,rmvd_idxs,short_idx_rmvd);
end % for im

celldata_rmvd=celldata(rmvd_idxs,:);
cellmaskLC_rmvd=cellmaskLC(rmvd_idxs,1);

clear cellmaskLC
clear celldata

fprintf(' : DONE!\n')

number_CID=max(sorted_celldata(:,12));
dup_color=int8([255,0,0]);
save(cat(2,ana_path,'data_vizucelltracking/number_CID.mat'),'number_CID','-v7.3','-nocompression');
save(cat(2,ana_path,'data_vizucelltracking/dup_color.mat'),'dup_color','-v7.3','-nocompression');



cmap=zeros(number_CID,3,'int8');
fprintf('building colormap %5d of %5d',0,number_CID);
for cid=1:number_CID
  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',cid,number_CID);

  col=randi([1,3]);
  if col==1
    % blue
    cmap(cid,1)=int8(randi([0,60]));
    cmap(cid,2)=int8(randi([128,255]));
    cmap(cid,3)=int8(randi([128,255]));
  elseif col==2
    % yellow
    cmap(cid,1)=int8(randi([128,255]));
    cmap(cid,2)=int8(randi([128,255]));
    cmap(cid,3)=int8(randi([0,60]));
  elseif col==3
    % red
    cmap(cid,1)=int8(randi([128,255]));
    cmap(cid,2)=int8(randi([0,60]));
    cmap(cid,3)=int8(randi([128,255]));
  end % if
end % for cid
fprintf('\n')
save(cat(2,ana_path,'data_vizucelltracking/cmap.mat'),'cmap','-v7.3','-nocompression');



[Ncelltot,~]=size(sorted_celldata);

fprintf('intializing position %5d of %5d',0,Npos);
for pos=1:Npos

  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',pos,Npos);

  RO_ana_dir=cat(2,ana_path,'vizu_cell_tracking/',num2str(pos-1,'%0.5d'),'/');
  mkdir(RO_ana_dir);

  data_ana_dir=cat(2,ana_path,'data_vizucelltracking/',num2str(pos-1,'%0.5d'),'/');
  mkdir(data_ana_dir);

  % find cells appearing at p=pos-1
  % we also select the 'dup from this pos' : used for 'queue trajectory'
  logiidx=(sorted_celldata(:,10)==(pos-1))|(sorted_celldata(:,11)==(pos-1));

  short_scd=sorted_celldata(logiidx,:);
  short_mlc=sorted_cellmaskLC(logiidx,:);
  short_blc=sorted_cellboundLC(logiidx,:);

  save(cat(2,data_ana_dir,'short_scd.mat'),'short_scd','-v7.3','-nocompression');
  save(cat(2,data_ana_dir,'short_mlc.mat'),'short_mlc','-v7.3','-nocompression');
  save(cat(2,data_ana_dir,'short_blc.mat'),'short_blc','-v7.3','-nocompression');

  logiidx=(celldata_rmvd(:,10)==(pos-1));

  short_cd_rmvd=celldata_rmvd(logiidx,:);
  short_mlc_rmvd=cellmaskLC_rmvd(logiidx,:);

  save(cat(2,data_ana_dir,'short_cd_rmvd.mat'),'short_cd_rmvd','-v7.3','-nocompression');
  save(cat(2,data_ana_dir,'short_mlc_rmvd.mat'),'short_mlc_rmvd','-v7.3','-nocompression');

end % for pos
fprintf('\n')

end % funciton
