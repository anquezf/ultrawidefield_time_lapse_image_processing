function XYlist=loadXYlist_V2(XYlist_path)

XYlist=[];

fileID=fopen(XYlist_path);

textXY=0;
while ~(textXY==-1)

  % read line
  textXY=fgetl(fileID);
  % test end of line
  if ~(textXY==-1)
    % check for commas
    commaIDX=regexp(textXY,',');
    % find commas
    [~,NC]=size(commaIDX);
    if NC>0
      for c=1:NC
        textXY(1,commaIDX(1,c))='.';
      end % for c
    end % if
    % read coordinates
    XY=sscanf(textXY,'%f ; %f',[1 2]);
    XYlist=cat(1,XYlist,XY);
  end %if

end % while

% *** when I was sure there were no ',' !!!
%XY=fscanf(fileID,'%s')%,[1 2])
%while ~feof(fileID) 
%  XY=fscanf(fileID,'%f ; %f',[1 2])
%  XYlist=cat(1,XYlist,XY);
%end % while
    
fclose(fileID);

end % function
