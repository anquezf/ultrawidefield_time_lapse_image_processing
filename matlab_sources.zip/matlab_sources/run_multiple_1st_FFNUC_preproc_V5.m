function run_multiple_preprocessing_V5(save_dir,pad_dpix_str,fWFF_str,FFmini_str,deltai_str,imini_str,imaxi_str,fW1_str,fW2_str,Nsig_str,NBMAX_str)

warning off
FS=12;


fprintf('\n*** Please select A BUNCH of EXISTING experiments\n')
ana_path_list=uipickfiles('FilterSpec',save_dir)';
fprintf('\n');

[Nexpe,~]=size(ana_path_list);
for expe=1:Nexpe
  ana_path=ana_path_list{expe,1};
  [~,Nchar]=size(ana_path);
  if ~(strcmp(ana_path(1,Nchar),'/'))
    ana_path=cat(2,ana_path,'/');
  end % if
  ana_path_list{expe,1}=ana_path;
  fprintf(cat(2,ana_path,'\n'));
end % for exp


% **********************
% *** preproc params ***
% **********************


NBMAX=str2double(NBMAX_str);

deltai=str2double(deltai_str);
imaxi=str2double(imaxi_str);
imini=str2double(imini_str);
iedges=(imini:deltai:imaxi)';

Nsig=str2double(Nsig_str);

fW1=str2double(fW1_str);
fW2=str2double(fW2_str);

pad_dpix=str2double(pad_dpix_str);
fWFF=str2double(fWFF_str);
FFmini=str2double(FFmini_str);

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ********************* ***\n');
fprintf('*** SAVE input parameters ***\n');
fprintf('*** ********************* ***\n');
fprintf('\n');

for expe=1:Nexpe

  ana_path=ana_path_list{expe,1};

  save(cat(2,ana_path,'deltai.mat'),'deltai','-v7.3','-nocompression');
  save(cat(2,ana_path,'imaxi.mat'),'imaxi','-v7.3','-nocompression');
  save(cat(2,ana_path,'imini.mat'),'imini','-v7.3','-nocompression');
  save(cat(2,ana_path,'iedges.mat'),'iedges','-v7.3','-nocompression');

  save(cat(2,ana_path,'Nsig.mat'),'Nsig','-v7.3','-nocompression');

  save(cat(2,ana_path,'fW1.mat'),'fW1','-v7.3','-nocompression');
  save(cat(2,ana_path,'fW2.mat'),'fW2','-v7.3','-nocompression');

  save(cat(2,ana_path,'pad_dpix.mat'),'pad_dpix','-v7.3','-nocompression');
  save(cat(2,ana_path,'fWFF.mat'),'fWFF','-v7.3','-nocompression');
  save(cat(2,ana_path,'FFmini.mat'),'FFmini','-v7.3','-nocompression');

end %for expe




% ******************************
% *** some usefull variables ***
% ******************************

POOLOBJ=parpool('local',NBMAX,'IdleTimeout',360);

% 1st FF smoothing : NL,NC
ana_path=ana_path_list{1,1};
load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

% mesh grid
[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);

% pixsize
load(cat(2,ana_path,'pixsize.mat'));
fWFF_pix=fWFF/pixsize;

padded_image=zeros(3*NL,3*NC);

[Npts,~]=size(iedges);



% ***********************************
% *** 1st FFNUC multiple pre-proc ***
% ***********************************

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** **************************************** ***\n');
fprintf('*** MULTIPLE PRE-PROCESSING of 1st FLATFIELD ***\n');
fprintf('*** **************************************** ***\n');
fprintf('\n');



fprintf('\n')

fprintf('*** Nuclear 1st FlatField pre-estimate : \n');

for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* 1st FlatField - experiment %d : ',ana_path,'\n'),expe);

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- pre-processing of 1st FlatField NUC : ');

  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fprintf(fid,'\n');
  fclose(fid);


  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'1st FlatField preproc (');
  fprintf(fid,'fWFF (um) = ');
  fprintf(fid,num2str(fW2));
  fprintf(fid,';');
  fprintf(fid,'pad_dpix = ');
  fprintf(fid,num2str(pad_dpix));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);


  % *** load infos
  % ******************
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');


  % *** INIT
  % ******************
  % dir to store data
  save_dir=cat(2,ana_path,'estimate_1stFFNUC/');
  mkdir(save_dir);
  % go !
  fprintf('INITIALIZE 1st FlatField extraction...')
  parfor im=im_start:im_stop
    init_1stflatfield_extraction(ana_path,im);
  end % for im
  fprintf(' DONE ! \n')


  % *** Averaging
  % *************
  fprintf('RUN averaging ...')
  parfor im=im_start:im_stop
    FFNUC_1stFF_rawAVG(ana_path,im);
  end % par for
  fprintf(' DONE ! \n')


  % *** estimate weight of each image
  % *********************************
  scale_vs_im=ones(1,Nim);
  fprintf('ESTIMATE flatfields weights ...');
  for im=im_start:im_stop
    im_ana_dir=cat(2,ana_path,'estimate_1stFFNUC/',num2str(im,'%05d'),'/');
    load(cat(2,im_ana_dir,'rawAVG.mat'),'rawAVG');
    w=sum(rawAVG_cur(:));
    scale_vs_im(1,im)=w;
  end % for im
  % check for nNAN
  ll=isnan(scale_vs_im);
  ll2=(scale_vs_im<0);
  ll3=isinf(scale_vs_im);
  if sum(ll&ll2&ll3)==0
    scale_vs_im(1:im_start,1)=scale_vs_im(im_start,1);
    scale_vs_im(im_stop:Nim,1)=scale_vs_im(im_stop,1);
    scale_vs_im=smooth(scale_vs_im,10)';
    scale_vs_im=scale_vs_im/min(scale_vs_im(:));
  else
    scale_vs_im=ones(1,Nim);
  end % if sum(ll)==0
  save(cat(2,save_dir,'scale_vs_im.mat'),'scale_vs_im','-v7.3','-nocompression');
  fprintf(' DONE !\n');


  % *** combine averaged images
  % ***************************
  AVG=zeros(NL,NC);
  fprintf('COMBINE flatfields : image %5d of %5d',0,0)
  for im=im_start:im_stop
    % *** display status...
    for id=1:14
    fprintf('\b');
    end % for id
    fprintf('%5d of %5d',im,Nim);
    im_ana_dir=cat(2,save_dir,num2str(im,'%05d'),'/');
    load(cat(2,im_ana_dir,'rawAVG.mat'),'rawAVG');
    AVG=AVG+medfilt2(rawAVG,[3 3],'symmetric')*scale_vs_im(1,im);
  end % for im
  fprintf(' DONE ! \n')


  % *** smooth
  % **********
  fprintf('SMOOTH flatfield ...');
  % *** gaussian filter size FFfW
  padded_image=do_padding(AVG,pad_dpix,NL,NC,Lmesh,Cmesh);
  padded_image=imgaussfilt(padded_image,fWFF_pix);
  AVG_f=padded_image((NL+1):(2*NL),(NC+1):(2*NC));
  save(cat(2,save_dir,'AVG.mat'),'AVG','-v7.3','-nocompression');
  save(cat(2,save_dir,'AVG_f.mat'),'AVG_f','-v7.3','-nocompression');
  fprintf(' DONE ! \n')

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- pre-processing of 1st FlatField NUC ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for expe


% *** combnine EXPE
% *****************

fprintf('\n\n* Combine 1st FlatFields : experiment %5d of %5d',0,0);

FF=zeros(NL,NC);

for expe=1:Nexpe

  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',expe,Nexpe);

  ana_path=ana_path_list{expe,1};
  save_dir=cat(2,ana_path,'FFNUC_estimate/');
  load(cat(2,save_dir,'AVG_f.mat'),'AVG_f');
  FF=FF+AVG_f;

end % for exp

% *** filter and normalize
FF=FF/max(FF(:));

fprintf(' DONE ! \n')


% *** save FF for each EXPE
% *************************

% figure
hf=figure('Units','centimeters','PaperSize', [60 60],'visible','off');
ax=subplot(1,1,1);
set(ax,'FontSize',FS,'FontWeight','Bold');
xlabel(ax,'X (\mu m)','FontSize',FS,'FontWeight','Bold');
ylabel(ax,'Y (\mu m)','FontSize',FS,'FontWeight','Bold');
imagesc(ax,'XData',[0:(NC-1)]*pixsize,'YData',[0:(NL-1)]*pixsize,'CData',FF);
axis(ax,'equal');
axis(ax,[0 (NC-1)*pixsize 0 (NL-1)*pixsize]);
caxis(ax,[0 1]);
colormap(ax,hot);
colorbar;

% save loop
fprintf('\n * save experiments %5d of %5d',0,0);
for expe=1:Nexpe

  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',expe,Nexpe);

  ana_path=ana_path_list{expe,1};
  save(cat(2,ana_path,'FF_NUC.mat'),'FF','-v7.3','-nocompression');
  print(cat(2,ana_path,'FlatFieldCorrection_1st_estimate.png'),'-dpng','-r300');

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  t=now;
  fprintf(fid,' --- combined : ');
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fclose(fid);

end % for exp
fprintf(' DONE ! \n')

close(hf);





% ***************************************************************
% *** 1st SEGMENTATION : HISTO, image processing of bkg/foreg ***
% ***************************************************************

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ****************************************** ***\n');
fprintf('*** MULTIPLE PRE-PROCESSING BKG/FOREG Averages ***\n');
fprintf('*** ****************************************** ***\n');
fprintf('\n');


for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* 1st segmentation - experiment %d : ',ana_path,'\n'),expe);

  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');


  % *************************

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- pre-processing bkg/foreg averages : ');

  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fprintf(fid,'\n');
  fclose(fid);

  % *************************

  % *** HISTO
  % *********

  % *** write log file
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'pre_proc_HISTO_V7 (');
  fprintf(fid,'deltai = ');
  fprintf(fid,num2str(deltai));
  fprintf(fid,';');
  fprintf(fid,'imini = ');
  fprintf(fid,num2str(imini));
  fprintf(fid,';');
  fprintf(fid,'imaxi = ');
  fprintf(fid,num2str(imaxi));
  fprintf(fid,';');
  fprintf(fid,num2str(Nsig));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** RUN histo pre_proc
  fprintf('RUN pre-processing of histograms...')
  parfor pos=1:Npos
    pre_proc_HISTO_V8(ana_path,pos);
  end % for pos
  fprintf(' DONE ! \n')

  % *** COMBINE
  histo_all=zeros(Npts,Nim);
  fprintf('COMBINE histograms from position ...');
  for p=0:(Npos-1)
    fprintf('%5d of %5d',p+1,Npos);
    pos_ana_dir=cat(2,ana_path,'DATA/',num2str(p,'%0.5d'),'/');
    load(cat(2,pos_ana_dir,'histo.mat'),'histo')
    histo_all=histo_all+histo;
  end % for p
  fprintf('DONE ! \n');

  % *** global mean and std per image
  mu_all=zeros(1,Nim);
  mu_foreg_all=zeros(1,Nim);
  sig_all=zeros(1,Nim);
  A0=0;
  fprintf('ESTIMATE mu and sig for image ...',0,Nim);
  for im=im_start:im_stop
    % pdf
    n=histo_all(:,im);
    % mean/mode
    [A0,idxm]=max(n); idxm=idxm(1,1);
    mu0=iedges(idxm,1);
    % find std : 2*std at A0*0.1353 std at A0*0.6065
    [~,idxl]=min(abs(n(1:idxm,1)-0.6065*A0)); idxl=idxl(1,1);
    sig0=abs(max(mu0-iedges(idxl,1)));
    mu_all(1,im)=mu0;
    sig_all(1,im)=sig0;
    % *** get foreground mean
    ITH=mu0+Nsig*sig0;
    logiidx=iedges>ITH;
    mu0_foreg=sum(iedges(logiidx,1).*histo_all(logiidx,im))/sum(histo_all(logiidx,im));
    mu_foreg_all(1,im)=mu0_foreg;
  end % for im
  fprintf(' DONE ! \n');
  save_dir=cat(2,ana_path,'first_seg/');
  mkdir(save_dir);
  save(cat(2,save_dir,'mu_all.mat'),'mu_all','-v7.3','-nocompression');
  save(cat(2,save_dir,'mu_foreg_all.mat'),'mu_foreg_all','-v7.3','-nocompression');
  save(cat(2,save_dir,'sig_all.mat'),'sig_all','-v7.3','-nocompression');



  % *************************

  % *** 1st CELL SEG
  % ****************

  % *** write log file
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'preproc_NUC_bkg_foreg_V4 (');
  fprintf(fid,'fW1 = ');
  fprintf(fid,num2str(fW1));
  fprintf(fid,';');
  fprintf(fid,'fW2 = ');
  fprintf(fid,num2str(fW2));
  fprintf(fid,';');
  fprintf(fid,'Nsig = ');
  fprintf(fid,num2str(Nsig));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** pre-processing
  fprintf('RUN pre-processing of BKG/FOREG...')
  parfor pos=1:Npos
    preproc_NUC_bkg_foreg_V4(ana_path,pos);
  end % parfor
  fprintf(' DONE !\n');

  % *** combine
  save_dir=cat(2,ana_path,'NUC_BKG_FOREG/');
  mkdir(save_dir);

  fprintf('combine BKG/FOREG for all positions ...')
  parfor im=im_start:im_stop
    combine_nuc_bkg_foreg_V2(ana_path,im);
  end % parfor
  fprintf(' DONE !\n');


  % *************************

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   -------------  pre-processing bkg/foreg averages ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for exp







% ************************************************************************************************************************************************

% ******************************
% *** exctract BKG FlatField ***
% ******************************

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ******************************* ***\n');
fprintf('*** MULTIPLE exctract BKG FlatField ***\n');
fprintf('*** ******************************* ***\n');
fprintf('\n');


AVGtot=zeros(NL,NC);

BKG=zeros(NL,NC);
NBKG=zeros(NL,NC);
BKGAVG=zeros(NL,NC);
holes_mask=zeros(NL,NC,'logical');

FFtemp=zeros(NL,NC);
padded_image=zeros(3*NL,3*NC);

for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* load BKG FlatField - experiment %d : ',ana_path,'\n'),expe);

  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');


  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- exctract BKG FlatField : ');

  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fprintf(fid,'\n');
  fclose(fid);


  % *************************

  % *** load AVG
  % ************


  % *** write log file

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'exctract BKG FlatField (');
  fprintf(fid,'fWFF (um) = ');
  fprintf(fid,num2str(fWfw));
  fprintf(fid,';');
  fprintf(fid,'pad_dpix = ');
  fprintf(fid,num2str(pad_dpix));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** load data for expe

  BKG=zeros(NL,NC);
  NBKG=zeros(NL,NC);
  for im=im_start:im_stop
    save_dir=cat(2,ana_path,'NUC_BKG_FOREG/',num2str(im,'%05d'),'/');
    load(cat(2,save_dir,'cumu_BKG.mat'),'cumu_BKG');
    load(cat(2,save_dir,'Nfound_BKG.mat'),'Nfound_BKG');
    BKG=BKG+cumu_BKG;
    NBKG=NBKG+Nfound_BKG;
  end % for im 

  % *** repair holes

  BKGAVG=BKG./NBKG;
  FFtemp=BKGAVG/max(BKGAVG(:));
  holes_mask=(FFtemp<FFmini)&isnan(FFtemp)&isinf(FFtemp)&(NBKG==0);
  NN=sum(holes_mask(:));
  if NN>0
    if NN>(0.5*NL*NC)
      BKGAVG=zeros(NL,NC);
    else
      BKGAVG=repair_FF_hole(BKG,NBKG,holes_mask);
    end % if
  end % if

  if ~(NN>(0.5*NL*NC))
  % *** remove outliers
    BKGAVG=medfilt2(BKGAVG,[3 3],'symmetric');
  % *** LP filter
    padded_image=do_padding(BKGAVG,pad_dpix,NL,NC,Lmesh,Cmesh);
    padded_image=imgaussfilt(padded_image,FFfw_pix);
    BKGAVG=padded_image((NL+1):(2*NL),(NC+1):(2*NC));
  end % if

  % save data
  save_dir=cat(2,ana_path,'NUC_BKG_FOREG/');
  save(cat(2,save_dir,'BKG.mat'),'BKG','-v7.3','-nocompression');
  save(cat(2,save_dir,'NBKG.mat'),'NBKG','-v7.3','-nocompression');
  save(cat(2,save_dir,'BKGAVG.mat'),'BKGAVG','-v7.3','-nocompression');
  save(cat(2,save_dir,'holes_mask.mat'),'holes_mask','-v7.3','-nocompression');

  % store AVG
  AVGtot=AVGtot+BKGAVG;

end % for exp

fprintf('\n')

% *** filter and normalize
FF_bkg=AVGtot/max(AVGtot(:));



% *** save FF for each EXPE
% *************************

% figure
hf=figure('Units','centimeters','PaperSize', [60 60],'visible','off');
ax=subplot(1,1,1);
set(ax,'FontSize',FS,'FontWeight','Bold');
xlabel(ax,'X (\mu m)','FontSize',FS,'FontWeight','Bold');
ylabel(ax,'Y (\mu m)','FontSize',FS,'FontWeight','Bold');
imagesc(ax,'XData',[0:(NC-1)]*pixsize,'YData',[0:(NL-1)]*pixsize,'CData',FF_bkg);
axis(ax,'equal');
axis(ax,[0 (NC-1)*pixsize 0 (NL-1)*pixsize]);
caxis(ax,[0 1]);
colormap(ax,hot);
colorbar;

% save loop
fprintf('\n * save BKG FlatField and measure b0 for experiment %5d of %5d',0,0);
for expe=1:Nexpe

  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',expe,Nexpe);

  ana_path=ana_path_list{expe,1};
  save(cat(2,ana_path,'FF_bkg.mat'),'FF_bkg','-v7.3','-nocompression');
  print(cat(2,ana_path,'FlatFieldCorrection_FFbkg.png'),'-dpng','-r300');

  save_dir=cat(2,ana_path,'NUC_BKG_FOREG/');
  save(cat(2,save_dir,'BKGAVG_tot.mat'),'AVGtot','-v7.3','-nocompression');

  save_dir=cat(2,ana_path,'NUC_BKG_FOREG/');
  load(cat(2,save_dir,'BKG.mat'),'BKG');
  load(cat(2,save_dir,'NBKG.mat'),'NBKG');
  load(cat(2,save_dir,'holes_mask.mat'),'holes_mask');
  b0=mean( (BKG(~holes_mak)./NBKG(~holes_mask))./FF_bkg(~holes_mask) );
  save(cat(2,ana_path,'b0.mat'),'b0','-v7.3','-nocompression');

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  t=now;
  fprintf(fid,' --- combined : ');
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fclose(fid);

end % for exp
fprintf(' DONE ! \n')

close(hf);


for expe=1:Nexpe

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* estimate delta_b(t) - experiment %d : ',ana_path,'\n'),expe);

  load(cat(2,ana_path,'b0.mat'),'b0');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');


  % *************************

  % *** get delta_b vsim
  % ********************

  delta_b_vsim=zeros(1,Nim)

  for im=im_start:im_stop
    save_dir=cat(2,ana_path,'NUC_BKG_FOREG/',num2str(im,'%05d'),'/');
    load(cat(2,save_dir,'cumu_BKG.mat'),'cumu_BKG');
    load(cat(2,save_dir,'Nfound_BKG.mat'),'Nfound_BKG');

    BKGAVG=cumu_BKG./Nfound_BKG;
    FFtemp=BKGAVG/max(BKGAVG(:));
    holes_mask=(FFtemp<FFmini)&isnan(FFtemp)&isinf(FFtemp)&(Nfound_BKG==0);
    
    delta_b_vsim(1,im)=mean((cumu_BKG(~holes_mak)./Nfound_BKG(~holes_mask))./FF_bkg(~holes_mask))-b0;
  end % for im 

  save(cat(2,ana_path,'delta_b_vsim.mat'),'delta_b_vsmim','-v7.3','-nocompression');


  % *************************

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- exctract BKG FlatField ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

  
end % for expe






% ************************************************************************************************************************************************

% ********************************
% *** exctract FOREG FlatField ***
% ********************************

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ********************************* ***\n');
fprintf('*** MULTIPLE exctract FOREG FlatField ***\n');
fprintf('*** ********************************* ***\n');
fprintf('\n');

AVGtot=zeros(NL,NC);

FOREG=zeros(NL,NC);
NFOREG=zeros(NL,NC);
FOREAVG=zeros(NL,NC);
holes_mask_foreg=zeros(NL,NC,'logical');

FFtemp=zeros(NL,NC);
padded_image=zeros(3*NL,3*NC);

for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* load FOREG FlatField - experiment %d : ',ana_path,'\n'),expe);

  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');
  load(cat(2,ana_path,'b0.mat'),'b0');
  load(cat(2,ana_path,'delta_b_vsim.mat'),'delta_b_vsim');

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- exctract FOREG FlatField : ');

  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fprintf(fid,'\n');
  fclose(fid);


  % *************************

  % *** load AVG
  % ************


  % *** write log file

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'exctract FOREG FlatField (');
  fprintf(fid,'fWFF (um) = ');
  fprintf(fid,num2str(FFfw));
  fprintf(fid,';');
  fprintf(fid,'pad_dpix = ');
  fprintf(fid,num2str(pad_dpix));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** load data for expe

  FOREG=zeros(NL,NC);
  NFOREG=zeros(NL,NC);
  for im=im_start:im_stop
    save_dir=cat(2,ana_path,'NUC_BKG_FOREG/',num2str(im,'%05d'),'/');
    load(cat(2,save_dir,'cumu_FOREG.mat'),'cumu_BKG');
    load(cat(2,save_dir,'Nfound_FOREG.mat'),'Nfound_BKG');
    FOREG=FOREG-Nfound_FOREG.*( (b0+delta_b_vsim(1,im))*FF_bkg );
    NFOREG=NFOREG+Nfound_FOREG;
  end % for im 

  % *** repair holes

  FOREGAVG=FOREG./NFOREG;
  FFtemp=FOREGAVG/max(FOREGAVG(:));
  holes_mask_foreg=(FFtemp<FFmini)&isnan(FFtemp)&isinf(FFtemp)&(NFOREG==0);
  NN=sum(holes_mask(:));
  if NN>0
    if NN>(0.5*NL*NC)
      FOREGAVG=zeros(NL,NC);
    else
      FOREGAVG=repair_FF_hole(FOREG,NFOREG,holes_mask_foreg);
    end % if
  end % if

  if ~(NN>(0.5*NL*NC))
  % *** remove outliers
    FOREGAVG=medfilt2(FOREGAVG,[3 3],'symmetric');
  % *** LP filter
    padded_image=do_padding(FOREGAVG,pad_dpix,NL,NC,Lmesh,Cmesh);
    padded_image=imgaussfilt(padded_image,FFfw_pix);
    FOREGAVG=padded_image((NL+1):(2*NL),(NC+1):(2*NC));
  end % if

  % save data
  save_dir=cat(2,ana_path,'NUC_BKG_FOREG/');
  save(cat(2,save_dir,'FOREG.mat'),'FOREG','-v7.3','-nocompression');
  save(cat(2,save_dir,'NFOREG.mat'),'NFOREG','-v7.3','-nocompression');
  save(cat(2,save_dir,'FOREGAVG.mat'),'FOREGAVG','-v7.3','-nocompression');
  save(cat(2,save_dir,'holes_mask_foreg.mat'),'holes_mask_foreg','-v7.3','-nocompression');

  % store AVG
  AVGtot=AVGtot+FOREGAVG;

end % for exp

fprintf('\n')

% *** filter and normalize
FF_foreg=AVGtot/max(AVGtot(:));



% *** save FF for each EXPE
% *************************

% figure
hf=figure('Units','centimeters','PaperSize', [60 60],'visible','off');
ax=subplot(1,1,1);
set(ax,'FontSize',FS,'FontWeight','Bold');
xlabel(ax,'X (\mu m)','FontSize',FS,'FontWeight','Bold');
ylabel(ax,'Y (\mu m)','FontSize',FS,'FontWeight','Bold');
imagesc(ax,'XData',[0:(NC-1)]*pixsize,'YData',[0:(NL-1)]*pixsize,'CData',FF_foreg);
axis(ax,'equal');
axis(ax,[0 (NC-1)*pixsize 0 (NL-1)*pixsize]);
caxis(ax,[0 1]);
colormap(ax,hot);
colorbar;

% save loop
fprintf('\n * save FOREG FlatField for experiment %5d of %5d',0,0);
for expe=1:Nexpe

  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',expe,Nexpe);

  ana_path=ana_path_list{expe,1};
  save(cat(2,ana_path,'FF_foreg.mat'),'FF_foreg','-v7.3','-nocompression');
  print(cat(2,ana_path,'FlatFieldCorrection_FFforeg.png'),'-dpng','-r300');

  save_dir=cat(2,ana_path,'NUC_BKG_FOREG/');
  load(cat(2,save_dir,'FOREGAVG_tot.mat'),'AVGtot');

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  t=now;
  fprintf(fid,' --- combined : ');
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fclose(fid);

  % *************************

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- exctract FOREG FlatField ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for exp
fprintf(' DONE ! \n')

close(hf);







% ************************************************************************************************************************************************

% ************************
% *** CORRECTED HISTO  ***
% ************************


fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ************************************ ***\n');
fprintf('*** MULTIPLE PRE-PROCESSING of HISTOGRAM ***\n');
fprintf('*** ************************************ ***\n');
fprintf('\n');


fprintf('\n\n')

fprintf('*** PROCESS corrected HISTOGRAMS  \n');


for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* corrected HISTO - experiment %d : ',ana_path,'\n\n'),expe);

  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');
  load(cat(2,ana_path,'b0.mat'),'b0');
  load(cat(2,ana_path,'delta_b_vsim.mat'),'delta_b_vsim');

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- pre-processing of corrected HISTO : ');

  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fprintf(fid,'\n');
  fclose(fid);

  % *** HISTO
  % *********

  % *** write log file

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'preproc_corrected_HISTO_V9 : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** run
  fprintf('compute corrected HISTO...');
  parfor pos=1:Npos
    preproc_corrected_HISTO_V9(ana_path,pos);
  end % parfor pos
  fprintf(' DONE ! \n');

  % combine
  cor_histo_all=zeros(Npts,Nim);
  fprintf('combine corrected HISTO for position ...');
  for pos=1:Npos
    pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
    load(cat(2,pos_ana_dir,'histo_cor.mat'),'histo_cor');
    cor_histo_all=cor_histo_all+histo_cor;
  end % for pos
  fprintf(' DONE ! \n');


  % *** global mean and std per image
  % ***
  mu_cor_all=zeros(1,Nim);
  sig_cor_all=zeros(1,Nim);
  A0=0;
  fprintf('ESTIMATE corrected mu and sig for image %5d of %5d',0,Nim);
  for im=im_start:im_stop
    % *** display status...
    for id=1:14
    fprintf('\b');
    end % for id
    fprintf('%5d of %5d',im,Nim);
    % pdf
    n=cor_histo_all(:,im);
    % mean/mode
    [A0,idxm]=max(n); idxm=idxm(1,1);
    mu0=iedges(idxm,1);
    % find std : 2*std at A0*0.1353 std at A0*0.6065
    [~,idxl]=min(abs(n(1:idxm,1)-0.6065*A0)); idxl=idxl(1,1);
    sig0=abs(max(mu0-iedges(idxl,1)));
    mu_cor_all(1,im)=mu0;
    sig_cor_all(1,im)=sig0;
  end % for im
  
  % save
  save(cat(2,ana_path,'cor_histo_all.mat'),'cor_histo_all','-v7.3','-nocompression');
  save(cat(2,ana_path,'mu_cor_all.mat'),'mu_cor_all','-v7.3','-nocompression');
  save(cat(2,ana_path,'sig_cor_all.mat'),'sig_cor_all','-v7.3','-nocompression');
  fprintf(' DONE ! \n');

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- pre-processing of corrected HISTO ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for expe




fprintf('\n\n\n We have pre-processed %5d experiments... GOODLUCK !\n',Nexpe);
delete(POOLOBJ);
fprintf('\n\n');


end % funciton


