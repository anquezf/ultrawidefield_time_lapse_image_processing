function init_1stflatfield_extraction(ana_path,im)

warning off

load(cat(2,ana_path,'Npos.mat'),'Npos');

save_dir=cat(2,ana_path,'estimate_1stFFNUC/');
im_ana_dir=cat(2,save_dir,num2str(im,'%05d'),'/');
mkdir(im_ana_dir);

fileListN_pos=cell(Npos,1);
for pos=1:Npos
  pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
  load(cat(2,pos_ana_dir,'fileListN.mat'),'fileListN');
  load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');
  ll=imidx_2_lidx(im,1);
  fileListN_pos{pos,1}=fileListN{ll,1};
end % for pos

save(cat(2,im_ana_dir,'fileListN_pos.mat'),'fileListN_pos','-v7.3','-nocompression');

end % funciton
