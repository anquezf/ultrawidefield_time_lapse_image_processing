function run_duplicate_removal_V6(ana_path,Dborder_str,Lmax_str,SOVTH_str,NBMAX_str)

fprintf('RUN removal of duplicates...\n')

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

warning off

tstart=now;

% *** inputs

Dborder=str2double(Dborder_str);
Lmax=str2double(Lmax_str);
SOVTH=str2double(SOVTH_str);

save(cat(2,ana_path,'Dborder.mat'),'Dborder','-v7.3','-nocompression');
save(cat(2,ana_path,'Lmax.mat'),'Lmax','-v7.3','-nocompression');
save(cat(2,ana_path,'SOVTH.mat'),'SOVTH','-v7.3','-nocompression');

NBMAX=str2double(NBMAX_str);

load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

POOLOBJ=parpool('local',NBMAX,'IdleTimeout',360);

parfor im=im_start:im_stop

  remove_duplicates_V4(ana_path,im,Dborder,Lmax,SOVTH);

end % for im

delete(POOLOBJ);

fprintf('duplicates removal : DONE ! \n')
fprintf('\n');

exit(0)

end % function
