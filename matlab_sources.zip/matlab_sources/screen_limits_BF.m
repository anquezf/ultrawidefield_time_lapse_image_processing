function [Imaxi,Imini]=screen_limits_BF(ana_path,pos,Nsig_BF,im_start,im_stop)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

pos_ana_dir=cat(2,ana_path,'BFbkg_estimate/POSITIONS/',num2str(pos-1,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'mu_bf_vs_im.mat'),'mu_bf_vs_im');
load(cat(2,pos_ana_dir,'sig_bf_vs_im.mat'),'sig_bf_vs_im');

I_vs_im=mu_bf_vs_im(1,im_start:im_stop)+Nsig_BF*sig_bf_vs_im(1,im_start:im_stop);
Imaxi=max(I_vs_im,[],'omitnan');

I_vs_im=mu_bf_vs_im(1,im_start:im_stop)-Nsig_BF*sig_bf_vs_im(1,im_start:im_stop);
Imini=min(I_vs_im,[],'omitnan');

end % fucntion
