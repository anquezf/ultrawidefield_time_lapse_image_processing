function export_nuc_SEG_V6(save_path,NposX,NposY,sorted_celldata,sorted_cellboundLC,pixsize,Lc_abs,Cc_abs,posGRID,Xgrid,Ygrid,NMAG,MAG_list,blctoskip_list,im)

warning off;

[Ncell,~]=size(sorted_celldata);
idxs=[1:Ncell]';
ll=zeros(Ncell,1,'logical');

for posX=1:NposX

  for posY=1:NposY

    pos=posGRID(posY,posX);
    if ~isnan(pos)

      ll=(sorted_celldata(:,10)==(pos-1))&(sorted_celldata(:,3)==im);
      scd_idxlist=idxs(ll,1);
      cid_list=sorted_celldata(ll,12);

      save(cat(2,save_path,'nuc_masks/',num2str(pos),'/',num2str(im),'/scd_idxlist.mat'),'scd_idxlist','-v7.3','-nocompression');
      save(cat(2,save_path,'nuc_masks/',num2str(pos),'/',num2str(im),'/cid_list.mat'),'cid_list','-v7.3','-nocompression');

      BLC_list=sorted_cellboundLC(ll,:);
      NN=sum(ll);

      Xc=Xgrid(posY,posX);
      Yc=Ygrid(posY,posX);

      XYlist_temp=cell(NN,1);
      for c=1:NN
        BLC=double(BLC_list{c,1});
        [Npix,~]=size(BLC);
        XY=zeros(Npix,2);
        XY(:,2)=Yc-(BLC(:,1)-Lc_abs)*pixsize;
        XY(:,1)=Xc+(BLC(:,2)-Cc_abs)*pixsize;
        XY=single(XY);
        XYlist_temp{c,1}=XY;
      end % for c

     
      for m=1:NMAG

        boundXY_list=cell(NN,1);
        toskip=blctoskip_list(1,m);

        if toskip>0

          for c=1:NN

            XY=XYlist_temp{c,1};
            [Npix,~]=size(XY);
          
            Npix2=floor((Npix-1)/toskip);
            boundXY=zeros(Npix2+1,2,'single');
            for pix=1:(Npix2+1)
              boundXY(pix,:)=XY(1+(pix-1)*toskip,:);
            end % for pix
            if ~( (boundXY(Npix2+1,1)==XY(Npix,1))&(boundXY(Npix2+1,2)==XY(Npix,2)) )
              boundXY=cat(1,boundXY,boundXY(1,:));
            end % if
            boundXY_list{c,1}=boundXY;

          end % for c

        else

          boundXY_list=XYlist_temp;

        end % if toskip>0

        MAG=MAG_list(1,m);
        save(cat(2,save_path,'nuc_masks/',num2str(pos),'/',num2str(im),'/',num2str(MAG),'/boundXY_list.mat'),'boundXY_list','-v7.3','-nocompression');
      
      end % for m

    end % if ~isnan(pos)

  end % for posY

end % for posX

end % funciton
      


  

