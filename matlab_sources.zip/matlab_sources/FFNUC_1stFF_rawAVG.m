function FFNUC_1stFF_rawAVG(ana_path,im)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if
save_dir=cat(2,ana_path,'estimate_1stFFNUC/');

load(cat(2,ana_path,'Npos.mat'),'Npos');
load(cat(2,ana_path,'imoffset.mat'));

load(cat(2,ana_path,'NL.mat'));
load(cat(2,ana_path,'NC.mat'));
rawAVG=zeros(NL,NC);

im_ana_dir=cat(2,save_dir,num2str(im,'%05d'),'/');
load(cat(2,im_ana_dir,'fileListN_pos.mat'),'fileListN_pos');

for pos=1:Npos

  theimage=double(imread(fileListN_pos{pos,1}));
  theimage=theimage-imoffset;

  rawAVG=rawAVG+theimage;

end % for pos

rawAVG=rawAVG/Npos;
save(cat(2,im_ana_dir,'rawAVG.mat'),'rawAVG','-v7.3','-nocompression');

end % function
