function AVG_out=repair_FF_hole_V2(CUMU,Nfound,holes_mask)

AVG_out=CUMU./Nfound;

[Lmask,Nreg]=bwlabel(holes_mask>0);

if Nreg>0

  se=strel('disk',2);
  se2=strel('disk',4);

  for reg=1:Nreg
    mask1=(Lmask==reg);
    mask2=imdilate(mask1,se);
    mask2=mask2&(~mask1)&(~holes_mask);
    if sum(mask2(:)>0)
      MED=median(AVG_out(mask2));
      AVG_out(mask1)=MED;
    else
      mask2=imdilate(mask1,se2);
      mask2=mask2&(~mask1)&(~holes_mask);
      if sum(mask2(:)>0)
        MED=median(AVG_out(mask2));
        AVG_out(mask1)=MED;
      else
        AVG_out(mask1)=1;
      end % if sum(mask2(:)>0)
    end % if sum(mask2(:)>0)
  end % for reg;

end % if

end % funciton
