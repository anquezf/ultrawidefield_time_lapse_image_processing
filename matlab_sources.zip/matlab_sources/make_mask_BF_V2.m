function maskBF=make_mask_BF_V2(celldata,Ncell,NL,NC,Lmesh,Cmesh,radius_sq)

maskBF=zeros(NL,NC);

cid_map=make_cid_map_V7(round(celldata(:,6)),round(celldata(:,7)),NL,NC,Ncell,Cmesh,Lmesh);

mm=zeros(NL,NC,'logical');
mm2=zeros(NL,NC);

for c=1:Ncell
  Lc=round(celldata(c,6));
  Cc=round(celldata(c,7));
  mm2=mm2+((power(Lmesh-Lc,2)+power(Cmesh-Cc,2))<radius_sq);
end % for c
mm=mm2>0;

maskBF=mm.*cid_map;

end % funciton
