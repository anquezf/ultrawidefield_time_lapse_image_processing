function run_build_shape_param_histos(ana_path,NBMAX_str)

fprintf('RUN building of shape params histograms ...\n')

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

warning off

% *** inputs
NBMAX=str2double(NBMAX_str);

load(cat(2,ana_path,'Nim.mat'),'Nim');


POOLOBJ=parpool('local',NBMAX);
parfor im=1:Nim
  build_shape_param_histos(ana_path,im);
end % for im
delete(POOLOBJ);


fprintf('shape params histograms built : DONE ! \n')
fprintf('\n');



fprintf('COMBINE Int. vs Area histograms ...\n')
clean_ana_dir=cat(2,ana_path,'CLEANCELLDATA/');
load(cat(2,clean_ana_dir,'edgesI.mat'),'edgesI');
load(cat(2,clean_ana_dir,'edgesA.mat'),'edgesA');

[NptsI,~]=size(edgesI);
[NptsA,~]=size(edgesA);
HISTO2D_IA=zeros(NptsA,NptsI);
HISTO2D=zeros(NptsA,NptsI);
HISTO1D_I=zeros(NptsI,1);
HI=zeros(NptsI,1);
HISTO1D_A=zeros(NptsA,1);
HA=zeros(NptsA,1);

fprintf('add data from image %5d of %5d',0,Nim);
for im=1:Nim

  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',im,Nim);

  clean_ana_dir=cat(2,ana_path,'CLEANCELLDATA/',num2str(im,'%0.5d'),'/');

  load(cat(2,clean_ana_dir,'HI.mat'),'HI');
  load(cat(2,clean_ana_dir,'HA.mat'),'HA');
  load(cat(2,clean_ana_dir,'HISTO2D.mat'),'HISTO2D');

  HISTO2D_IA=HISTO2D_IA+HISTO2D;
  HISTO1D_I=HISTO1D_I+HI;
  HISTO1D_A=HISTO1D_A+HA;

end % for im
fprintf('\n')

fprintf('histograms COMBINED !\n')


fprintf('saving data ...')
clean_ana_dir=cat(2,ana_path,'CLEANCELLDATA/');
save(cat(2,clean_ana_dir,'HISTO1D_I.mat'),'HISTO1D_I','-v7.3','-nocompression');
save(cat(2,clean_ana_dir,'HISTO1D_A.mat'),'HISTO1D_A','-v7.3','-nocompression');
save(cat(2,clean_ana_dir,'HISTO2D_IA.mat'),'HISTO2D_IA','-v7.3','-nocompression');
fprintf(': DONE ! \n')

exit(0)


end % function
