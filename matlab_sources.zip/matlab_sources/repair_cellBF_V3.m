function newcellBF=repair_cellBF_V3(ana_path,sorted_celldata,idx_to_repair,idxlist_rmvd)

% info on cell to repair
p=sorted_celldata(idx_to_repair,10);
im=sorted_celldata(idx_to_repair,3);

[Ncell,~]=size(sorted_celldata);

logiidx=zeros(Ncell,1,'logical');
idxs=[1:Ncell]';
logiidx=(sorted_celldata(:,3)==im)&(sorted_celldata(:,10)==p);
NN=sum(logiidx);
idxlist=idxs(logiidx,1);

% set idx_to_repair in first position
ll=(idxlist==idx_to_repair);
idxtemp=idxlist(1,1);
idxlist(ll,1)=idxtemp;
idxlist(1,1)=idx_to_repair;

% remove cells to remove ...
idxlist_sel=idx_to_repair;
NNtot=1;
for c=2:NN
  ll=(idxlist(c,1)==idxlist_rmvd);
  if sum(ll)==0
    idxlist_sel=cat(1,idxlist_sel,idxlist(c,1));
    NNtot=NNtot+1;
  end % if
end % for c

% make maskBF
load(cat(2,ana_path,'pixsize.mat'));
load(cat(2,ana_path,'fW2.mat'));
radius_sq=power(fW2/pixsize,2);
load(cat(2,ana_path,'NL.mat'));
load(cat(2,ana_path,'NC.mat'));
theimage=zeros(NL,NC);
maskBF=zeros(NL,NC);
[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);

maskBF=make_mask_BF_V2(sorted_celldata(idxlist_sel,:),NNtot,NL,NC,Lmesh,Cmesh,radius_sq);


% Bf histo
save_dir=cat(2,ana_path,'BFbkg_estimate/');
pos_ana_dir=cat(2,save_dir,'POSITIONS/',num2str(p,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'mu_bf_vs_im.mat'),'mu_bf_vs_im');
load(cat(2,pos_ana_dir,'sig_bf_vs_im.mat'),'sig_bf_vs_im');
load(cat(2,ana_path,'Nsig_BF.mat'),'Nsig_BF');

mu0=mu_bf_vs_im(1,im);
sig0=sig_bf_vs_im(1,im);
lim_mini=mu0-Nsig_BF*sig0;
lim_maxi=mu0+Nsig_BF*sig0;


load(cat(2,ana_path,'imoffset.mat'),'imoffset');
load(cat(2,ana_path,'flipUD.mat'),'flipUD');
load(cat(2,ana_path,'flipLR.mat'),'flipLR');

% load BFavg
im_ana_dir=cat(2,save_dir,'IMAGES/',num2str(im,'%05d'),'/');
load(cat(2,im_ana_dir,'BFrawAVG.mat'),'BFrawAVG');

% load raw data
save_dir=cat(2,ana_path,'BFbkg_estimate/');
pos_ana_dir=cat(2,save_dir,'POSITIONS/',num2str(p,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'fileListBF.mat'),'fileListBF');

pos_ana_dir=cat(2,ana_path,'DATA/',num2str(p,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');

ll=imidx_2_lidx(im,1);

% *** load raw data
theimage=double(imread(fileListBF{ll,1}));
theimage=(theimage-imoffset)-BFrawAVG;
% flip ?
if flipUD>0 theimage=flipud(theimage); end % if
% flip ?
if flipLR>0 theimage=fliplr(theimage); end % if


% process data
newcellBF=zeros(1,8);

[Ll,Cl]=find(maskBF==1);
[Npix,~]=size(Ll);
BFdata=zeros(Npix,1);
for pix=1:Npix BFdata(pix,1)=theimage(Ll(pix,1),Cl(pix,1)); end % for pix

%                  1    2               3              4           5        6           7        8
% sorted_cellBF = [BF , meanBF (vsim) , stdBF (vsim) , Npix_mini , BFmini , Npix_maxi , BFmaxi , BFAREA]
newcellBF(1,1)=sum(BFdata(:))/Npix;

ll=BFdata<lim_mini;
Npix_mini=sum(ll);
BFmini=sum(BFdata(ll,1))/Npix_mini;
newcellBF(1,4)=Npix_mini;
newcellBF(1,5)=BFmini;

ll=BFdata>lim_maxi;
Npix_maxi=sum(ll);
BFmaxi=sum(BFdata(ll,1))/Npix_maxi;
newcellBF(1,6)=Npix_maxi;
newcellBF(1,7)=BFmaxi;

newcellBF(1,8)=Npix;

end % function
