function prepare_tracking_feedback_V2(ana_path)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if


ROdir=cat(2,ana_path,'tracking_collision_feedback/');
ROcoll_dir=cat(2,ROdir,'collision_detection/');
ROtrack_dir=cat(2,ROdir,'linkage/');

load(cat(2,ana_path,'Nim.mat'));

% *************
% *** load data
% *************

fprintf('load data ... ');

load(cat(2,ROdir,'sorted_celldata.mat'),'sorted_celldata');
load(cat(2,ROdir,'sorted_cellboundLC.mat'),'sorted_cellboundLC');
load(cat(2,ROdir,'sorted_cellmaskLC.mat'),'sorted_cellmaskLC');
[Nscd_tot,~]=size(sorted_celldata);

celldata_FB=sorted_celldata(:,1:11);
cellboundLC_FB=sorted_cellboundLC;
cellmaskLC_FB=sorted_cellmaskLC;
clear sorted_celldata
clear sorted_cellboundLC
clear sorted_cellmaskLC

new_celldata=[];
new_cellboundLC={};
new_cellmaskLC={};

fprintf(' DONE ! -> ');

% ***************
% *** create data
% ***************

fprintf('repair collisions ...');
for im=Nim:-1:2

   save_path=cat(2,ROcoll_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');

  % ***********************
  % *** load collision data
  % ***********************

  load(cat(2,save_path,'Ncorr.mat'),'Ncorr');
  load(cat(2,save_path,'corrected_celldata.mat'),'corrected_celldata');
  load(cat(2,save_path,'corrected_cellboundLC.mat'),'corrected_cellboundLC');
  load(cat(2,save_path,'corrected_cellmaskLC.mat'),'corrected_cellmaskLC');
  load(cat(2,save_path,'corrected_idx.mat'),'corrected_idx');

  load(cat(2,save_path,'Ncolli.mat'),'Ncolli');
  load(cat(2,save_path,'collider_celldata.mat'),'collider_celldata');
  load(cat(2,save_path,'collider_cellboundLC.mat'),'collider_cellboundLC');
  load(cat(2,save_path,'collider_cellmaskLC.mat'),'collider_cellmaskLC');

  load(cat(2,save_path,'Nrscd.mat'),'Nrscd');
  load(cat(2,save_path,'rescued_celldata.mat'),'rescued_celldata');
  load(cat(2,save_path,'rescued_cellboundLC.mat'),'rescued_cellboundLC');
  load(cat(2,save_path,'rescued_cellmaskLC.mat'),'rescued_cellmaskLC');

  % *******************
  % *** add and correct
  % *******************

  if Ncorr>0
    for cor=1:Ncorr
      idx=corrected_idx(cor,1);
      celldata_FB(idx,:)=corrected_celldata(cor,:);
      cellboundLC_FB{idx,1}=corrected_cellboundLC{cor,1};
      cellmaskLC_FB{idx,1}=corrected_cellmaskLC{cor,1};
    end % for cor
  end % if

  Nnew=Ncolli+Nrscd;
  if Ncolli>0
    new_celldata=cat(1,new_celldata,collider_celldata);
    new_cellboundLC=cat(1,new_cellboundLC,collider_cellboundLC);
    new_cellmaskLC=cat(1,new_cellmaskLC,collider_cellmaskLC);
  end % if
  if Nrscd>0
    new_celldata=cat(1,new_celldata,rescued_celldata);
    new_cellboundLC=cat(1,new_cellboundLC,rescued_cellboundLC);
    new_cellmaskLC=cat(1,new_cellmaskLC,rescued_cellmaskLC);
  end % if

end % for im
fprintf(' DONE ! -> \n')

clear collider_celldata
clear collider_cellmaskLC
clear collider_cellboundLC

clear rescued_celldata
clear rescued_cellmaskLC
clear rescued_cellboundLC

clear corrected_celldata
clear corrected_cellmaskLC
clear corrected_cellboundLC

% *****************
% *** add new cells
% *****************

fprintf('add new cells ...')

celldata_FB=cat(1,celldata_FB,new_celldata);
cellboundLC_FB=cat(1,cellboundLC_FB,new_cellboundLC);
cellmaskLC_FB=cat(1,cellmaskLC_FB,new_cellmaskLC);

clear new_celldata
clear new_cellmaskLC
clear new_cellboundLC

save(cat(2,ROdir,'celldata_FB.mat'),'celldata_FB','-v7.3','-nocompression');
save(cat(2,ROdir,'cellboundLC_FB.mat'),'cellboundLC_FB','-v7.3','-nocompression');
save(cat(2,ROdir,'cellmaskLC_FB.mat'),'cellmaskLC_FB','-v7.3','-nocompression');

clear cellmaskLC_FB
clear cellboundLC_FB

fprintf(' DONE ! ->')

% *****************
% *** init tracking
% *****************

[Ncell,~]=size(celldata_FB);
idxs=[1:Ncell]';

im_p=Nim;
logiidx_p=(celldata_FB(:,3)==im_p);
Np=sum(logiidx_p(:));
short_celldata_p=zeros(Np,11,'single');
idxlist_p=zeros(Np,1);
idxlist_p=idxs(logiidx_p,1);
short_celldata_p=single(celldata_FB(logiidx_p,:));
%short_celldata_p=single(short_celldata_p);


fprintf('prepare linkage...');
for im=Nim:-1:2

  save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');

  im_c=im;
  im_p=im-1;

  short_celldata_c=zeros(Np,11,'single');
  idxlist_c=zeros(Np,1);

  % c = p from loop before
  short_celldata_c=short_celldata_p;
  idxlist_c=idxlist_p;
  Nc=Np;


  logiidx_p=(celldata_FB(:,3)==im_p);
  Np=sum(logiidx_p(:));

  short_celldata_p=zeros(Np,11,'single');
  idxlist_p=zeros(Np,1);
  
  short_celldata_p=single(celldata_FB(logiidx_p,:));
  %short_celldata_p=single(short_celldata_p);
  idxlist_p=idxs(logiidx_p,1);


  save(cat(2,save_path,'short_celldata_c.mat'),'short_celldata_c','-v7.3','-nocompression');
  save(cat(2,save_path,'short_celldata_p.mat'),'short_celldata_p','-v7.3','-nocompression');

  save(cat(2,save_path,'idxlist_c.mat'),'idxlist_c','-v7.3','-nocompression');
  save(cat(2,save_path,'idxlist_p.mat'),'idxlist_p','-v7.3','-nocompression');

  save(cat(2,save_path,'Nc.mat'),'Nc','-v7.3','-nocompression');
  save(cat(2,save_path,'Np.mat'),'Np','-v7.3','-nocompression');

end % for im

fprintf(' DONE !\n')

end % funciton

