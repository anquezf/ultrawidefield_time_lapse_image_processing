function [mask_out,Nreg_out]=make_mask_split_V6(mask_in,Nreg_in,NL,NC,deepTH,se)

Nreg_out=0;
mask_out=zeros(NL,NC);

mm=zeros(NL,NC);
mask_temp=zeros(NL,NC);
logimask=zeros(NL,NC,'logical');

for c=1:Nreg_in

  % current region
  mm=(mask_in==c);
  BLC=bwboundaries(mm);
  if ~(isempty(BLC))
    BLC=BLC{1,1};
    % measure boundary deepness
    [dBxB_list,dBxC_list,~,L0_list,C0_list,~,~,Lc,Cc,~,~]=measure_boundary_deepness_V3(BLC);
  else
    dBxB_list=[];
    dBxC_list=[];
    L0_list=[];
    C0_list=[];
    Lc=[];
    Cc=[];
  end % if  ~(isempty(BLC))

  deepN=-1;
  if ~(isempty(dBxB_list))
    deepN=dBxB_list./dBxC_list;
  end % if ~(isempty(dBxBm))
  logiidx=deepN>deepTH;
  Nspl=sum(logiidx);

  if Nspl>1

    % then we are going to split

    if Nspl==2
      % then directly connect the two points
      L0_list=L0_list(logiidx,1);
      C0_list=C0_list(logiidx,1);
      [Lw,Cw]=walk_toward_boundary_V2(L0_list(1,1),C0_list(1,1),L0_list(2,1),C0_list(2,1),BLC);
    else
      % then start from center for each points
      [Ntot,~]=size(L0_list);
      % for all pts
      Lw=[];
      Cw=[];
      for p=1:Ntot
        if deepN(p,1)>deepTH
          [LLw,CCw]=walk_toward_boundary_V2(Lc,Cc,L0_list(p,1),C0_list(p,1),BLC);
          Lw=cat(1,Lw,LLw);
          Cw=cat(1,Cw,CCw);
        end % if
      end % for
    end % if Nspl==2

    % make mask
    mask_temp=mm;
    [Npix,~]=size(Lw);
    if Npix>0
      for pix=1:Npix
        mask_temp(Lw(pix,1),Cw(pix,1))=0;
      end % ofr pix
    end % if
    % label
    [mask_temp,Nsp]=bwlabel(mask_temp);
    for r=1:Nsp
      Nreg_out=Nreg_out+1;
      logimask=(mask_temp==r);
      logimask=imdilate(logimask,se);
      mask_out(logimask)=Nreg_out;
    end % for r

  else

    Nreg_out=Nreg_out+1;
    logimask=(mask_in==c);
    mask_out(logimask)=Nreg_out;

  end % if

end % for c

end % funciton
