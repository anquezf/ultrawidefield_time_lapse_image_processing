function combine_raw_data_V2(ana_path)

warning off


[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% ****************
% *** combine data

load(cat(2,ana_path,'Npos.mat'),'Npos')

%           1  2   3      4     5          6   7   8   9   10 
%celldata=[ X ,Y , imidx, Area, Intensity, L,  C,  wB, wS, p  ]
%           um um  idx    Npix  a.u.       pix pix um  um  idx

rawcelldata=[];
rawcellmaskLC={};
rawcellboundLC={};

for p=0:(Npos-1)

  pos_ana_dir=cat(2,ana_path,'DATA/',num2str(p,'%0.5d'),'/');

  cellList=[];
  load(cat(2,pos_ana_dir,'cell_data/cell_List.mat'),'cell_List');
  load(cat(2,pos_ana_dir,'cell_data/maskLC_List'),'maskLC_List');
  load(cat(2,pos_ana_dir,'cell_data/boundLC_List'),'boundLC_List');
  if ~(isempty(cell_List))
    rawcelldata=cat(1,rawcelldata,cell_List);
    rawcellmaskLC=cat(1,rawcellmaskLC,maskLC_List);
    rawcellboundLC=cat(1,rawcellboundLC,boundLC_List);
  end % if

end % for p

save_path=cat(2,ana_path,'combined_data/');
mkdir(save_path)
save(cat(2,save_path,'rawcelldata.mat'),'rawcelldata','-v7.3','-nocompression');
save(cat(2,save_path,'rawcellmaskLC.mat'),'rawcellmaskLC','-v7.3','-nocompression');
save(cat(2,save_path,'rawcellboundLC.mat'),'rawcellboundLC','-v7.3','-nocompression');


end % funciton
