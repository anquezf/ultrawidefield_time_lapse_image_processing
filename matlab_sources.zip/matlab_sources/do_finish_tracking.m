function [isoptim,nit]=do_finish_tracking(ana_path,im)

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% *** INPUTS
% tracking params
save_path=cat(2,ana_path,'tracking/');
load(cat(2,save_path,'useWB.mat'),'useWB');
load(cat(2,save_path,'useWS.mat'),'useWS');
load(cat(2,save_path,'Lmax2.mat'),'Lmax2');
Lmax2=single(Lmax2);
load(cat(2,save_path,'WBSweight.mat'),'WBSweight');
WBSweight=single(WBSweight);
load(cat(2,save_path,'WBSweight.mat'),'WBSweight');
load(cat(2,save_path,'Nitemax.mat'),'Nitemax');
% data to track here...
save_path=cat(2,ana_path,'tracking/',num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
load(cat(2,save_path,'short_celldata_p.mat'),'short_celldata_p');
load(cat(2,save_path,'short_celldata_c.mat'),'short_celldata_c');
short_celldata_c=single(short_celldata_c);
short_celldata_p=single(short_celldata_p);

cost=build_cost_V5(short_celldata_c,short_celldata_p,Lmax2,useWB,useWS,WBSweight);

clear('short_celldata_c')
clear('short_celldata_p')

attrib=seed_attrib_V3(cost,Lmax2);

[attrib,nit]=linkage_V10(cost,attrib,Lmax2,Nitemax);

save(cat(2,save_path,'attrib.mat'),'attrib','-v7.3','-nocompression');
save(cat(2,save_path,'nit.mat'),'nit','-v7.3','-nocompression');

if nit<Nitemax
  isoptim=1;
else
  isoptim=0;
end % if

end % funciton
