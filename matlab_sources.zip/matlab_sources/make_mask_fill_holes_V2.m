function [mask_out]=make_mask_fill_holes_V2(mask_in,Nreg,NL,NC)

mask_out=zeros(NL,NC);
mask_temp=zeros(NL,NC);

for c=1:Nreg
  mask_temp=(imfill((mask_in==c),'holes')>0);
  mask_out(mask_temp)=c;
end % for c

end % funciton
