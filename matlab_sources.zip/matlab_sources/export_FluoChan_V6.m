function export_FluoChan_V6(save_path,chanF,ana_path,MAG,Imini,Imaxi,bit_depth,deltaX_pix,deltaY_pix,Npos,pNC,pNL,NL,NC,imoffset,FF_bkg,FF_foreg,b,useFF,useDNS,flipUD,flipLR,im)

warning off

theimage=zeros(NL,NC);
pimage=zeros(pNL,pNC);

for pos=1:Npos

  load(cat(2,ana_path,'Fluo_Ana/',chanF,'/positions_infos/',num2str(pos-1,'%05d'),'/imidx_2_lidx.mat'));
  ll=imidx_2_lidx(im,1);

  load(cat(2,ana_path,'Fluo_Ana/',chanF,'/positions_infos/',num2str(pos-1,'%05d'),'/fileListF.mat'));

  % *** load raw data
  theimage=double(imread(fileListF{ll,1}));
  theimage=(theimage-imoffset);

  % flip ?
  if flipUD>0 theimage=flipud(theimage); end % if
  % flip ?
  if flipLR>0 theimage=fliplr(theimage); end % if

  % *** pre proc DATA
  % *****************

  if useFF>0
  % remove background
    theimage=theimage-b*FF_bkg;
  % correct FF
    theimage=theimage./FF_foreg;
  else
    theimage=theimage-b;
  end % if useFF

  if useDNS>0 
  % denoise
   theimage=medfilt2(theimage,[3 3],'symmetric');
  end % if useDNS

  pimage=imresize(theimage(deltaY_pix:NL,deltaX_pix:NC),[pNL,pNC]);

  mask=pimage<Imini;
  pimage(mask)=Imini;
  mask=pimage>Imaxi;
  pimage(mask)=Imaxi;

  pimage=(pimage-Imini)/(Imaxi-Imini);

  if bit_depth==16
    pimage_out=pimage*65535;
    pimage_out=uint16(pimage_out);
  else
    pimage_out=pimage*255;
    pimage_out=uint8(pimage_out);
  end % if

  save(cat(2,save_path,chanF,'_images/',num2str(MAG),'X/',num2str(pos),'/',num2str(im,'%05d'),'.mat'),'pimage_out','-v7.3','-nocompression');

end % for pos

end % fucntion
