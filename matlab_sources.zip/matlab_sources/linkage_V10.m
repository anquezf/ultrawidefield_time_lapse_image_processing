function [attrib,nit]=linkage_V8(cost,attrib,Lmax,Nitmax)


% Lmax typical maximum displacement between to frames
Lmax_sq=power(Lmax,2);

% last column and last line are dummy particles
[N1,N2]=size(cost);
N1=N1-1;
N2=N2-1;

% ******************************
% initialize reduced cost matrix
% ******************************

% whos with whom ?
K=attrib*([1:(N2+1)]');
L=([1:(N1+1)])*attrib;

% matrix to calculate red_cost
costK=zeros(N1+1,N2+1,'single');
costL=zeros(N1+1,N2+1,'single');
costLK=zeros(N1+1,N2+1,'single');

% non dummy
% calculate for all permutation
for n1=1:N1
  for n2=1:N2
    %red_cost(n1,n2)=cost(n1,n2)-cost(n1,K(n1,1))-cost(L(1,n2),n2)+cost(L(1,n2),K(n1,1));
    costK(n1,n2)=cost(n1,K(n1,1));
    costL(n1,n2)=cost(L(1,n2),n2);
    costLK(n1,n2)=cost(L(1,n2),K(n1,1));
  end % for n2
end % for n1
% dis-apperaing
for n1=1:N1
  %red_cost(n1,N2+1)=cost(n1,N2+1)-cost(n1,K(n1,1))+cost(N1+1,K(n1,1));
  costK(n1,N2+1)=cost(n1,K(n1,1));
  costL(n1,N2+1)=0;
  costLK(n1,N2+1)=cost(N1+1,K(n1,1));
end % for n1
% apperaing
for n2=1:N2
  %red_cost(N1+1,n2)=cost(N1+1,n2)-cost(L(1,n2),n2)+cost(L(1,n2),N2+1);
  costK(N1+1,n2)=0;
  costL(N1+1,n2)=cost(L(1,n2),n2);
  costLK(N1+1,n2)=cost(L(1,n2),N2+1);
end % for n2

% calculate reduced_cost
red_cost=zeros(N1+1,N2+1,'single');
red_cost=cost-costK-costL+costLK;
red_cost(N1+1,N2+1)=0;



% ***********
% start optim
% ***********

do_stop=0;
nit=0;

while do_stop==0

  logiidx=(red_cost<0);
  %[n1_list,n2_list]=find(red_cost<0);

  if (sum(logiidx(:))==0)||(nit>=Nitmax)

    do_stop=1;

  else

    [~,idx]=min(red_cost(:));
    [n1s,n2s]=ind2sub([(N1+1) (N2+1)],idx);
    kk=K(n1s,1);
    ll=L(1,n2s);

    attrib(n1s,n2s)=1;
    attrib(n1s,kk)=0;
    attrib(ll,n2s)=0;
    attrib(ll,kk)=1;

    K(n1s,1)=n2s;
    K(ll,1)=kk;
    L(1,n2s)=n1s;
    L(1,kk)=ll;

    % update reduced cost

    % non dummies

    if n1s<(N1+1)    
      costK(n1s,1:N2)=cost(n1s,K(n1s,1));
      for n2=1:N2
        costLK(n1s,n2)=cost(L(1,n2),K(n1s,1));
      end % for n1
    end % if
    if n2s<(N2+1)
      costL(1:N1,n2s)=cost(L(1,n2s),n2s);
      for n1=1:N1
        %n2s
        %n1
        costLK(n1,n2s)=cost(L(1,n2s),K(n1,1));
      end % for n1
    end % if


    if ll<(N1+1)    
      costK(ll,1:N2)=cost(ll,K(ll,1));
      for n2=1:N2
        costLK(ll,n2)=cost(L(1,n2),K(ll,1));
      end % for n2
    end % if
    if kk<(N2+1)
      costL(1:N1,kk)=cost(L(1,kk),kk);
      for n1=1:N1
        costLK(n1,kk)=cost(L(1,kk),K(n1,1));
      end % for n1
    end % if

    % dummies
    costK(n1s,N2+1)=cost(n1s,K(n1s,1));
    costL(n1s,N2+1)=0;
    costLK(n1s,N2+1)=cost(N1+1,K(n1s,1));

    costK(ll,N2+1)=cost(ll,K(ll,1));
    costL(ll,N2+1)=0;
    costLK(ll,N2+1)=cost(N1+1,K(ll,1));

    costK(N1+1,n2s)=0;
    costL(N1+1,n2s)=cost(L(1,n2s),n2s);
    costLK(N1+1,n2s)=cost(L(1,n2s),N2+1);

    costK(N1+1,kk)=0;
    costL(N1+1,kk)=cost(L(1,kk),kk);
    costLK(N1+1,kk)=cost(L(1,kk),N2+1);

    % update    
    red_cost=cost-costK-costL+costLK;
    red_cost(N1+1,N2+1)=0;

  end % if isempty(n_list)||(nit>=Nit_max)

  nit=nit+1;

end % while


end % funciton
