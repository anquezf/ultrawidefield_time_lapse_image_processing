function export_posUDLR(ana_path)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'XYlist.mat'));

% script build pos pos

hf=figure('Units','centimeters','PaperSize', [60 60],'visible','off');
ax=subplot(1,1,1);

Xmini=min(XYlist(:,1))-100;
Xmaxi=max(XYlist(:,1))+100;
Ymini=min(XYlist(:,2))-100;
Ymaxi=max(XYlist(:,2))+100;

FS=4;

axis(ax,[Xmini Xmaxi Ymini Ymaxi]);
set(ax,'FontSize',FS,'FontWeight','Bold');
xlabel(ax,'X (\mu m)','FontSize',FS,'FontWeight','Bold');
ylabel(ax,'Y (\mu m)','FontSize',FS,'FontWeight','Bold');
grid on

hold(ax,'on');
plot(ax,XYlist(:,1),XYlist(:,2),'-','LineWidth',0.5);

[Npos,~]=size(XYlist);
for pos=1:Npos
  hold(ax,'on');
  text(ax,XYlist(pos,1),XYlist(pos,2),num2str(pos-1,'%d'),'FontSize',FS,'FontWeight','Bold');
end % for pos

print(cat(2,ana_path,'posUDLR.png'),'-dpng','-r300');
close(hf);


end % fucntion
