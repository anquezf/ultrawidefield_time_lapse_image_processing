function run_preproc_BFhisto(ana_path,imaxi_bf_str,imini_bf_str,deltai_bf_str,NBMAX_str)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if


imaxi_bf=str2double(imaxi_bf_str);
imini_bf=str2double(imini_bf_str);
deltai_bf=str2double(deltai_bf_str);
iedges_bf=(imini_bf:deltai_bf:imaxi_bf)';

save(cat(2,ana_path,'deltai_bf.mat'),'deltai_bf','-v7.3','-nocompression');
save(cat(2,ana_path,'imaxi_bf.mat'),'imaxi_bf','-v7.3','-nocompression');
save(cat(2,ana_path,'imini_bf.mat'),'imini_bf','-v7.3','-nocompression');
save(cat(2,ana_path,'iedges_bf.mat'),'iedges_bf','-v7.3','-nocompression');

load(cat(2,ana_path,'Npos.mat'));

NBMAX=str2double(NBMAX_str);


% ***
% *** process raw AVG

fprintf('* PROCESS BrightField Histograms : \n');

POOLOBJ=parpool('local',NBMAX,'IdleTimeout',360);
parfor pos=1:Npos
  preproc_BFhisto(ana_path,pos);
end % par for
delete(POOLOBJ);

fprintf(' DONE!\n');


end % function



