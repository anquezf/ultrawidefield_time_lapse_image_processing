function dirList=utils_DIRList(dirName)

% Find all directory in the target directory
%
% ***** input :
%		'dirName' : name of directory to screen ;
% ***** output :
%		'dirList' : a List of directory name ; cell array ; one line per directory


% *** Init ***
% Look at what's in the current directory
dirData = dir(dirName);
sizes=size(dirData);
% Find the index for directories
dirIndex = find([dirData.isdir]);
% some variables
dirList={};

% *** Find them ***
for d=dirIndex
  if not(strcmp(dirData(d).name,'.'))&not(strcmp(dirData(d).name,'..'))
    dirList=vertcat(dirList,dirData(d).name);
  end
end % for

% Prepend path to files
if ~isempty(dirList)
  dirList = cellfun(@(x) fullfile(dirName,x),dirList,'UniformOutput',false);  %# Prepend path to files
end

% add '/' to path
[Ndir,crapint]=size(dirList);
if not(Ndir==0)
  for d=1:Ndir
    dirList{d,1}=cat(2,dirList{d,1},'/');
  end % for d
end % if

% make full path
[Ndir,crapint]=size(dirList);
for d=1:Ndir
  dirList{d,1}=utils_GetFullPath(dirList{d,1});
end % for d

end % function


