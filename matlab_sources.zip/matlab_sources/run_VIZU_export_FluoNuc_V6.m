function run_VIZU_exportFluoNuc_V6(ana_path,NBMAX_str,Imaxi_str)

fprintf('\n');
fprintf('\n');
fprintf('\n');

fprintf('************************\n');
fprintf('*** Export Fluo. Nuc ***\n');
fprintf('************************\n');
fprintf('\n');


warning off
vizu_version='V6';

% *** params
Imaxi=str2double(Imaxi_str);



ana_path_temp=ana_path;
ana_path=ana_path_temp;
[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

NBMAX=str2double(NBMAX_str);
POOLOBJ=parpool('local',NBMAX);

fprintf('\n');
fprintf('*** Load Infos ***\n');


% *** VIZU export infos
% *********************

fprintf('* VIZU export infos...');

startIndex = regexp(ana_path,'/');
[~,Nsi]=size(startIndex);
[~,Nchar]=size(ana_path);
if startIndex(1,Nsi)==Nchar
  idx=startIndex(1,Nsi-1)+1;
  motif=ana_path(1,idx:(Nchar-1));
else
  idx=startIndex(1,Nsi)+1;
  motif=ana_path(1,idx:(Nchar-1));
end

save_path=cat(2,ana_path,'VIZU_',vizu_version,'_',motif,'/');
%save_path=cat(2,'VIZU_',vizu_version,'_',motif,'/');

dNL=0;
load(cat(2,save_path,'dNL.mat'),'dNL');
dNC=0;
load(cat(2,save_path,'dNC.mat'),'dNC');

load(cat(2,save_path,'im_start.mat'),'im_start');
load(cat(2,save_path,'im_stop.mat'),'im_stop');

NposX_tot=0;
load(cat(2,save_path,'NposX_tot.mat'),'NposX_tot');
NposY_tot=0;
load(cat(2,save_path,'NposY_tot.mat'),'NposY_tot');

load(cat(2,save_path,'NMAG.mat'),'NMAG');
load(cat(2,save_path,'MAG_list.mat'),'MAG_list');

bit_depth=8;
load(cat(2,save_path,'bit_depth'),'bit_depth');

load(cat(2,save_path,'NpanelX_list.mat'),'NpanelX_list');
load(cat(2,save_path,'NpanelY_list.mat'),'NpanelY_list');
load(cat(2,save_path,'pNC_list.mat'),'pNC_list');
load(cat(2,save_path,'pNL_list.mat'),'pNL_list');

load(cat(2,save_path,'blctoskip_list.mat'),'blctoskip_list');

posGRID=[];
load(cat(2,save_path,'posGRID.mat'),'posGRID');

load(cat(2,save_path,'Xgrid.mat'),'Xgrid');
load(cat(2,save_path,'Ygrid.mat'),'Ygrid');
load(cat(2,save_path,'Xmingrid.mat'),'Xmingrid');
load(cat(2,save_path,'Ymingrid.mat'),'Ymingrid');
load(cat(2,save_path,'Xmaxgrid.mat'),'Xmaxgrid');
load(cat(2,save_path,'Ymaxgrid.mat'),'Ymaxgrid');

fprintf('DONE !\n')


% *** EXPERIMENTS infos
% *********************

fprintf('* EXPERIMENTS infos...');

Nim=0;
load(cat(2,ana_path,'Nim.mat'));

Npos=0;
load(cat(2,ana_path,'Npos.mat'));

pixsize=0;
load(cat(2,ana_path,'pixsize.mat'));

NL=0;
load(cat(2,ana_path,'NL.mat'));
NC=0;
load(cat(2,ana_path,'NC.mat'));

load(cat(2,ana_path,'deltaXpos.mat'));
load(cat(2,ana_path,'deltaYpos.mat'));

b0=0;
load(cat(2,ana_path,'b0.mat'));
delta_b_vsim=zeros(1,Nim);
load(cat(2,ana_path,'delta_b_vsim.mat'));
mu_cor_all=zeros(1,Nim);
load(cat(2,ana_path,'mu_cor_all.mat'));

flipUD=0;
load(cat(2,ana_path,'flipUD.mat'));
flipLR=0;
load(cat(2,ana_path,'flipLR.mat'));
FF_bkg=zeros(NL,NC);
load(cat(2,ana_path,'FF_bkg.mat'));
useFFforeg=0;
load(cat(2,ana_path,'useFFforeg.mat'));
FF_foreg=zeros(NL,NC);
load(cat(2,ana_path,'FF_foreg.mat'));
imoffset=zeros(NL,NC);
load(cat(2,ana_path,'imoffset.mat'));

fprintf('DONE !\n')



% *** prepare directory
% *********************

fprintf('* prepare directory...');

mkdir(cat(2,save_path,'nuc_images/'));
save(cat(2,save_path,'nuc_images/Imaxi'),'Imaxi','-v7.3','-nocompression');

fprintf('DONE !\n')




% *** export 1X
% *************

fprintf('\n');
fprintf('*** export 1X images ***\n');

ll=MAG_list==1;

if sum(ll)>0

  fprintf('* run 1X export...');
  mkdir(cat(2,save_path,'nuc_images/1X'));

  if deltaXpos<0
    deltaX_pix=round(-deltaXpos/pixsize);
  end
  if deltaYpos<0
    deltaY_pix=round(-deltaYpos/pixsize);
  end % if

  pNC=pNC_list(1,ll);
  pNL=pNL_list(1,ll);

  parfor im=im_start:im_stop
    deltab=delta_b_vsim(1,im);
    mucor=mu_cor_all(1,im);
    export_FluoNuc_1X_V6(save_path,ana_path,Imaxi,bit_depth,dNL,dNC,deltaX_pix,deltaY_pix,NposX_tot,NposY_tot,posGRID,pNC,pNL,NL,NC,b0,deltab,mucor,imoffset,FF_bkg,useFFforeg,FF_foreg,flipUD,flipLR,im);
  end % parfor

  fprintf('DONE !\n')

else

  fprintf('* no 1X to export ! \n');

end % if




fprintf('\n');
fprintf('*** export images ');
for m=1:NMAG
  MAG=MAG_list(1,m);
  if ~(MAG==1)
    fprintf(cat(2,num2str(MAG),'X '));
  end % if
end % for
fprintf('***\n');


for m=1:NMAG

  MAG=MAG_list(1,m);

  if ~(MAG==1)

    fprintf(cat(2,'* run ',num2str(MAG),'X export :\n'));


    % prepare dir
    fprintf('prepare directories ...');

    mkdir(cat(2,save_path,'nuc_images/',num2str(MAG),'X'));
    for pos=1:Npos
      mkdir(cat(2,save_path,'nuc_images/',num2str(MAG),'X/',num2str(pos),'/'));
    end % for pos

    fprintf('DONE !\n')

    % prepare panels
    fprintf('prepare panels ...');

    if deltaXpos<0
      deltaX_pix=round(-deltaXpos/pixsize);
    end
    if deltaYpos<0
      deltaY_pix=round(-deltaYpos/pixsize);
    end % if

    pNC=pNC_list(1,m);
    pNL=pNL_list(1,m);

    parfor im=im_start:im_stop
      deltab=delta_b_vsim(1,im);
      mucor=mu_cor_all(1,im);
      export_FluoNuc_V6(save_path,ana_path,Imaxi,bit_depth,deltaX_pix,deltaY_pix,Npos,pNC,pNL,NL,NC,b0,deltab,mucor,imoffset,FF_bkg,useFFforeg,FF_foreg,flipUD,flipLR,MAG,im);
    end % parfor

   fprintf('DONE !\n')

  end % if

end % for



fprintf('\n');
fprintf('\n');
fprintf('\n');
delete(POOLOBJ);
fprintf('*** Export FluoNuc DONE ! ***\n');
