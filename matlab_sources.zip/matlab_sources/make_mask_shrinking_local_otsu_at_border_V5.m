function [mask,nit]=make_mask_shrinking_local_otsu_at_border_V5(Ncell,mask_ini,theimage,NL,NC,Nite,se,mu0)

% comparing imerode and full image works well to detect boundaries of simple objects
% it is faster that the bwboundaries function...

mask=mask_ini;
mask_bkg=(mask==0);
mask_cell=zeros(NL,NC);
mask_border=zeros(NL,NC);

aschanged_prev=ones(Ncell,1);
aschanged_cur=zeros(Ncell,1);

%mask_dummy=mask_ini;
do_stop=0;
nit=0;
while do_stop==0

  aschanged_cur=zeros(Ncell,1);
  nit=nit+1;
  % get bkg and its properties
  N0=sum(mask_bkg(:));
  % we assume mu0 is known
  % mu0=sum(theimage(mask_bkg))/N0;

  for c=1:Ncell

   if aschanged_prev(c,1)>0

    mask_cell=(mask==c);
    N1=sum(mask_cell(:));
    mu1=sum(theimage(mask_cell))/N1;

    % get other properties
    NT=N0+N1;
    w0=N0/NT;
    w1=N1/NT;

    % get updates that we already know
    N0p=N0+1;
    N1p=N1-1;
    w0p=N0p/NT;
    w1p=N1p/NT;
    % mu0p= (N0*mu0)/N0p + v/N0p
    %           PP0      + v/N0p
    PP0=(N0*mu0)/N0p;
    % mu1p= (N1*mu1)/N1p - v/N1p
    %           PP1      - v/N1p
    PP1=(N1*mu1)/N1p;
    % the inter-class variance at intial state
    sig2=(w0*w1)*power(mu0-mu1,2);

    % get boundaries
    mask_border=mask_cell-imerode(mask_cell,se);
    [LL,CC]=find(mask_border);
    %[B,mask_dummy,Nbound]=bwboundaries(mask_prev);
    [Nbound,~]=size(LL);

    if Nbound>0
    for b=1:Nbound
      v=theimage(LL(b,1),CC(b,1));
      % we assume mu0 isknown
      % mu0p=PP0+v/N0p;
      mu1p=PP1-v/N1p;
      sig2p=(w0p*w1p)*power(mu0-mu1p,2);
      if sig2p>sig2
        mask(LL(b,1),CC(b,1))=0;
	mask_bkg(LL(b,1),CC(b,1))=1;
        aschanged_cur(c,1)=1;
      end % if
    end % for b
    end % if ~(isempty(B))

   end % if aschnaged_prev

  end % for c

  if nit>(Nite-1)
    do_stop=1;
  end % if

  if sum(aschanged_cur)==0
    do_stop=1;
  end % if

  aschanged_prev=aschanged_cur;

end % while

end % fucntion
