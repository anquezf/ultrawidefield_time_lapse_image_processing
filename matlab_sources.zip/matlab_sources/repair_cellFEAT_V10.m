function new_scd=repair_cellFEAT_V8(ana_path,old_scd,newMLC,NL,NC)

mask=zeros(NL,NC,'int16');
bkg_mask=zeros(NL,NC,'logical');
mask_cell=zeros(NL,NC,'logical');

% create mask
[Npix,~]=size(newMLC);
for pix=1:Npix
  mask_cell(newMLC(pix,1),newMLC(pix,2))=1;
end % for pix

Lc_abs=NL/2;
Cc_abs=NC/2;

load(cat(2,ana_path,'useFFforeg.mat'),'useFFforeg');
load(cat(2,ana_path,'FF_NUC.mat'),'FF');
load(cat(2,ana_path,'FF_bkg.mat'),'FF_bkg');
load(cat(2,ana_path,'FF_foreg.mat'),'FF_foreg');
load(cat(2,ana_path,'imoffset.mat'),'imoffset');
load(cat(2,ana_path,'pixsize.mat'),'pixsize');
load(cat(2,ana_path,'flipUD.mat'),'flipUD');
load(cat(2,ana_path,'flipLR.mat'),'flipLR');

% load bkg pdf
load(cat(2,ana_path,'mu_cor_all.mat'),'mu_cor_all');
load(cat(2,ana_path,'sig_cor_all.mat'),'sig_cor_all');

load(cat(2,ana_path,'b0.mat'),'b0');
load(cat(2,ana_path,'delta_b_vsim.mat'),'delta_b_vsim');

p=old_scd(1,10);
pos_ana_dir=cat(2,ana_path,'DATA/',num2str(p,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');
load(cat(2,pos_ana_dir,'fileListN.mat'),'fileListN');
load(cat(2,pos_ana_dir,'XYfield.mat'),'XYfield');

% load image
im=old_scd(1,3);
theimage=zeros(NL,NC);
% find idx
idx=imidx_2_lidx(im,1);

% load raw data
theimage=double(imread(fileListN{idx,1}));
theimage=(theimage-imoffset);

% *** image restoration
theimage=theimage-(b0+delta_b_vsim(1,im))*FF_bkg;

if useFFforeg==1
  theimage=theimage./FF_foreg;
end % if

theimage=theimage-mu_cor_all(1,im);


% flip ?
if flipUD>0 theimage=flipud(theimage); end % if
% flip ?
if flipLR>0 theimage=fliplr(theimage); end % if


Xc=XYfield(1,1);
Yc=XYfield(1,2);

Area=sum(mask_cell(:));
INTEN=(sum(theimage(mask_cell))/Area);
[Ll,Cl]=find(mask_cell);
L=mean(Ll); C=mean(Cl);
X=( (C-Cc_abs)*pixsize )+Xc;
Y=( -(L-Lc_abs)*pixsize )+Yc;

reg_props=regionprops(mask_cell,'MajorAxisLength','MinorAxisLength','ConvexArea');
RP=reg_props(1,1);
wB=(RP.MajorAxisLength)*pixsize;
wS=(RP.MinorAxisLength)*pixsize;
ConvexArea=(RP.ConvexArea);

CID=old_scd(:,12);

new_scd=[X,Y,im,ConvexArea,INTEN,L,C,wB,wS,p,nan,CID];

end % function
