function [mask,Nreg_out]=split_collider_V4(Nreg,MLC,NL,NC)

[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);

mask=zeros(NL,NC);
mask_ini=zeros(NL,NC);
mask_temp=zeros(NL,NC);
mask_temp2=zeros(NL,NC);

[Npix,~]=size(MLC);
for pix=1:Npix
  mask_ini(MLC(pix,1),MLC(pix,2))=1;
end % for pix
mask=mask_ini;


% ***************************
% *** successive erosions ***
% ***************************

se=strel('disk',3);

Ncur=1;
Nprev=1;
Nreg_out=1;

Nite=sum(mask_ini(:))/Nreg;
do_stop=0;
mask_centroids=mask;
ite=0;

while do_stop==0

  ite=ite+1;

  mask_temp=imerode(mask>0,se);
  [mask_temp,Ncur]=bwlabel(mask_temp);

  if (Ncur>0)&(Ncur>=Nprev)
    mask=mask_temp;
    Nreg_out=Ncur;
  end % if

  if (Ncur>=Nreg)
    do_stop=1;
  end % if

  if (Ncur==0)
    do_stop=1;
  end % if

  if (Ncur<Nprev)
    do_stop=1;
  end % if

  if (ite>=Nite)
    do_stop=1;
  end % if

  Nprev=Ncur;
end % while

% *******************************
% *** classify by region size ***
% *******************************

Ll=zeros(Nreg_out,1);
Cl=zeros(Nreg_out,1);
Area=zeros(Nreg_out);
idxl=zeros(Nreg_out,1);
for r=1:Nreg_out
  mask_temp=(mask==r);
  Area(r,1)=sum(mask_temp(:));
  idxl(r,1)=r;
end % for r
[~,idxs]=sort(Area,'descend');
Ll=Ll(idxs,1);
Cl=Cl(idxs,1);
idxl=idxl(idxs,1);

if Nreg_out>Nreg
  Ll=Ll(1:Nreg,1);
  Cl=Cl(1:Nreg,1);
  Nreg_out=Nreg;
end % if


% ***************************************
% *** successively dilate each region ***
% ***************************************

ite=0;
if Nreg_out>1

  mask_temp=mask;
  mask=zeros(NL,NC);
  for r=1:Nreg_out
    idx=idxl(r,1);
    mask_temp2=(mask_temp==idx);
    mask(mask_temp2>0)=r;
  end % for r

  do_stop=0;
  while do_stop==0

    ite=ite+1;

    mask_temp=zeros(NL,NC);
    for r=1:Nreg_out
      mask_temp2=(mask==r);
      mask_temp2=imdilate(mask_temp2,se);
      mask_temp(mask_temp2>0)=r;
    end % for r
    mask=mask_temp;

    drawnow
    logiidxT=(mask_ini>0);
    logiidxC=(mask>0)&(mask_ini>0);
    NpixT=sum(logiidxT(:));
    NpixC=sum(logiidxC(:));
    if (NpixC>=NpixT)||(ite>=Nite)
      do_stop=1;
    end % if

  end % for while

  mask=mask.*mask_ini;

else
  mask=mask_ini;
  Nreg_out=1;
end % if

%{
BLC=bwboundaries(mask_ini); BLC=BLC{1,1};
figure; plot(BLC(:,2),BLC(:,1));

for r=1:Nreg_out
  BLC=bwboundaries(mask==r); BLC=BLC{1,1};
  hold on; plot(BLC(:,2),BLC(:,1));
end
axis equal;
%}

end % funciton



