function do_tracking_V3(ana_path,im)

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% *** INPUTS
% tracking params
save_path=cat(2,ana_path,'tracking/');
load(cat(2,save_path,'useWB.mat'),'useWB');
load(cat(2,save_path,'useWS.mat'),'useWS');
load(cat(2,save_path,'Lmax.mat'),'Lmax');
load(cat(2,save_path,'WBSweight.mat'),'WBSweight');
load(cat(2,save_path,'Nitemax.mat'),'Nitemax');
% data to track here...
save_path=cat(2,ana_path,'tracking/',num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
load(cat(2,save_path,'short_celldata_p.mat'),'short_celldata_p');
load(cat(2,save_path,'short_celldata_c.mat'),'short_celldata_c');


cost=build_cost_V5(short_celldata_c,short_celldata_p,Lmax,useWB,useWS,WBSweight);

clear('short_celldata_c')
clear('short_celldata_p')

attrib=seed_attrib_V3(cost,Lmax);

[attrib,nit]=linkage_V10(cost,attrib,Lmax,Nitemax);

save(cat(2,save_path,'attrib.mat'),'attrib','-v7.3','-nocompression');
save(cat(2,save_path,'nit.mat'),'nit','-v7.3','-nocompression');

end % funciton
