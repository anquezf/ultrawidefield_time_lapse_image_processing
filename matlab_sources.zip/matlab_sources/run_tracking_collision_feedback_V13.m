function run_tracking_collision_feedback_V13(ana_path,deepTH_str,deepTH_2_str,AREArelinc_str,NloopFB_str,rscAREA_tol_str,RSCOVTH_str,NBMAX_str)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'Nim.mat'));
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

load(cat(2,ana_path,'NL.mat'));
load(cat(2,ana_path,'NC.mat'));

save_path=cat(2,ana_path,'tracking/');
load(cat(2,save_path,'Lmax.mat'),'Lmax');
load(cat(2,save_path,'Nitemax.mat'),'Nitemax');

load(cat(2,ana_path,'dpix_tol.mat'),'dpix_tol');
load(cat(2,ana_path,'deepTH_repairSPLIT.mat'),'deepTH_repairSPLIT');

load(cat(2,ana_path,'mitoCONTRAST_TH1.mat'),'mitoCONTRAST_TH1');


NBMAX=str2double(NBMAX_str);

% ***********************************************************************************
% *** INTIALIZATION
% ***********************************************************************************

fprintf('*** INITIALIZE tracking-collision feedback ... \n')

% *** prepare dirs
% ****************

ROdir=cat(2,ana_path,'tracking_collision_feedback/');
mkdir(ROdir);
ROcoll_dir=cat(2,ROdir,'collision_detection/');
mkdir(ROcoll_dir);
ROtrack_dir=cat(2,ROdir,'linkage/');
mkdir(ROtrack_dir);

deepTH=str2double(deepTH_str);
deepTH_2=str2double(deepTH_2_str);
NloopFB=str2double(NloopFB_str);
AREArelinc=str2double(AREArelinc_str);
rscAREA_tol=str2double(rscAREA_tol_str);
RSCOVTH=str2double(RSCOVTH_str);

save(cat(2,ana_path,'deepTH.mat'),'deepTH','-v7.3','-nocompression');
save(cat(2,ana_path,'deepTH_2.mat'),'deepTH_2','-v7.3','-nocompression');
save(cat(2,ana_path,'AREArelinc.mat'),'AREArelinc','-v7.3','-nocompression');
save(cat(2,ana_path,'NloopFB.mat'),'NloopFB','-v7.3','-nocompression');
save(cat(2,ana_path,'rscAREA_tol.mat'),'rscAREA_tol','-v7.3','-nocompression');
save(cat(2,ana_path,'RSCOVTH.mat'),'RSCOVTH','-v7.3','-nocompression');

fprintf('intializing collision detection');% for image %5d to %5d',0,0);
for im=(im_start+1):im_stop
  save_path=cat(2,ROcoll_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
  mkdir(save_path)
end % for im
fprintf(' : DONE ! \n')



fprintf('intializing linkage');% for image %5d to %5d',0,0);
for im=(im_start+1):im_stop
  % *** mkdir
  save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
  mkdir(save_path)
end % for im
fprintf(' : DONE ! \n')


% *** load data
% ****************

fprintf('load data ...')

load(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata');
load(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC');
load(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC');
load(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF');

load(cat(2,ana_path,'combined_data/celldata_fp.mat'),'celldata_fp');
load(cat(2,ana_path,'combined_data/cellmaskLC_fp.mat'),'cellmaskLC_fp');
load(cat(2,ana_path,'combined_data/cellboundLC_fp.mat'),'cellboundLC_fp');

fprintf(' DONE !\n')

fprintf('prepare FP rescue for image %5d to %5d',0,0);
for im=(im_start+1):im_stop

  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d to %5d',im,im-1);

  save_path=cat(2,ROcoll_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
  logiidx=(celldata_fp(:,3)==im)|(celldata_fp(:,3)==(im-1));
  short_celldata_fp=celldata_fp(logiidx,:);
  short_cellmaskLC_fp=cellmaskLC_fp(logiidx,:);
  short_cellboundLC_fp=cellboundLC_fp(logiidx,:);
  save(cat(2,save_path,'short_celldata_fp.mat'),'short_celldata_fp','-v7.3','-nocompression');
  save(cat(2,save_path,'short_cellmaskLC_fp.mat'),'short_cellmaskLC_fp','-v7.3','-nocompression');
  save(cat(2,save_path,'short_cellboundLC_fp.mat'),'short_cellboundLC_fp','-v7.3','-nocompression');

end % for im

clear celldata_fp;
clear cellmaskLC_fp;
clear cellboundLC_fp;
clear short_celldata_fp;
clear short_cellmaskLC_fp;
clear short_cellboundLC_fp;
fprintf(' DONE !\n')


% ***********************************************************************************
% *** RUN LOOP
% ***********************************************************************************

fprintf('\n')
fprintf('*** RUN collision-tracking feedback : \n')
fprintf('\n')

  % *** create parallel computing
  POOLOBJ=parpool('local',NBMAX,'IdleTimeout',240);


loops_done=0;
do_stop=0;

Ncor_vs_loop=zeros(NloopFB,1);
Ncol_vs_loop=zeros(NloopFB,1);
Nrscd_vs_loop=zeros(NloopFB,1);
optim_vs_loop=zeros(NloopFB,1);
Novsp_vs_loop=zeros(NloopFB,1);

while do_stop==0

  fprintf('* loop : %d \n',loops_done+1)

  % *** prepare collision detection *********************************************************
  % *******************************

  [Nscd_tot,~]=size(sorted_celldata);
  idxlist=[1:Nscd_tot]';

  for im=im_stop:-1:(im_start+1)

    logiidx=(sorted_celldata(:,3)==im)|(sorted_celldata(:,3)==(im-1));
    short_celldata=sorted_celldata(logiidx,:);
    short_cellmaskLC=sorted_cellmaskLC(logiidx,:);
    short_cellboundLC=sorted_cellboundLC(logiidx,:);
    short_idxlist=idxlist(logiidx,:);

    save_path=cat(2,ROcoll_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');

    save(cat(2,save_path,'short_celldata.mat'),'short_celldata','-v7.3','-nocompression');
    save(cat(2,save_path,'short_cellmaskLC.mat'),'short_cellmaskLC','-v7.3','-nocompression');
    save(cat(2,save_path,'short_cellboundLC.mat'),'short_cellboundLC','-v7.3','-nocompression');

    save(cat(2,save_path,'short_idxlist.mat'),'short_idxlist','-v7.3','-nocompression');

  end % for im



  % *** do collision detection  *********************************************************
  % *******************************

  Ncorrected=0;
  Ncolliders=0;
  Nrescued=0;

  parfor im=(im_start+1):im_stop
    [Ncorr,Ncolli,Nrscd]=do_collision_detection_V17(ana_path,im);
    Ncorrected=Ncorrected+Ncorr;
    Ncolliders=Ncolliders+Ncolli;
    Nrescued=Nrescued+Nrscd;
  end % parfor


  fprintf('---> found %07d colliders and %07d FP rescued \n',Ncolliders,Nrescued);

  Ncor_vs_loop(loops_done+1,1)=Ncorrected;
  Ncol_vs_loop(loops_done+1,1)=Ncolliders;
  Nrscd_vs_loop(loops_done+1,1)=Nrescued;


  % *** prepare tracking feedback  *********************************************************
  % *******************************

  celldata_FB=sorted_celldata(:,1:11);
  cellboundLC_FB=sorted_cellboundLC;
  cellmaskLC_FB=sorted_cellmaskLC;
  cellBF_FB=sorted_cellBF;

  new_celldata=[];
  new_cellboundLC={};
  new_cellmaskLC={};
  new_cellBF=[];

  for im=im_stop:-1:(im_start+1)

    save_path=cat(2,ROcoll_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
    % *** load collision data
    load(cat(2,save_path,'Ncorr.mat'),'Ncorr');
    load(cat(2,save_path,'corrected_celldata.mat'),'corrected_celldata');
    load(cat(2,save_path,'corrected_cellboundLC.mat'),'corrected_cellboundLC');
    load(cat(2,save_path,'corrected_cellmaskLC.mat'),'corrected_cellmaskLC');
    load(cat(2,save_path,'corrected_idx.mat'),'corrected_idx');
    load(cat(2,save_path,'Ncolli.mat'),'Ncolli');
    load(cat(2,save_path,'collider_celldata.mat'),'collider_celldata');
    load(cat(2,save_path,'collider_cellboundLC.mat'),'collider_cellboundLC');
    load(cat(2,save_path,'collider_cellmaskLC.mat'),'collider_cellmaskLC');
    load(cat(2,save_path,'Nrscd.mat'),'Nrscd');
    load(cat(2,save_path,'rescued_celldata.mat'),'rescued_celldata');
    load(cat(2,save_path,'rescued_cellboundLC.mat'),'rescued_cellboundLC');
    load(cat(2,save_path,'rescued_cellmaskLC.mat'),'rescued_cellmaskLC');


    % *** add and correct
    if Ncorr>0
      for cor=1:Ncorr
        idx=corrected_idx(cor,1);
        celldata_FB(idx,:)=corrected_celldata(cor,:);
        cellboundLC_FB{idx,1}=corrected_cellboundLC{cor,1};
        cellmaskLC_FB{idx,1}=corrected_cellmaskLC{cor,1};
        cellBF_FB(idx,:)=nan(1,8);
      end % for cor
    end % if Ncorr>0
    Nnew=Ncolli+Nrscd;
    if Ncolli>0
      new_celldata=cat(1,new_celldata,collider_celldata);
      new_cellboundLC=cat(1,new_cellboundLC,collider_cellboundLC);
      new_cellmaskLC=cat(1,new_cellmaskLC,collider_cellmaskLC);
      new_cellBF=cat(1,new_cellBF,nan(Ncolli,8));
    end % if Ncolli>0
    if Nrscd>0
      new_celldata=cat(1,new_celldata,cat(2,rescued_celldata,nan(Nrscd,1)));
      new_cellboundLC=cat(1,new_cellboundLC,rescued_cellboundLC);
      new_cellmaskLC=cat(1,new_cellmaskLC,rescued_cellmaskLC);
      new_cellBF=cat(1,new_cellBF,nan(Nrscd,8));
    end % if Nrscd>0

  end % for im

  % *** add new cells
  celldata_FB=cat(1,celldata_FB,new_celldata);
  cellboundLC_FB=cat(1,cellboundLC_FB,new_cellboundLC);
  cellmaskLC_FB=cat(1,cellmaskLC_FB,new_cellmaskLC);
  cellBF_FB=cat(1,cellBF_FB,new_cellBF);

  % *** correct BF
  [Ncell,~]=size(celldata_FB);
  idxs=[1:Ncell]';
  logiidx=(isnan(cellBF_FB(:,4)))&(isnan(cellBF_FB(:,6)))&(isnan(cellBF_FB(:,8)));
  Nbf2cor=sum(logiidx(:));
  new_BF_list=zeros(Nbf2cor,8);
  idxlist=idxs(logiidx,1);
  if Nbf2cor>0
    parfor modi=1:Nbf2cor
      idx=idxlist(modi,1);
      newBF=repair_cellBF_V3(ana_path,celldata_FB,idx,[]);
      new_BF_list(modi,:)=newBF;
    end % par for
    for modi=1:Nbf2cor
      idx=idxlist(modi,1);
      cellBF_FB(idx,:)=new_BF_list(modi,:);
    end % for modi
  end % if Nmodif



  % *** init tracking ******************************************************************
  % *******************************

  [Ncell,~]=size(celldata_FB);
  idxs=[1:Ncell]';

  im_p=im_stop;
  logiidx_p=(celldata_FB(:,3)==im_p);
  Np=sum(logiidx_p(:));
  short_celldata_p=zeros(Np,11,'single');
  idxlist_p=zeros(Np,1);
  idxlist_p=idxs(logiidx_p,1);
  short_celldata_p=single(celldata_FB(logiidx_p,:));
  %short_celldata_p=single(short_celldata_p);

  for im=im_stop:-1:(im_start+1)

    save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');

    im_c=im;
    im_p=im-1;
    % init short_celldata_c
    short_celldata_c=zeros(Np,11,'single');
    idxlist_c=zeros(Np,1);
    % c = p from loop before
    short_celldata_c=short_celldata_p;
    idxlist_c=idxlist_p;
    Nc=Np;
    % select data prev
    logiidx_p=(celldata_FB(:,3)==im_p);
    Np=sum(logiidx_p(:));
    short_celldata_p=zeros(Np,11,'single');
    idxlist_p=zeros(Np,1);
    short_celldata_p=single(celldata_FB(logiidx_p,:));
    idxlist_p=idxs(logiidx_p,1);

    save(cat(2,save_path,'short_celldata_c.mat'),'short_celldata_c','-v7.3','-nocompression');
    save(cat(2,save_path,'short_celldata_p.mat'),'short_celldata_p','-v7.3','-nocompression');
    save(cat(2,save_path,'idxlist_c.mat'),'idxlist_c','-v7.3','-nocompression');
    save(cat(2,save_path,'idxlist_p.mat'),'idxlist_p','-v7.3','-nocompression');
    save(cat(2,save_path,'Nc.mat'),'Nc','-v7.3','-nocompression');
    save(cat(2,save_path,'Np.mat'),'Np','-v7.3','-nocompression');

  end % for im




  % *** do tracking feedback  *********************************************************
  % *******************************

  optim_reached=0;
  parfor im=(im_start+1):im_stop
    [isoptim,~]=do_tracking_feedback_V2(ana_path,im);
    optim_reached=optim_reached+isoptim;
  end % parfor im


  fprintf('---> Optimum reached for %4f %% of images pairs\n',100*optim_reached/(im_stop-im_start));
  optim_vs_loop(loops_done+1,1)=optim_reached/(im_stop-im_start);



  % *** combine tracking data *********************************************************
  % *******************************

  % *** init last frame
  im=im_stop;
  save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
  load(cat(2,save_path,'idxlist_c.mat'),'idxlist_c');
  [Nc,~]=size(idxlist_c);
  ID_list=[1:Nc]';
  maxID=Nc;

  [Ncell,~]=size(celldata_FB);

  cellsID=zeros(Ncell,1);
  cellsID(1:Nc,1)=ID_list;

  cellidx=zeros(Ncell,1);
  cellidx(1:Nc,1)=idxlist_c;

  % OUTPUTS
  nit_avg=0;
  optim_reached=0;

  cidx=Nc;

  for im=im_stop:-1:(im_start+1)

    save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
    load(cat(2,save_path,'idxlist_p.mat'),'idxlist_p');
    load(cat(2,save_path,'idxlist_c.mat'),'idxlist_c');

    [Nc,~]=size(idxlist_c);
    [Np,~]=size(idxlist_p);

    load(cat(2,save_path,'attrib.mat'),'attrib');

    next_ID_list=zeros(Np,1);

    % link to previous frame
    for np=1:Np
      cidx=cidx+1;
      cellidx(cidx,1)=idxlist_p(np,1);
      [L,~]=find(attrib(:,np)==single(1));
      if L==(Nc+1)
        maxID=maxID+1;
        cellsID(cidx,1)=maxID;
        next_ID_list(np,1)=maxID;
      else
        cellsID(cidx,1)=ID_list(L,1);
        next_ID_list(np,1)=ID_list(L,1);
      end % if
    end % for n2

    ID_list=next_ID_list;

  end % for im

  sorted_celldata=cat(2,celldata_FB(cellidx,:),cellsID);
  sorted_cellmaskLC=cellmaskLC_FB(cellidx,:);
  sorted_cellboundLC=cellboundLC_FB(cellidx,:);
  sorted_cellBF=cellBF_FB(cellidx,:);



  % *** repair over split ******************************************************************
  % *******************************

  idxlist_modif=[];
  cellMLC_modif={};
  cellBLC_modif={};
  cellID_modif=[];
  idxlist_rmvd=[];

  % ***
  % *** detect oversplitting
  for im=(im_start+1):(im_stop-1)
   [idxlist_modif_t,cellMLC_modif_t,cellBLC_modif_t,cellID_modif_t,idxlist_rmvd_t]=repair_oversplit_V2(im,sorted_celldata,sorted_cellboundLC,sorted_cellBF,sorted_cellmaskLC,Lmax,Nitemax,dpix_tol,mitoCONTRAST_TH1,deepTH_repairSPLIT,NL,NC);
    sorted_celldata(idxlist_modif_t,12)=cellID_modif_t;
    idxlist_modif=cat(1,idxlist_modif,idxlist_modif_t);
    cellMLC_modif=cat(1,cellMLC_modif,cellMLC_modif_t);
    cellBLC_modif=cat(1,cellBLC_modif,cellBLC_modif_t);
    cellID_modif=cat(1,cellID_modif,cellID_modif_t);
    idxlist_rmvd=cat(1,idxlist_rmvd,idxlist_rmvd_t);
  end % for im

  % ***
  % *** repair celldata
  [Nmodif,~]=size(idxlist_modif);
  new_scd_list=zeros(Nmodif,12);
  NL=NL; % this is there for NL and NC to exist...
  NC=NC;
  parfor modi=1:Nmodif
    idx=idxlist_modif(modi,1);
    new_scd=repair_cellFEAT_V10(ana_path,sorted_celldata(idx,:),cellMLC_modif{modi,1},NL,NC);
    new_scd_list(modi,:)=new_scd;
  end % par for
  for modi=1:Nmodif
    idx=idxlist_modif(modi,1);
    sorted_celldata(idx,:)=new_scd_list(modi,:);
    sorted_celldata(idx,12)=cellID_modif(modi,1);
    sorted_cellmaskLC{idx,1}=cellMLC_modif{modi,1};
    sorted_cellboundLC{idx,1}=cellBLC_modif{modi,1};
  end % for modi

  % ***
  % *** repair cellBF
  new_BF_list=zeros(Nmodif,8);
  parfor modi=1:Nmodif
    idx=idxlist_modif(modi,1);
    newBF=repair_cellBF_V3(ana_path,sorted_celldata,idx,idxlist_rmvd);
    new_BF_list(modi,:)=newBF;
  end % par for

  for modi=1:Nmodif
    idx=idxlist_modif(modi,1);
    sorted_cellBF(idx,:)=new_BF_list(modi,:);
  end % for modi

  % ***
  % ***  remove cells
  sorted_celldata(idxlist_rmvd,:)=[];
  sorted_cellmaskLC(idxlist_rmvd,:)=[];
  sorted_cellboundLC(idxlist_rmvd,:)=[];
  sorted_cellBF(idxlist_rmvd,:)=[];

  % ***
  % *** repair cellBF time series
  %  we do not use stdBF nor meanBF ...
  %  so we do not repair it...

  fprintf('---> found %05d over-splitted cells \n',Nmodif);
  Novsp_vs_loop(loops_done+1,1)=Nmodif;

  % *** conditions to quit loop ******************************************************************
  % *******************************

  loops_done=loops_done+1;
  if loops_done>=NloopFB
    do_stop=1;
  end % if
  if (Ncolliders==0)&&(Nrescued==0)
    do_stop=1;
  end % if

end % while do_stop==0

fprintf('\n')


fprintf('*** BUILD cell Area and Perimeter data ...')

[Ncell,~]=size(sorted_celldata);
sorted_cellAP=zeros(Ncell,2);
for ce=1:Ncell
  MLC=sorted_cellmaskLC{ce,1};
  BLC=sorted_cellboundLC{ce,1};
  [AA,~]=size(MLC);
  [PP,~]=size(BLC);
  sorted_cellAP(ce,1)=AA;
  sorted_cellAP(ce,2)=PP;
end % for ce

fprintf(' DONE !\n')

fprintf('*** SAVE data ...')

save(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellAP.mat'),'sorted_cellAP','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF','-v7.3','-nocompression');

save(cat(2,ROdir,'Ncor_vs_loop.mat'),'Ncor_vs_loop','-v7.3','-nocompression');
save(cat(2,ROdir,'Ncol_vs_loop.mat'),'Ncol_vs_loop','-v7.3','-nocompression');
save(cat(2,ROdir,'Nrscd_vs_loop.mat'),'Nrscd_vs_loop','-v7.3','-nocompression');
save(cat(2,ROdir,'optim_vs_loop.mat'),'optim_vs_loop','-v7.3','-nocompression');
save(cat(2,ROdir,'Novsp_vs_loop.mat'),'Novsp_vs_loop','-v7.3','-nocompression');

fprintf(' DONE !\n')

delete(POOLOBJ);

end % function
