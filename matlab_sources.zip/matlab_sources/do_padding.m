function padded_image=do_padding(theimage,dpix,NL,NC,Lmesh,Cmesh)

padded_image=zeros(3*NL,3*NC);

logiidx2=zeros(NL,NC,'logical');
logiidx2=(~isinf(theimage))&(~isnan(theimage));
immaxi=10*max(theimage(logiidx2));

[GC,GL]=gradient(theimage);

padded_image((NL+1):(2*NL),(NC+1):(2*NC))=theimage;

% right side
XX=[(NC+1):(2*NC)];
for ll=1:NL
  A=theimage(ll,NC);
  GG=mean(GL(ll,(NC-dpix):NC));
  k=GG/A;
  if k>0
    k=0;
  end
  padding=A*exp(k*(XX-NC));
  logiidx=(isinf(padding))|(isnan(padding))|(padding>immaxi);
  if sum(logiidx(:))==0
    padded_image(NL+ll,(2*NC+1):(3*NC))=padding;
  elseif (isnan(A))|(isinf(A))
    padded_image(NL+ll,(2*NC+1):(3*NC))=0;
  else
    padded_image(NL+ll,(2*NC+1):(3*NC))=A;
  end % if
end % for ll

% left side
XX=[0:(NC-1)];
for ll=1:NL
  A=theimage(ll,1);
  GG=mean(GL(ll,1:dpix));
  k=-GG/A;
  if k>0
    k=0;
  end
  padding=fliplr(A*exp(k*(XX-1)));
  logiidx=(isinf(padding))|(isnan(padding))|(padding>immaxi);
  if sum(logiidx(:))==0
    padded_image(NL+ll,1:NC)=padding;
  elseif (isnan(A))|(isinf(A))
    padded_image(NL+ll,1:NC)=0;
  else
    padded_image(NL+ll,1:NC)=A;
  end % if
end % for ll

% down side
XX=[(NL+1):(2*NL)]';
for cc=1:NC
  A=theimage(NL,cc);
  GG=mean(GL((NL-dpix):NL,cc));
  k=GG/A;
  if k>0
    k=0;
  end
  padding=A*exp(k*(XX-NC));
  logiidx=(isinf(padding))|(isnan(padding))|(padding>immaxi);
  if sum(logiidx(:))==0
    padded_image((2*NL+1):(3*NL),NC+cc)=padding;
  elseif (isnan(A))|(isinf(A))
    padded_image((2*NL+1):(3*NL),NC+cc)=0;
  else
    padded_image((2*NL+1):(3*NL),NC+cc)=A;
  end % if
end % for ll

% up side
XX=[0:(NL-1)]';
for cc=1:NC
  A=theimage(1,cc);
  GG=mean(GL(1:dpix,cc));
  k=-GG/A;
  if k>0
    k=0;
  end
  padding=flipud(A*exp(k*(XX-1)));
  logiidx=(isinf(padding))|(isnan(padding))|(padding>immaxi);
  if sum(logiidx(:))==0
    padded_image(1:NL,NC+cc)=padding;
  elseif (isnan(A))|(isinf(A))
    padded_image(1:NL,NC+cc)=0;
  else
    padded_image(1:NL,NC+cc)=A;
  end % if
end % for ll


% upper right corner
GGC=GC(1:dpix,(NC-dpix):NC); GGC=mean(GGC(:));
GGL=GL(1:dpix,(NC-dpix):NC); GGL=mean(GGL(:));
A=theimage(1,NC);
kC=GGC/A;
if kC>0
  kC=0;
end
kL=-GGL/A;
if kL>0
  kL=0;
end

padding=flipud(A*exp(kL*(Lmesh-1)).*exp(kC*(Cmesh-1)));
logiidx=(isinf(padding))|(isnan(padding))|(padding>immaxi);
if sum(logiidx(:))==0
  padded_image(1:NL,(2*NC+1):(3*NC))=padding;
elseif (isnan(A))|(isinf(A))
  padded_image(1:NL,(2*NC+1):(3*NC))=0;
else
  padded_image(1:NL,(2*NC+1):(3*NC))=A;
end % if



% upper left corner
GGC=GC(1:dpix,1:dpix); GGC=mean(GGC(:));
GGL=GL(1:dpix,1:dpix); GGL=mean(GGL(:));
A=theimage(1,1);
kC=-GGC/A;
if kC>0
  kC=0;
end
kL=-GGL/A;
if kL>0
  kL=0;
end

padding=fliplr(flipud(A*exp(kL*(Lmesh-1)).*exp(kC*(Cmesh-1))));
logiidx=(isinf(padding))|(isnan(padding))|(padding>immaxi);
if sum(logiidx(:))==0
  padded_image(1:NL,1:NC)=padding;
elseif (isnan(A))|(isinf(A))
  padded_image(1:NL,1:NC)=0;
else
  padded_image(1:NL,1:NC)=A;
end % if


% lower left corner
GGC=GC((NL-dpix):NL,1:dpix); GGC=mean(GGC(:));
GGL=GL((NL-dpix):NL,1:dpix); GGL=mean(GGL(:));
A=theimage(NL,1);
kC=-GGC/A;
if kC>0
  kC=0;
end
kL=GGL/A;
if kL>0
  kL=0;
end

padding=fliplr(A*exp(kL*(Lmesh-1)).*exp(kC*(Cmesh-1)));
logiidx=(isinf(padding))|(isnan(padding))|(padding>immaxi);
if sum(logiidx(:))==0
  padded_image((2*NL+1):(3*NL),1:NC)=padding;
elseif (isnan(A))|(isinf(A))
  padded_image((2*NL+1):(3*NL),1:NC)=0;
else
  padded_image((2*NL+1):(3*NL),1:NC)=A;
end % if


% lower right corner
GGC=GC((NL-dpix):NL,(NC-dpix):NC); GGC=mean(GGC(:));
GGL=GL((NL-dpix):NL,(NC-dpix):NC); GGL=mean(GGL(:));
A=theimage(NL,NC);
kC=GGC/A;
if kC>0
  kC=0;
end
kL=GGL/A;
if kL>0
  kL=0;
end

padding=A*exp(kL*(Lmesh-1)).*exp(kC*(Cmesh-1));
logiidx=(isinf(padding))|(isnan(padding))|(padding>immaxi);
if sum(logiidx(:))==0
  padded_image((2*NL+1):(3*NL),(2*NC+1):(3*NC))=padding;
elseif (isnan(A))|(isinf(A))
  padded_image((2*NL+1):(3*NL),(2*NC+1):(3*NC))=0;
else
  padded_image((2*NL+1):(3*NL),(2*NC+1):(3*NC))=A;
end % if

end % function
