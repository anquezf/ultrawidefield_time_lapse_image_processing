function [bkg_mask,foreg_mask]=make_foregbkgmask(mask,Nreg,NL,NC,radius)

foreg_mask=mask>0;

radius_sq=radius*radius;
[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);
bkg_mask=zeros(NL,NC,'logical');
mm=zeros(NL,NC,'logical');

for reg=1:Nreg

  mm=(mask==reg);
  Cc=mean(Cmesh(mm));
  Lc=mean(Lmesh(mm));
  
  mm=((power(Lmesh-Lc,2)+power(Cmesh-Cc,2))<radius_sq);
  bkg_mask(mm)=1;

end % for reg

bkg_mask=~bkg_mask;

end % fucntion
  
