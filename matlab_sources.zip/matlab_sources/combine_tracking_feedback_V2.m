function cellidx=combine_tracking_feedback_V2(ana_path)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'Nim.mat'));

ROdir=cat(2,ana_path,'tracking_collision_feedback/');
ROcoll_dir=cat(2,ROdir,'collision_detection/');
ROtrack_dir=cat(2,ROdir,'linkage/');

% tracking params
track_path=cat(2,ana_path,'tracking/');
load(cat(2,track_path,'Nitemax.mat'),'Nitemax');

fprintf('load data ...')

% load cell data
load(cat(2,ROdir,'celldata_FB.mat'),'celldata_FB');
load(cat(2,ROdir,'cellboundLC_FB.mat'),'cellboundLC_FB');
load(cat(2,ROdir,'cellmaskLC_FB.mat'),'cellmaskLC_FB');

fprintf(' DONE ! -> ')

% *******************
% *** init last frame
% *******************

im=Nim;
save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
load(cat(2,save_path,'idxlist_c.mat'),'idxlist_c');

[Nc,~]=size(idxlist_c);
ID_list=[1:Nc]';
maxID=Nc;

[Ncell,~]=size(celldata_FB);

cellsID=zeros(Ncell,1);
cellsID(1:Nc,1)=ID_list;

cellidx=zeros(Ncell,1);
cellidx(1:Nc)=idxlist_c;

% OUTPUTS
nit_avg=0;
optim_reached=0;

cidx=Nc;
fprintf('combine tracking... ');
for im=Nim:-1:2

  save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
  load(cat(2,save_path,'idxlist_p.mat'),'idxlist_p');
  load(cat(2,save_path,'idxlist_c.mat'),'idxlist_c');

  [Nc,~]=size(idxlist_c);
  [Np,~]=size(idxlist_p);

  load(cat(2,save_path,'attrib.mat'),'attrib');

  next_ID_list=zeros(Np,1);

  % link to previous frame
  for np=1:Np

    cidx=cidx+1;
    cellidx(cidx,1)=idxlist_p(np,1);

    [L,~]=find(attrib(:,np)==single(1));

    if L==(Nc+1)
      maxID=maxID+1;
      cellsID(cidx,1)=maxID;
      next_ID_list(np,1)=maxID;
    else
      cellsID(cidx,1)=ID_list(L,1);
      next_ID_list(np,1)=ID_list(L,1);
    end % if

  end % for n2

  ID_list=next_ID_list;

end % for im
fprintf(' DONE ! -> ')


% *** SAVE

% tracking params
save_path=cat(2,ana_path,'tracking/');
load(cat(2,save_path,'Nitemax.mat'),'Nitemax');


sorted_celldata=cat(2,celldata_FB(cellidx,:),cellsID);
%sorted_celldata=cat(2,celldata_FB(cellidx,:),cellsID);
sorted_cellmaskLC=cellmaskLC_FB(cellidx,:);
sorted_cellboundLC=cellboundLC_FB(cellidx,:);

fprintf('save data...')
save(cat(2,ROdir,'sorted_celldata.mat'),'sorted_celldata','-v7.3','-nocompression');
save(cat(2,ROdir,'sorted_cellmaskLC.mat'),'sorted_cellmaskLC','-v7.3','-nocompression');
save(cat(2,ROdir,'sorted_cellboundLC.mat'),'sorted_cellboundLC','-v7.3','-nocompression');
%}

fprintf(' DONE ! \n')

end % function


