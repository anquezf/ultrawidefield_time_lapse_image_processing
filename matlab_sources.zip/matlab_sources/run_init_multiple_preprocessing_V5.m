function run_init_multiple_preprocessing_V5(save_dir,pad_dpix_str,fWFF_str,FFmini_str,deltai_str,imini_str,imaxi_str,fW1_str,fW2_str,Nsig_str,NBMAX_str)

warning off


fprintf('\n*** Please select A BUNCH of EXISTING experiments\n')
ana_path_list=uipickfiles('FilterSpec',save_dir)';
fprintf('\n');

[Nexpe,~]=size(ana_path_list);
for expe=1:Nexpe
  ana_path=ana_path_list{expe,1};
  [~,Nchar]=size(ana_path);
  if ~(strcmp(ana_path(1,Nchar),'/'))
    ana_path=cat(2,ana_path,'/');
  end % if
  ana_path_list{expe,1}=ana_path;
  fprintf(cat(2,ana_path,'\n'));
end % for exp



% ********************************************
% *** save current ana_path_list and NBmax ***
% ********************************************

run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if

save(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe','-v7.3','-nocompression');

NBMAX=str2double(NBMAX_str);
save(cat(2,run_path,'run_vars/cur_NBMAX.mat'),'NBMAX','-v7.3','-nocompression');

% **********************
% *** preproc params ***
% **********************

deltai=str2double(deltai_str);
imaxi=str2double(imaxi_str);
imini=str2double(imini_str);
iedges=(imini:deltai:imaxi)';

Nsig=str2double(Nsig_str);

fW1=str2double(fW1_str);
fW2=str2double(fW2_str);

pad_dpix=str2double(pad_dpix_str);
fWFF=str2double(fWFF_str);
FFmini=str2double(FFmini_str);

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ********************* ***\n');
fprintf('*** SAVE input parameters ***\n');
fprintf('*** ********************* ***\n');
fprintf('\n');

for expe=1:Nexpe

  ana_path=ana_path_list{expe,1};

  save(cat(2,ana_path,'deltai.mat'),'deltai','-v7.3','-nocompression');
  save(cat(2,ana_path,'imaxi.mat'),'imaxi','-v7.3','-nocompression');
  save(cat(2,ana_path,'imini.mat'),'imini','-v7.3','-nocompression');
  save(cat(2,ana_path,'iedges.mat'),'iedges','-v7.3','-nocompression');

  save(cat(2,ana_path,'Nsig.mat'),'Nsig','-v7.3','-nocompression');

  save(cat(2,ana_path,'fW1.mat'),'fW1','-v7.3','-nocompression');
  save(cat(2,ana_path,'fW2.mat'),'fW2','-v7.3','-nocompression');

  save(cat(2,ana_path,'pad_dpix.mat'),'pad_dpix','-v7.3','-nocompression');
  save(cat(2,ana_path,'fWFF.mat'),'fWFF','-v7.3','-nocompression');
  save(cat(2,ana_path,'FFmini.mat'),'FFmini','-v7.3','-nocompression');

end %for expe


end % function

