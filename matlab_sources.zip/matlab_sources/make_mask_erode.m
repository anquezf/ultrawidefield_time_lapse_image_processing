function [mask_out,Nreg_out]=make_mask_erode(Nreg_in,NL,NC,mask_in,se,Nloop)

mask_cell=zeros(NL,NC);
mask_out=zeros(NL,NC);
Lmask=zeros(NL,NC);
mask_temp=zeros(NL,NC);

Nreg_out=0;

for c=1:Nreg_in

  is_spl=0;
  mask_cell=(mask_in==c);

  % start splitting
  for l=1:Nloop
  if is_spl==0

    mask_cell=imerode(mask_cell,se);
    [Lmask,NN]=bwlabel(mask_cell);
    if NN>1
      is_spl=1;
      for r=1:NN
        mask_temp=(Lmask==r);
        % re-dilate
        for ll=1:l mask_temp=imdilate(mask_temp,se); end % for ll
        Nreg_out=Nreg_out+1;
	mask_out((mask_temp>0))=Nreg_out;
      end % for r
    end % if

  end % if not is_spl
  end % for l

  if is_spl==0
    mask_temp=(mask_in==c);
    Nreg_out=Nreg_out+1;
    mask_out(mask_temp)=Nreg_out;
  end % if

end % for c


end % function
