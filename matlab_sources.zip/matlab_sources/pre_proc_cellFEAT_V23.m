function pre_proc_cellFEAT_V23(ana_path,pos)

warning off

% *** OUTPUTS ***

%             1  2   3      4     5          6   7   8   9   10 
% cell_List=[ X ,Y , imidx, Area, Intensity, L,  C,  wB, wS, p  ]
%             um um  idx    Npix  a.u.       pix pix um  um  idx

% maskLC_List={ [L1,C1 ; L2,C2 ; ... LA,CA] ; ... }

% Nreg _List=[Nreg1 ; Nreg 2 ; ... ]

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'scale.mat'),'scale');
load(cat(2,ana_path,'fW1.mat'),'fW1');
load(cat(2,ana_path,'fW2.mat'),'fW2');
load(cat(2,ana_path,'Nsig.mat'),'Nsig');
load(cat(2,ana_path,'fWmf.mat'),'fWmf');
load(cat(2,ana_path,'Nite.mat'),'Nite');
load(cat(2,ana_path,'deepTH_SPLIT.mat'),'deepTH_SPLIT');
load(cat(2,ana_path,'Nloop.mat'),'Nloop');


% analysis infos (global)
% *** load analysis infos
% FFcor
load(cat(2,ana_path,'useFFforeg.mat'),'useFFforeg');
load(cat(2,ana_path,'FF_NUC.mat'),'FF');
load(cat(2,ana_path,'FF_bkg.mat'),'FF_bkg');
load(cat(2,ana_path,'FF_foreg.mat'),'FF_foreg');
load(cat(2,ana_path,'imoffset.mat'),'imoffset');
% number of images
load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');
% image sizing
load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);

% image re-sizing
Lc_abs=NL/2;
Cc_abs=NC/2;
rszNL=scale*NL;
rszNC=scale*NC;
[rszCmesh,rszLmesh]=meshgrid(1:rszNC,1:rszNL);

% image positionning
load(cat(2,ana_path,'pixsize.mat'),'pixsize');
load(cat(2,ana_path,'flipUD.mat'),'flipUD');
load(cat(2,ana_path,'flipLR.mat'),'flipLR');
rszfW1=fW1/(pixsize/scale);
rszfW2=fW2/(pixsize/scale);

fWmf=round(fWmf/(pixsize));
if fWmf<2 fWmf=2; end


pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
bkg_mask_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/MASK_NUC/bkg_masks/');
mask_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/MASK_NUC/masks/');
mkdir(mask_ana_dir);
ROdir=cat(2,pos_ana_dir,'cell_data/');
mkdir(ROdir);


load(cat(2,pos_ana_dir,'XYfield.mat'),'XYfield');
Xc=XYfield(1,1);
Yc=XYfield(1,2);

% *** load position infos
load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');
load(cat(2,pos_ana_dir,'fileListN.mat'),'fileListN');

% load bkg pdf
load(cat(2,ana_path,'mu_cor_all.mat'),'mu_cor_all');
load(cat(2,ana_path,'sig_cor_all.mat'),'sig_cor_all');

load(cat(2,ana_path,'b0.mat'),'b0');
load(cat(2,ana_path,'delta_b_vsim.mat'),'delta_b_vsim');

% some variables
se2=strel('disk',2);
se1=strel('disk',1);

theimage=zeros(NL,NC);
theimage_f=zeros(NL,NC);
theimage_mf=zeros(NL,NC);

mask=zeros(NL,NC);

bkg_mask=zeros(NL,NC,'logical');

bkg_mask_rsz=zeros(rszNL,rszNC,'logical');

mask_ini_neighbhd=zeros(rszNL,rszNC);
mask1=zeros(rszNL,rszNC);

theimage_rsz=zeros(rszNL,rszNC);
theimage_rsz_f=zeros(rszNL,rszNC);
theimage_rsz_mf=zeros(rszNL,rszNC);

Nreg=0;

% *** outputs
cell_List=[];     %            1  2   3      4     5          6   7   8   9   10 
                  %cell_List=[ X ,Y , imidx, Area, Intensity, L,  C,  wB, wS, p  ]
                  %            um um  idx    Npix  a.u.       pix pix um  um  idx
maskLC_List={};   % maskLC_List={ [L1,C1 ; L2,C2 ; ... LA,CA] ; ... }
Nreg_List=zeros(Nim,1);
boundLC_List={};  % bond_list={ [Lb1,Cb1 ; Lb2,Cb2 ; ... Lbn,Cbn] ; ... }

for im=im_start:im_stop

  mask=zeros(NL,NC);

  % *** find idx
  idx=imidx_2_lidx(im,1);

  % *** load raw data
  theimage=double(imread(fileListN{idx,1}));
  theimage=(theimage-imoffset);

  % *** image restoration
  theimage=theimage-(b0+delta_b_vsim(1,im))*FF_bkg;

  if useFFforeg==1
    theimage=theimage./FF_foreg;
  end % if

  theimage=theimage-mu_cor_all(1,im);
  

  % flip ?
  if flipUD>0 theimage=flipud(theimage); end % if
  % flip ?
  if flipLR>0 theimage=fliplr(theimage); end % if

  % *** resize
  theimage_rsz=imresize(theimage,scale);

  % medfilt
  theimage_mf=medfilt2(theimage,[fWmf fWmf]);
  theimage_rsz_mf=imresize(theimage_mf,scale);
  

  % *** detect local maximas
  theimage_rsz_f=make_nuc_blur_V3(theimage_rsz_mf,rszfW1,rszfW2);
  sig_tot=sig_cor_all(1,im);
  ITH=Nsig*sig_tot;
  [mask_ini_neighbhd,Nreg]=make_mask_init_V8(theimage_rsz_f,theimage_rsz_mf,rszNL,rszNC,rszLmesh,rszCmesh,ITH,2,rszfW2);

  if Nreg>0
    [mask_ini_neighbhd]=make_mask_clean_smalls_V2(mask_ini_neighbhd,Nreg,rszNL,rszNC);
    [mask1,~]=make_mask_shrinking_local_otsu_at_border_V5(Nreg,mask_ini_neighbhd,theimage_rsz_mf,rszNL,rszNC,Nite,se2,0);
    [mask1,Nreg]=make_mask_check_empty(mask1,Nreg,rszNL,rszNC);
    % post-processing
    [mask1]=make_mask_fill_holes_V2(mask1,Nreg,rszNL,rszNC);
    [mask1,Nreg]=make_mask_split_V6(mask1,Nreg,rszNL,rszNC,deepTH_SPLIT,se1);
    [mask1]=make_mask_clean_smalls_V2(mask1,Nreg,rszNL,rszNC);
    [mask1,Nreg]=make_mask_erode(Nreg,rszNL,rszNC,mask1,se1,Nloop);
    % resize
    mask=make_mask_resize_V2(mask1,Nreg,NL,NC,1/scale);
    % post-process real size
    [mask,~]=make_mask_shrinking_local_otsu_at_border_V5(Nreg,mask,theimage_mf,NL,NC,Nite,se1,0);
    [mask,Nreg]=make_mask_check_empty(mask,Nreg,NL,NC);
    [mask]=make_mask_clean_smalls_V2(mask,Nreg,NL,NC);
  else
    mask=zeros(NL,NC);
  end % if Nreg>0

  if Nreg<1
    Nreg_List(im,1)=0;
  else
    % we are going to create cell_List
    % and maskLC_List and boundLC_List
    Nreg_List(im,1)=Nreg;
    [cells,LClist,BOUNDlist]=get_cellFEAT_V8(Nreg,mask,theimage,NL,NC,Xc,Yc,im,Lc_abs,Cc_abs,pixsize,pos-1);
    %            1  2   3      4     5          6   7   8   9   10 
    %cell_List=[ X ,Y , imidx, Area, Intensity, L,  C,  wB, wS, p  ]
    %            um um  idx    Npix  a.u.       pix pix um  um  idx
    cell_List=cat(1,cell_List,cells);
    % LClist={ [L1,C1 ; L2,C2 ; ... LA,CA] ; ... }
    maskLC_List=cat(1,maskLC_List,LClist);
    % BOUNDlist={ [Lb1,Cb1 ; Lb2,Cb2 ; ... Lbn,Cbn] ; ... }
    boundLC_List=cat(1,boundLC_List,BOUNDlist);
  end % if

  mask=sparse(mask);
  % save mask
  save(cat(2,mask_ana_dir,'mask_im',num2str(im,'%05d'),'.mat'),'mask');


end %for im

save(cat(2,ROdir,'cell_List.mat'),'cell_List','-v7.3','-nocompression');
save(cat(2,ROdir,'Nreg_List.mat'),'Nreg_List','-v7.3','-nocompression');
save(cat(2,ROdir,'maskLC_List.mat'),'maskLC_List','-v7.3','-nocompression');
save(cat(2,ROdir,'boundLC_List.mat'),'boundLC_List','-v7.3','-nocompression');

end % function
