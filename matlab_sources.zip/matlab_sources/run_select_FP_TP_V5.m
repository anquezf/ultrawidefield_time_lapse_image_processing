function run_select_FP_TP_V4(ana_path,Nbunch_str,loadPINI_str,save_dir)

LW=3;
FS=15;

fprintf('--- False Positve and True Positive cells splitting --- \n')
fprintf('\n')

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

warning off


% *** inputs
Nbunch=str2double(Nbunch_str);
save(cat(2,ana_path,'CLEANCELLDATA/Nbunch.mat'),'Nbunch','-v7.3','-nocompression');

loadPINI=str2double(loadPINI_str);
save(cat(2,ana_path,'loadPINI.mat'),'loadPINI','-v7.3','-nocompression');

if loadPINI==1

  fprintf('*** Please select A SINGLE experiment\n')
  ref_ana_path=uipickfiles('FilterSpec',save_dir)';
  ref_ana_path=ref_ana_path{1,1};
  fprintf('\n');

  fprintf('loading data ...')

  [~,Nchar]=size(ref_ana_path);
  if ~(strcmp(ref_ana_path(1,Nchar),'/'))
  ref_ana_path=cat(2,ref_ana_path,'/');
  end % if

  load(cat(2,ref_ana_path,'CLEANCELLDATA/IMAXI_list.mat'),'IMAXI_list');
  load(cat(2,ref_ana_path,'CLEANCELLDATA/AMAXI_list.mat'),'AMAXI_list');
  load(cat(2,ref_ana_path,'CLEANCELLDATA/AFP_list.mat'),'AFP_list');
  load(cat(2,ref_ana_path,'CLEANCELLDATA/IFP_list.mat'),'IFP_list');
  load(cat(2,ref_ana_path,'CLEANCELLDATA/C_list.mat'),'C_list');

  load(cat(2,ref_ana_path,'im_start.mat'),'im_start');
  load(cat(2,ref_ana_path,'im_stop.mat'),'im_stop');

  IMAXI0=mean(IMAXI_list(im_start:im_stop,1),'omitnan');
  AMAXI0=mean(AMAXI_list(im_start:im_stop,1),'omitnan');
  AFP0=mean(AFP_list(im_start:im_stop,1),'omitnan');
  IFP0=mean(IFP_list(im_start:im_stop,1),'omitnan');
  C0=mean(C_list(im_start:im_stop,1),'omitnan');

  fprintf('DONE !\n')

end % if
  



load(cat(2,ana_path,'Nim.mat'),'Nim')

if loadPINI==1
  % *** GUI
  fprintf('*** Starting User Interface ...\n')
  [IMAXI_list,AMAXI_list,AFP_list,IFP_list,C_list]=select_FP_TP_V4(ana_path,Nbunch,IMAXI0,AMAXI0,AFP0,IFP0,C0);
  fprintf('\n')
else
 % *** GUI
  fprintf('*** Starting User Interface ...\n')
  [IMAXI_list,AMAXI_list,AFP_list,IFP_list,C_list]=select_FP_TP_V4(ana_path,Nbunch);
  fprintf('\n')
end % if


% saving
fprintf('*** Saving FP/TP selection ...\n')
save(cat(2,ana_path,'CLEANCELLDATA/IMAXI_list.mat'),'IMAXI_list','-v7.3','-nocompression');
save(cat(2,ana_path,'CLEANCELLDATA/AMAXI_list.mat'),'AMAXI_list','-v7.3','-nocompression');
save(cat(2,ana_path,'CLEANCELLDATA/AFP_list.mat'),'AFP_list','-v7.3','-nocompression');
save(cat(2,ana_path,'CLEANCELLDATA/IFP_list.mat'),'IFP_list','-v7.3','-nocompression');
save(cat(2,ana_path,'CLEANCELLDATA/C_list.mat'),'C_list','-v7.3','-nocompression');
fprintf('DONE ! \n')





end % function
