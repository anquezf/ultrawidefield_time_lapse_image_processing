function process_fluoNUC_V4(ana_path,chanFluo,NL,NC,imoffset,flipUD,flipLR,FF_bkg,FF_foreg,b,num_cellID,Npos,im)

warning off

im_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/','images_infos/',num2str(im,'%0.5d'),'/');
load(cat(2,im_ana_dir,'fileListF_pos.mat'),'fileListF_pos');
load(cat(2,im_ana_dir,'time_s_pos.mat'),'time_s_pos');


% some variables
theimage=zeros(NL,NC);
theimage_raw=zeros(NL,NC);
theimage_sub=zeros(NL,NC);
theimage_cor=zeros(NL,NC);
theimage_dns=zeros(NL,NC);

mask_temp=zeros(NL,NC,'logical');

% *************
% *** cell data
INTEN_raw_im=nan(num_cellID,1);
INTEN_sub_im=nan(num_cellID,1);
INTEN_cor_im=nan(num_cellID,1);
INTEN_dns_im=nan(num_cellID,1);

BKG_raw_im=nan(num_cellID,1);
BKG_sub_im=nan(num_cellID,1);
BKG_cor_im=nan(num_cellID,1);
BKG_dns_im=nan(num_cellID,1);

AREA_im=nan(num_cellID,1);
TIMES_im=nan(num_cellID,1);

% **************
% *** fluo proc

load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/short_celldata.mat'),'short_celldata');
[NN,~]=size(short_celldata);
logiidx=zeros(NN,1,'logical');

for pos=1:Npos

  load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/',num2str(pos-1,'%0.5d'),'/bkg_mask.mat'))
  load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/',num2str(pos-1,'%0.5d'),'/cell_mask.mat'))

  logiidx=short_celldata(:,10)==(pos-1);
  scd=short_celldata(logiidx,:);

  % *** load raw data
  % *****************
  theimage=double(imread(fileListF_pos{pos,1}));
  % init_FLUO is preparing fileListF_pos with imdx and not lidx
  theimage=(theimage-imoffset);
  % flip ?
  if flipUD>0 theimage=flipud(theimage); end % if
  % flip ?
  if flipLR>0 theimage=fliplr(theimage); end % if

  % *** pre proc DATA
  % *****************
  % raw data
  theimage_raw=theimage;
  % remove background
  theimage_sub=theimage-b*FF_bkg;
  % correct FF
  theimage_cor=theimage_sub./FF_foreg;
  % denoise
  theimage_dns=medfilt2(theimage_cor,[3 3],'symmetric');

  % *** load time_s
  % *****************
  TT=time_s_pos(pos,1);

  % *** load cell data
  % *****************
  [Ncell,~]=size(scd);
  for ce=1:Ncell

    cellID=scd(ce,12);
    mask_temp=cell_mask==cellID;
    AA=sum(mask_temp(:));

    if AA>0
      AREA_im(cellID,1)=AA;
      TIMES_im(cellID,1)=TT;
      INTEN_raw_im(cellID,1)=sum(theimage_raw(mask_temp));
      INTEN_sub_im(cellID,1)=sum(theimage_sub(mask_temp));
      INTEN_cor_im(cellID,1)=sum(theimage_cor(mask_temp));
      INTEN_dns_im(cellID,1)=sum(theimage_dns(mask_temp));

      BKG_raw_im(cellID,1)=mean(theimage_raw(bkg_mask));
      BKG_sub_im(cellID,1)=mean(theimage_sub(bkg_mask));
      BKG_cor_im(cellID,1)=mean(theimage_cor(bkg_mask));
      BKG_dns_im(cellID,1)=mean(theimage_dns(bkg_mask));
    end % if idx>0

  end % for ce

end % for pos

im_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/','images_infos/',num2str(im,'%0.5d'),'/');

save(cat(2,im_ana_dir,'INTEN_raw_im.mat'),'INTEN_raw_im','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'INTEN_sub_im.mat'),'INTEN_sub_im','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'INTEN_cor_im.mat'),'INTEN_cor_im','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'INTEN_dns_im.mat'),'INTEN_dns_im','-v7.3','-nocompression');

save(cat(2,im_ana_dir,'BKG_raw_im.mat'),'BKG_raw_im','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'BKG_sub_im.mat'),'BKG_sub_im','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'BKG_cor_im.mat'),'BKG_cor_im','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'BKG_dns_im.mat'),'BKG_dns_im','-v7.3','-nocompression');

save(cat(2,im_ana_dir,'AREA_im.mat'),'AREA_im','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'TIMES_im.mat'),'TIMES_im','-v7.3','-nocompression');

end % function
