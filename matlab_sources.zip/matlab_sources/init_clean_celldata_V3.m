function init_clean_celldata_V3(ana_path,IBS,ABS)


warning off


[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% *** INPUTS
save(cat(2,ana_path,'IBS.mat'),'IBS','-v7.3','-nocompression');
save(cat(2,ana_path,'ABS.mat'),'ABS','-v7.3','-nocompression');

% *** load data
load(cat(2,ana_path,'pixsize.mat'),'pixsize')
load(cat(2,ana_path,'Nim.mat'),'Nim')
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');
load(cat(2,ana_path,'NL.mat'),'NL')
load(cat(2,ana_path,'NC.mat'),'NC')
load(cat(2,ana_path,'imaxi.mat'),'imaxi')
pixsize_sq=power(pixsize,2);

amaxi=(NL*NC/9)*pixsize_sq;

edgesI=((-5*IBS):IBS:imaxi+5*IBS)';
edgesA=((-5*ABS):ABS:amaxi+5*ABS)';

% *** prepare data for each postion
clean_ana_dir=cat(2,ana_path,'CLEANCELLDATA/');
mkdir(clean_ana_dir);

% *** save inputs
save(cat(2,clean_ana_dir,'imaxi.mat'),'imaxi','-v7.3','-nocompression');
save(cat(2,clean_ana_dir,'amaxi.mat'),'amaxi','-v7.3','-nocompression');
save(cat(2,clean_ana_dir,'IBS.mat'),'IBS','-v7.3','-nocompression');
save(cat(2,clean_ana_dir,'ABS.mat'),'ABS','-v7.3','-nocompression');
save(cat(2,clean_ana_dir,'edgesI.mat'),'edgesI','-v7.3','-nocompression');
save(cat(2,clean_ana_dir,'edgesA.mat'),'edgesA','-v7.3','-nocompression');

load(cat(2,ana_path,'combined_data/rawcelldata.mat'),'rawcelldata')
load(cat(2,ana_path,'combined_data/rawcellmaskLC.mat'),'rawcellmaskLC')


[Nreg,~]=size(rawcelldata);
INTENlist=rawcelldata(:,5);
for rr=1:Nreg
  mlc=rawcellmaskLC{rr,1};
  [AA,~]=size(mlc);
  AREAlist(rr,1)=AA*pixsize_sq;
end % for rr


save(cat(2,clean_ana_dir,'INTENlist.mat'),'INTENlist','-v7.3','-nocompression');
save(cat(2,clean_ana_dir,'AREAlist.mat'),'AREAlist','-v7.3','-nocompression');


idxs=[1:Nreg]';
for im=im_start:im_stop

  % *** select cell data
  logiidx=(rawcelldata(:,3)==im);
  short_idxlist=idxs(logiidx,1);
  short_INTENlist=INTENlist(logiidx,:);
  short_AREAlist=AREAlist(logiidx,:);

  clean_ana_dir=cat(2,ana_path,'CLEANCELLDATA/',num2str(im,'%0.5d'),'/');
  mkdir(clean_ana_dir);
  save(cat(2,clean_ana_dir,'short_idxlist.mat'),'short_idxlist','-v7.3','-nocompression');
  save(cat(2,clean_ana_dir,'short_INTENlist.mat'),'short_INTENlist','-v7.3','-nocompression');
  save(cat(2,clean_ana_dir,'short_AREAlist.mat'),'short_AREAlist','-v7.3','-nocompression');

end % for im



end % function
