function combine_duplicates_removal_V3(ana_path)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% *** load data
load(cat(2,ana_path,'Nim.mat'),'Nim')
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

modified_celldata=[];
rmvd_idxs=[];
modified_idxs=[];

fprintf('combining duplicate removal ...\n');
fprintf('load image data %5d of %5d',0,Nim);
for im=im_start:im_stop

  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',im,Nim);


  dup_ana_dir=cat(2,ana_path,'RMVDUP/',num2str(im,'%0.5d'),'/');

  load(cat(2,dup_ana_dir,'short_celldata_modified.mat'),'short_celldata_modified');
  load(cat(2,dup_ana_dir,'short_idx_rmvd.mat'),'short_idx_rmvd');
  load(cat(2,dup_ana_dir,'short_idx_modified.mat'),'short_idx_modified');

  % *** store data
  modified_celldata=cat(1,modified_celldata,short_celldata_modified);
  rmvd_idxs=cat(1,rmvd_idxs,short_idx_rmvd);
  modified_idxs=cat(1,modified_idxs,short_idx_modified);

end % for im
fprintf('\n')


load(cat(2,ana_path,'combined_data/celldata.mat'),'celldata');
load(cat(2,ana_path,'combined_data/cellmaskLC.mat'),'cellmaskLC');
load(cat(2,ana_path,'combined_data/cellboundLC.mat'),'cellboundLC');

[Nrmvd,~]=size(rmvd_idxs);
[Nmodif,~]=size(modified_idxs);
[Nreg,~]=size(celldata);
Ncell=Nreg-Nrmvd;

celldata_clean=zeros(Ncell,11);
cellmaskLC_clean=cell(Ncell,1);
cellboundLC_clean=cell(Ncell,1);


fprintf('load cell data %9d of %9d',0,Nreg);
ncell=0;
for c=1:Nreg

  % *** display status...
  for id=1:22
  fprintf('\b');
  end % for id
  fprintf('%9d of %9d',c,Nreg);


  logiidx=(rmvd_idxs==c);
  if sum(logiidx(:))==0

    ncell=ncell+1;

    logiidx2=(modified_idxs==c);
    if sum(logiidx2(:))==1
      ii=find(logiidx2);
      celldata_clean(ncell,:)=modified_celldata(ii,:);
    else
      celldata_clean(ncell,:)=cat(2,celldata(c,:),NaN);
    end % if

    cellmaskLC_clean{ncell,1}=cellmaskLC{c,1};
    cellboundLC_clean{ncell,1}=cellboundLC{c,1};

  end % if

end % for c
fprintf('\n')

fprintf('save data : ');
save(cat(2,ana_path,'combined_data/celldata_clean.mat'),'celldata_clean','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellmaskLC_clean.mat'),'cellmaskLC_clean','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellboundLC_clean.mat'),'cellboundLC_clean','-v7.3','-nocompression');
fprintf('DONE ! \n');

exit(0)

end % funciton
