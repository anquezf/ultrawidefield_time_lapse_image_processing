function [Ncorr,Ncolli,Nrscd]=do_collision_detection_V17(ana_path,im)



warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% **********
% *** inputs
% **********

ROdir=cat(2,ana_path,'tracking_collision_feedback/');
ROcoll_dir=cat(2,ROdir,'collision_detection/');
ROtrack_dir=cat(2,ROdir,'linkage/');
track_path=cat(2,ana_path,'tracking/');


load(cat(2,ana_path,'deepTH.mat'),'deepTH');
load(cat(2,ana_path,'deepTH_2.mat'),'deepTH_2');
load(cat(2,ana_path,'AREArelinc.mat'),'AREArelinc');

load(cat(2,ana_path,'NloopFB.mat'),'NloopFB');

load(cat(2,ana_path,'rscAREA_tol.mat'),'rscAREA_tol');
load(cat(2,ana_path,'RSCOVTH.mat'),'RSCOVTH');



% ******************
% *** analysis infos
% ******************

load(cat(2,ana_path,'XYlist.mat'),'XYlist');
load(cat(2,ana_path,'pixsize.mat'),'pixsize');
pixsize_sq=power(pixsize,2);
load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');
Lc_abs=NL/2;
Cc_abs=NC/2;

load(cat(2,ana_path,'imoffset.mat'),'imoffset');
load(cat(2,ana_path,'FF_NUC.mat'),'FF');
load(cat(2,ana_path,'FF_bkg.mat'),'FF_bkg');
load(cat(2,ana_path,'FF_foreg.mat'),'FF_foreg');
load(cat(2,ana_path,'useFFforeg.mat'),'useFFforeg');

load(cat(2,ana_path,'flipUD.mat'),'flipUD');
load(cat(2,ana_path,'flipLR.mat'),'flipLR');
load(cat(2,ana_path,'XYlist.mat'),'XYlist');


load(cat(2,ana_path,'Lmax.mat'),'Lmax');
Lmax=double(Lmax);
Lmax_sq=power(Lmax,2);
Lmax_sq_2=power(2*Lmax,2);


% ********
% *** data
% ********

save_path=cat(2,ROcoll_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
load(cat(2,save_path,'short_celldata.mat'),'short_celldata');
load(cat(2,save_path,'short_cellmaskLC.mat'),'short_cellmaskLC');
load(cat(2,save_path,'short_cellboundLC.mat'),'short_cellboundLC');

load(cat(2,save_path,'short_idxlist.mat'),'short_idxlist');

load(cat(2,save_path,'short_celldata_fp.mat'),'short_celldata_fp');
load(cat(2,save_path,'short_cellmaskLC_fp.mat'),'short_cellmaskLC_fp');
load(cat(2,save_path,'short_cellboundLC_fp.mat'),'short_cellboundLC_fp');

% ******************
% *** start analysis
% ******************

[Nscd,~]=size(short_celldata);
idxs_scd=[1:Nscd]';

is_cur_scd=(short_celldata(:,3)==im);
is_prev_scd=(short_celldata(:,3)==(im-1));


[Nfp,~]=size(short_celldata_fp);
idxs_fp=[1:Nfp]';

is_cur_fp=(short_celldata_fp(:,3)==im);
candidates_rescue_idxs=idxs_fp(is_cur_fp,:);
[Nrsc_c,~]=size(candidates_rescue_idxs);

% ******************
% *** find colliders
% ******************
colliders_idxs=[];
% search for cells (CID) found at frame im-1 (prev)
% but lost at frame im (cur)
col_candidates_idxs=idxs_scd(is_prev_scd,:);
[Ncand,~]=size(col_candidates_idxs);
% look wether candidates are lost at frame im
for cand=1:Ncand
  idx=col_candidates_idxs(cand,1);
  CID=short_celldata(idx,12);
  logiidx=(short_celldata(:,12)==CID)&is_cur_scd;
  if sum(logiidx)==0
    colliders_idxs=cat(1,colliders_idxs,idx);
  end % if
end % for cc

[Ncol,~]=size(colliders_idxs);


% ****************************
% *** find partners candidates
% ****************************
candidates_partner_idxs=[];
% search for cells found at frame im (cur)
%               and also at frame im-1 (prev)
candidates_idxs_1=idxs_scd(is_cur_scd,1);
[Ncand,~]=size(candidates_idxs_1);
% look wether candidates are there at frame im-1 (prev)
for cand=1:Ncand
  idx=candidates_idxs_1(cand,1);
  CID=short_celldata(idx,12);
  logiidx=(short_celldata(:,12)==CID)&is_prev_scd;
  if sum(logiidx)==1
    idx2=idxs_scd(logiidx,1);
    candidates_partner_idxs=cat(1,candidates_partner_idxs,[idx,idx2]);
  end % if
end % for cc

[Npart_c,~]=size(candidates_partner_idxs);


% candidates coordinates
% partner cur
XXc_p=short_celldata(candidates_partner_idxs(:,1),1);
YYc_p=short_celldata(candidates_partner_idxs(:,1),2);
% partner prev
XXp_p=short_celldata(candidates_partner_idxs(:,2),1);
YYp_p=short_celldata(candidates_partner_idxs(:,2),2);


% partner prev
XXc_fp=short_celldata_fp(candidates_rescue_idxs,1);
YYc_fp=short_celldata_fp(candidates_rescue_idxs,2);



% ***************************
% choose best partner or FP
% ***************************

% % selected_rescued= [ fp_idx_1 ; ... ; fp_idx_r ; ... ]
selected_rescued=[];

% partner_candidates{ii,kk} : ii partner index and jj param
% partner_candidates = { Ncol_found , NTH1 , NTH2 , L0 , C0 , Lc , Cc }
% partner_candidates has the same size as candidates_partner_idxs
% N1TH number of digged Boundary points that satisfy first TH (deepTH)
% N1TH number of digged Boundary points that satisfy 2nd TH (deepTH_2)
% start with empty... compute Ncol, NTH1, NTH2, ... when needed
partner_candidates=cell(Npart_c,5);

for col=1:Ncol

  % col info
  col_idx=colliders_idxs(col,1);
  scd=short_celldata(col_idx,:);
  Xcol=scd(1,1); Ycol=scd(1,2);

  p_col=short_celldata(col_idx,10);
  Xrefcol=XYlist(p_col+1,1);
  Yrefcol=XYlist(p_col+1,2);
  colMLC=short_cellmaskLC{col_idx,1};
  [colAREA,~]=size(colMLC);

  colBLC=short_cellboundLC{col_idx,1};

  Xcol=short_celldata(col_idx,1);
  Ycol=short_celldata(col_idx,2);

  % ***
  % search for best partner
  
  dsq=power(Xcol-XXc_p,2)+power(Ycol-YYc_p,2);
  [dsq_bpa,ii]=min(dsq); ii=ii(1,1);
  bpa_idx=candidates_partner_idxs(ii,1);


  if ~(isempty(bpa_idx))

    % collect best part info
    p_bpa=short_celldata(bpa_idx,10);
    Xrefbpa=XYlist(p_bpa+1,1);
    Yrefbpa=XYlist(p_bpa+1,2);
    bpaMLC=short_cellmaskLC{bpa_idx,1};
    [bpaAREA,~]=size(bpaMLC);
    bpaBLC=short_cellboundLC{bpa_idx,1};
    Lbpa=short_celldata(bpa_idx,6);
    Cbpa=short_celldata(bpa_idx,7);
    Xbpa=short_celldata(bpa_idx,1);
    Ybpa=short_celldata(bpa_idx,2);

    % get overlap
    sharedAREA=measure_cells_overlap_V3(colBLC,colMLC,Xrefcol,Yrefcol,bpaMLC,Xrefbpa,Yrefbpa,Lc_abs,Cc_abs,pixsize);
    OVBPA=sharedAREA/colAREA;

    % get deepness of best CVX boundary points
    Ncol_found=partner_candidates{ii,1};
    if isempty(Ncol_found)
      Ncol_found=0;
      % calculate params
      if ~isempty(bpaBLC)
        [dBxB_list,dBxC_list,~,L0bpa_list,C0bpa_list,~,~,Lcbpa,Ccbpa,~,~]=measure_boundary_deepness_V3(bpaBLC);
      else
        dBxB_list=[];
        dBxC_list=[];
        L0bpa_list=[];
        C0bpa_list=[];
        Lcbpa=[];
        Ccbpa=[];
      end % if ~isempty(bpaBLC)
      deepBPA_list=-1;
      if ~(isempty(dBxB_list))
        deepBPA_list=dBxB_list./dBxC_list;
      end % if
      ll=deepBPA_list>deepTH;
      N1TH=sum(ll);
      ll=deepBPA_list>deepTH_2;
      N2TH=sum(ll);
      % sort them
      [Nhu,~]=size(dBxB_list);
      if Nhu>0
        [~,idxorder]=max(deepBPA_list);
        L0bpa=L0bpa_list(idxorder,1);
        C0bpa=C0bpa_list(idxorder,1);
      else
        L0bpa=0;
        C0bpa=0;
      end
      % intialize infos for this partner candidate
      partner_candidates{ii,1}=Ncol_found;
      partner_candidates{ii,2}=N1TH;
      partner_candidates{ii,3}=N2TH;
      partner_candidates{ii,4}=L0bpa;
      partner_candidates{ii,5}=C0bpa;
      partner_candidates{ii,6}=Lcbpa;
      partner_candidates{ii,7}=Ccbpa;
    else
      Ncol_found=partner_candidates{ii,1};
      N1TH=partner_candidates{ii,2};
      N2TH=partner_candidates{ii,3};
    end % if

  else
    N1TH=0;
    N2TH=0;
    OVBPA=0;
    dsq_bpa=inf;
    bpaAREA=0;
    Ncol_found=inf;
  end % if % if ~(isempty(bpa_idx))
  
  AREAmul=1+Ncol*AREArelinc;
  % ***
  % catch it ??? !!!
  is_associated=0;

  if (OVBPA>RSCOVTH)&&(bpaAREA>AREAmul*colAREA)
    if N1TH>(Ncol_found+2)
    %if N1TH>2
      % catch
      Ncol_found=Ncol_found+1;
      partner_candidates{ii,1}=Ncol_found;
      is_associated=1;
    end % if

  elseif (OVBPA>RSCOVTH)
    if (N1TH>(Ncol_found+2))&&(N2TH>1)
    %if (N1TH>2)&&(N2TH>1)
      % catch
      Ncol_found=Ncol_found+1;
      partner_candidates{ii,1}=Ncol_found;
      is_associated=1;
    end % if

  else %elseif OVBPA is not >0
       % then use highly constrain criteria
    if (dsq_bpa<Lmax_sq)&&(N1TH>(Ncol_found+2))&&(N2TH>1)&&(bpaAREA>AREAmul*colAREA)
    %if (dsq_bpa<Lmax_sq)&&(N1TH>2)&&(N2TH>1)&&(bpaAREA>AREAmul*colAREA)
      % catch
      Ncol_found=Ncol_found+1;
      partner_candidates{ii,1}=Ncol_found;
      is_associated=1;
    end % ifr (dsq_bpa<Lmax_sq_2)&&(deepBPA>deepTH)
  end % if (OVBPA>0)


  % *** try false positive rescue
  if is_associated==0
    % get best FP infos
    dsq_fp=power(Xcol-XXc_fp,2)+power(Ycol-YYc_fp,2);
    [dsq_bfp,jj]=min(dsq_fp); jj=jj(1,1);
    bfp_idx=candidates_rescue_idxs(jj,1);

    % collect best FP info
    p_bfp=short_celldata_fp(bfp_idx,10);
    Xrefbfp=XYlist(p_bfp+1,1);
    Yrefbfp=XYlist(p_bfp+1,2);
    bfpMLC=short_cellmaskLC_fp{bfp_idx,1};
    [bfpAREA,~]=size(bfpMLC);

    bfpBLC=short_cellboundLC_fp{bfp_idx,1};

    if ~(isempty(bfp_idx))
      if (dsq_bfp<Lmax_sq)
        sharedAREA_fp=measure_cells_overlap_V3(colBLC,colMLC,Xrefcol,Yrefcol,bfpMLC,Xrefbfp,Yrefbfp,Lc_abs,Cc_abs,pixsize);
        OVBFP=sharedAREA_fp/colAREA;
        if (OVBFP>RSCOVTH)&&(bfpAREA>((1-rscAREA_tol)*colAREA))&&(bfpAREA<((1+rscAREA_tol)*colAREA))
          selected_rescued=cat(1,selected_rescued,bfp_idx);
        end
      end % if (dsq_fp<Lmax_sq)
    end % if (~(isempty(bfp_idx)))

  end % if is_associated==0

end % for col



mask_cell=zeros(NL,NC,'uint16');
mask=zeros(NL,NC,'uint16');
bkg_mask=zeros(NL,NC,'logical');

% ****************************************
% *** update colliders and corrected cells
% ****************************************

corrected_celldata=[];
corrected_cellmaskLC={};
corrected_cellboundLC={};

corrected_idx=[];

collider_celldata=[];
collider_cellmaskLC={};
collider_cellboundLC={};

Ncorr=0;
Ncolli=0;


% test duplicate
short_celldata_testdup=short_celldata(is_cur_scd,:);
llX=zeros(Nscd,1,'logical');
llY=zeros(Nscd,1,'logical');
DDX=zeros(Nscd,1);
DDY=zeros(Nscd,1);


% partner_candidates{ii,kk} : ii partner index and jj param
% partner_candidates = { Ncol_found , NTH1 , NTH2 , L0_list , C0_list }
if Npart_c>0

for part=1:Npart_c

  % get number of colliders found
  num_col=partner_candidates{part,1};
  if isempty(num_col)
    num_col=0;
  end % isempty

  if num_col>0

    part_idx=candidates_partner_idxs(part,1);

    L0bpa=partner_candidates{part,4};
    C0bpa=partner_candidates{part,5};
    Lcbpa=partner_candidates{part,6};
    Ccbpa=partner_candidates{part,7};

    Nreg=num_col+1;

    % split partner
    BLCbpa=double(short_cellboundLC{part_idx,1});
    MLCbpa=double(short_cellmaskLC{part_idx,1});
    %[mask,Nsp]=split_collider(Nreg,MLCbpa,BLCbpa,L0bpa,C0bpa,Lcbpa,Ccbpa,NL,NC,1);
    %[mask,Nsp]=split_collider_V3(Nreg,MLCbpa,NL,NC);
    [isin,ison]=inpolygon(Lcbpa,Ccbpa,BLCbpa(:,1),BLCbpa(:,2));
    if (isin)&&(~ison)
      [mask_cell,Nsp]=split_collider(Nreg,MLCbpa,BLCbpa,L0bpa,C0bpa,Lcbpa,Ccbpa,NL,NC,1);
    else
      [mask_cell,Nsp]=cut_collider_V2(Nreg,MLCbpa,NL,NC);
    end % if

    if Nsp>1

      % *** partner pos
      p=short_celldata(part_idx,10);
      pos_ana_dir=cat(2,ana_path,'DATA/',num2str(p,'%0.5d'),'/');
      % *** find FOV center
      Xc=XYlist(p+1,1);
      Yc=XYlist(p+1,2);
      % *** data infos
      load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');
      load(cat(2,pos_ana_dir,'fileListN.mat'),'fileListN');

      % load bkg pdf
      load(cat(2,ana_path,'mu_cor_all.mat'),'mu_cor_all');
      load(cat(2,ana_path,'sig_cor_all.mat'),'sig_cor_all');
      load(cat(2,ana_path,'b0.mat'),'b0');
      load(cat(2,ana_path,'delta_b_vsim.mat'),'delta_b_vsim');

      % *** find idx
      idx=imidx_2_lidx(im,1);
      % *** load raw data
      theimage=double(imread(fileListN{idx,1}));
      theimage=(theimage-imoffset);

      % *** image restoration
      theimage=theimage-(b0+delta_b_vsim(1,im))*FF_bkg;

      if useFFforeg==1
        theimage=theimage./FF_foreg;
      end % if

      theimage=theimage-mu_cor_all(1,im);

      % flip ?
      if flipUD>0 theimage=flipud(theimage); end % if
      % flip ?
      if flipLR>0 theimage=fliplr(theimage); end % if

      [cells,LClist,BOUNDlist]=get_cellFEAT_V8(Nsp,mask_cell,theimage,NL,NC,Xc,Yc,im,Lc_abs,Cc_abs,pixsize,p);
      [Ncell,~]=size(cells);
      Alist=zeros(Ncell,1);
      for ce=1:Ncell
        MLC=LClist{ce,1};
        [A,~]=size(MLC);
      end % for ce
      [~,idxlist]=sort(Alist);
      cells=cells(idxlist,:);
      LClist=LClist(idxlist,1);
      BOUNDlist=BOUNDlist(idxlist,1);

      p2=short_celldata(part_idx,11);
      cells=cat(2,cells,p2*ones(Nsp,1));


      [NMaskcor,~]=size(LClist{1,1});
      [NBoundcor,~]=size(BOUNDlist{1,1});
      if (NMaskcor>2)&&(NBoundcor>2)

        % test duplicate
        DDX=abs(short_celldata_testdup(:,1)-cells(1,1)); llX=DDX<pixsize;
        DDY=abs(short_celldata_testdup(:,2)-cells(1,2)); llY=DDY<pixsize;

        if (sum(llX&llY)==0)

          % store corrected cell
          Ncorr=Ncorr+1;
          corrected_celldata=cat(1,corrected_celldata,cells(1,:));
          corrected_cellmaskLC=cat(1,corrected_cellmaskLC,LClist{1,1});
          corrected_cellboundLC=cat(1,corrected_cellboundLC,BOUNDlist{1,1});
          % this index correspond to sorted_celldata.mat !!!! ready to use !
          corrected_idx=cat(1,corrected_idx,short_idxlist(part_idx,1));

          % store colliders
          for cc=2:Nsp
            [NMaskcol,~]=size(LClist{cc,1});
            [NBoundcol,~]=size(BOUNDlist{cc,1});

            if (NMaskcol>2)&&(NBoundcol>2)
              % test duplicate
              DDX=abs(short_celldata_testdup(:,1)-cells(cc,1)); llX=DDX<pixsize;
              DDY=abs(short_celldata_testdup(:,2)-cells(cc,2)); llY=DDY<pixsize;
              if (sum(llX&llY)==0)
                Ncolli=Ncolli+1;
                collider_celldata=cat(1,collider_celldata,cells(cc,:));
                collider_cellmaskLC=cat(1,collider_cellmaskLC,LClist{cc,1});
                collider_cellboundLC=cat(1,collider_cellboundLC,BOUNDlist{cc,1});
              end % if (sum(llX&llY)==0)
            end % if (NMaskcol>2)&&(NBoundcol>2)
          end % for cc

       end % if  (sum(llX&llY)==0)

      end % if (NMaskcor>2)&&(NBoundcor>2)

    end % if Nsp>1

  end % for num_col

end % for Npart_c

end % if Npart_c>0


save_path=cat(2,ROcoll_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');

save(cat(2,save_path,'Ncorr.mat'),'Ncorr','-v7.3','-nocompression');
save(cat(2,save_path,'corrected_celldata.mat'),'corrected_celldata','-v7.3','-nocompression');
save(cat(2,save_path,'corrected_cellboundLC.mat'),'corrected_cellboundLC','-v7.3','-nocompression');
save(cat(2,save_path,'corrected_cellmaskLC.mat'),'corrected_cellmaskLC','-v7.3','-nocompression');
save(cat(2,save_path,'corrected_idx.mat'),'corrected_idx','-v7.3','-nocompression');

save(cat(2,save_path,'Ncolli.mat'),'Ncolli','-v7.3','-nocompression');
save(cat(2,save_path,'collider_celldata.mat'),'collider_celldata','-v7.3','-nocompression');
save(cat(2,save_path,'collider_cellboundLC.mat'),'collider_cellboundLC','-v7.3','-nocompression');
save(cat(2,save_path,'collider_cellmaskLC.mat'),'collider_cellmaskLC','-v7.3','-nocompression');




% *******************
% *** select rescued
% *******************

% selected_rescued= [ fp_idx_1 ; ... ; fp_idx_r ; ... ]
selected_rescued=unique(selected_rescued);
[Nrscd,~]=size(selected_rescued);

rescued_celldata=[];
rescued_cellmaskLC={};
rescued_cellboundLC={};

Nrscd2=0;
if Nrscd>0

  for rs=1:Nrscd

    rscd_idx=selected_rescued(rs,1);

    DDX=abs(short_celldata_testdup(:,1)-short_celldata_fp(rscd_idx,1)); llX=DDX<pixsize;
    DDY=abs(short_celldata_testdup(:,2)-short_celldata_fp(rscd_idx,2)); llY=DDY<pixsize;
    if (sum(llX&llY)==0)
      Nrscd2=Nrscd2+1;
      rescued_celldata=cat(1,rescued_celldata,short_celldata_fp(rscd_idx,:));
      rescued_cellmaskLC=cat(1,rescued_cellmaskLC,short_cellmaskLC_fp{rscd_idx,1});
      rescued_cellboundLC=cat(1,rescued_cellboundLC,short_cellboundLC_fp{rscd_idx,1});
    end % if (sum(llX&llY)==0)

  end % for rs

end % if Nrscd>0
Nrscd=Nrscd2;


save(cat(2,save_path,'Nrscd.mat'),'Nrscd','-v7.3','-nocompression');
save(cat(2,save_path,'rescued_celldata.mat'),'rescued_celldata','-v7.3','-nocompression');
save(cat(2,save_path,'rescued_cellboundLC.mat'),'rescued_cellboundLC','-v7.3','-nocompression');
save(cat(2,save_path,'rescued_cellmaskLC.mat'),'rescued_cellmaskLC','-v7.3','-nocompression');


end % function
