function [Lw,Cw]=walk_toward_boundary_V2(Li,Ci,Lt,Ct,BLC)

% Li and Ci are Line# and col# for inside point
% Lt and Ct are Line# and col# for target point on boundary (BLC)

Lt=round(Lt);
Ct=round(Ct);

Lw=round(Li);
Cw=round(Ci);


Lcur=round(Li);
Ccur=round(Ci);
Lprev=Lcur;
Cprev=Ccur;
Ltest=zeros(4,1);
Ctest=zeros(4,1);

keepgoing=1;
while(keepgoing>0)

  if ~((Lcur+1==Lprev)&(Ccur==Cprev))
  Ltest(1,1)=Lcur+1;
  Ctest(1,1)=Ccur;
  else
  Ltest(1,1)=inf;
  Ctest(1,1)=inf;
  end % if

  if ~((Lcur-1==Lprev)&(Ccur==Cprev))
  Ltest(2,1)=Lcur-1;
  Ctest(2,1)=Ccur;
  else
  Ltest(2,1)=inf;
  Ctest(2,1)=inf;
  end % if

  if ~((Lcur==Lprev)&(Ccur+1==Cprev))
  Ltest(3,1)=Lcur;
  Ctest(3,1)=Ccur+1;
  else
  Ltest(3,1)=inf;
  Ctest(3,1)=inf;
  end % if

  if ~((Lcur==Lprev)&(Ccur-1==Cprev))
  Ltest(4,1)=Lcur;
  Ctest(4,1)=Ccur-1;
  else
  Ltest(4,1)=inf;
  Ctest(4,1)=inf;
  end % if

  d_sq=power(Lt-Ltest,2)+power(Ct-Ctest,2);
  [mini,idx]=min(d_sq);
  idx=idx(1,1);
  Lcur=Ltest(idx,1);
  Ccur=Ctest(idx,1);

  [isin,ison]=inpolygon(Lcur,Ccur,BLC(:,1),BLC(:,2));
  if (isin)&&(~ison)
    Lw=cat(1,Lw,Lcur);
    Cw=cat(1,Cw,Ccur);
  else
    keepgoing=0;
  end % if

  if ison
    Lw=cat(1,Lw,Lcur);
    Cw=cat(1,Cw,Ccur);
  else

  Lprev=Lcur;
  Cprev=Ccur;

end % while

end % funciton
