function run_init_multiple_FLUO_V3(save_dir,chanFluo,quantileFF_low_str,quantileFF_high_str,NBMAX_str)

warning off


fprintf('*** Please select A BUNCH of EXISTING experiments\n')
ana_path_list=uipickfiles('FilterSpec',save_dir)';

[Nexpe,~]=size(ana_path_list);
for expe=1:Nexpe
  ana_path=ana_path_list{expe,1};
  [~,Nchar]=size(ana_path);
  if ~(strcmp(ana_path(1,Nchar),'/'))
    ana_path=cat(2,ana_path,'/');
  end % if
  ana_path_list{expe,1}=ana_path;
  fprintf(cat(2,ana_path,'\n'));
end % for exp

% ********************************************
% *** save current ana_path_list and NBmax ***
% ********************************************

run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if

save(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe','-v7.3','-nocompression');

NBMAX=str2double(NBMAX_str);
save(cat(2,run_path,'run_vars/cur_NBMAX.mat'),'NBMAX','-v7.3','-nocompression');
save(cat(2,run_path,'run_vars/cur_chanFluo.mat'),'chanFluo','-v7.3','-nocompression');


% ********************************************
% *** save current ana_path_list and NBmax ***
% ********************************************

quantileFF_low=str2double(quantileFF_low_str);
quantileFF_high=str2double(quantileFF_high_str);

fprintf('\n\n')
POOLOBJ=parpool('local',NBMAX,'IdleTimeout',560);
fprintf('\n\n')


fprintf('\n\n')
fprintf('*** INTIALIZE FlatField Processing ...\n');

for expe=1:Nexpe

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'* intialize FlatField Processing - ',chanFluo,' - experiment %d : ',ana_path,'\n'),expe);

  % ******************
  % *** write log file
  % ******************

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- Fluo Analysis ');
  fprintf(fid,chanFluo);
  fprintf(fid,' - INIT : ');
  tstart=now;
  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fclose(fid);


  % ******************
  % *** load infos
  % ******************

  Npos=0; Nim=0; im_start=0; im_stop=0;
  load(cat(2,ana_path,'Npos.mat'));
  load(cat(2,ana_path,'Nim.mat'));
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');


  fluo_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/');
  mkdir(fluo_ana_dir);

  save(cat(2,fluo_ana_dir,'quantileFF_low.mat'),'quantileFF_low','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'quantileFF_high.mat'),'quantileFF_high','-v7.3','-nocompression');

  % *********************************************
  % *** prepare data for each position
  % *********************************************

  mkdir(cat(2,fluo_ana_dir,'positions_infos/'));

  fprintf('prepare positions ...')
  parfor pos=1:Npos
    prepare_Fluo_positions(ana_path,chanFluo,pos);
  end % for p
  fprintf(' DONE ! \n')


  % *********************************************
  % *** prepare data for each images
  % *********************************************


  mkdir(cat(2,fluo_ana_dir,'images_infos/'))

  fprintf('prepare images ..')
  parfor im=im_start:im_stop
    prepare_Fluo_images(ana_path,chanFluo,im)
  end % for im
  fprintf(' DONE ! \n')

  % ******************
  % *** write log file
  % ******************

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- Fluo Analysis ');
  fprintf(fid,chanFluo);
  fprintf(fid,' - INIT : ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);


end % for expe


fprintf('\n\n We have pre-processed %5d experiments... GOODLUCK !\n',Nexpe);
delete(POOLOBJ);
fprintf('\n\n');

end % function
