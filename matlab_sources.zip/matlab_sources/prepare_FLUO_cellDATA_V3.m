function prepare_FLUO_cellDATA_V3(ana_path,Lmesh,Cmesh,NL,NC,im,Npos,pixsize,Radpix_sq)

warning off

load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/','short_celldata.mat'),'short_celldata');
load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/','short_cellmaskLC.mat'),'short_cellmaskLC');

% ***
% the three masks for FF bkg/foreg exctraction and fnuc fluo exctraction
bkg_mask=zeros(NL,NC,'logical');
foreg_mask=zeros(NL,NC,'logical');
cell_mask=zeros(NL,NC);
mask_temp=zeros(NL,NC,'logical');

% ***
% the Nforeg/Nbkg images for FF bkg/foreg exctraction
Nfound_FOREG=zeros(NL,NC);
Nfound_BKG=zeros(NL,NC);

% ***
% some other variables
[Ncelltot,~]=size(short_celldata);
logiidx=zeros(Ncelltot,1);

for pos=1:Npos

  fluo_ana_dir=cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/',num2str(pos-1,'%0.5d'),'/');
  mkdir(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/',num2str(pos-1,'%0.5d')),'/');

  logiidx=(short_celldata(:,10)==(pos-1));
  scd=short_celldata(logiidx,:);
  smlc=short_cellmaskLC(logiidx,1);

  bkg_mask=zeros(NL,NC,'logical');
  foreg_mask=zeros(NL,NC,'logical');
  cell_mask=zeros(NL,NC);
  mask_temp=zeros(NL,NC,'logical');

  Ncell=sum(logiidx);

  for ce=1:Ncell

    % foreground mask
    % cellmask
    MLC=smlc{ce,1};
    [Npix,~]=size(MLC);
    cid=scd(ce,12);
    for pix=1:Npix
      foreg_mask(MLC(pix,1),MLC(pix,2))=true;
      cell_mask(MLC(pix,1),MLC(pix,2))=cid;
    end % for
 
    % background mask
    L0=scd(ce,6);
    C0=scd(ce,7);
    mask_temp=(power(Lmesh-L0,2)+power(Cmesh-C0,2))<Radpix_sq;
    bkg_mask=bkg_mask+mask_temp;

  end % for ce
  bkg_mask=~(bkg_mask);
  cell_mask=sparse(cell_mask);

  save(cat(2,fluo_ana_dir,'bkg_mask.mat'),'bkg_mask','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'foreg_mask.mat'),'foreg_mask','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'cell_mask.mat'),'cell_mask','-v7.3','-nocompression');

  Nfound_FOREG(foreg_mask)=Nfound_FOREG(foreg_mask)+1;
  Nfound_BKG(bkg_mask)=Nfound_BKG(bkg_mask)+1;

end % for pos

fluo_ana_dir=cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/');
save(cat(2,fluo_ana_dir,'Nfound_BKG.mat'),'Nfound_BKG','-v7.3','-nocompression');
save(cat(2,fluo_ana_dir,'Nfound_FOREG.mat'),'Nfound_FOREG','-v7.3','-nocompression');


end % function
  
