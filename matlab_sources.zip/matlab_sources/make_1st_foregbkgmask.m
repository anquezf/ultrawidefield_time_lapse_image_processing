function [bkg_mask,foreg_mask]=make_1st_foregbkgmask_init_V8(theimage_f,theimage,NL,NC,Lmesh,Cmesh,ITH,delta_pix,radius);

FACTOR=1/50;

foreg_mask=zeros(NL,NC,'logical');
bkg_mask=zeros(NL,NC,'logical');
Lmask=zeros(NL,NC);

mm=zeros(NL,NC,'logical');
mm2=zeros(NL,NC,'logical');
mm3=zeros(NL,NC,'logical');

radius_sq=radius*radius;

% get regional max
mm=imregionalmax(theimage_f);
[Lmask,Ng]=bwlabel(mm);

for c=1:Ng

  % get locl infos
  mm=(Lmask==c);
  [Lc,Cc]=find(mm); Lc=mean(Lc); Cc=mean(Cc);
  lmin=max([(Lc-delta_pix),1]);
  lmax=min([(Lc+delta_pix),NL]);
  cmin=max([(Cc-delta_pix),1]);
  cmax=min([(Cc+delta_pix),NC]);
  data=theimage(lmin:lmax,cmin:cmax);

  Ifmax=theimage_f(Lc,Cc);

  if mean(data(:))>=ITH
    % large mask around local max
    mm2=(power(Lmesh-Lc,2)+power(Cmesh-Cc,2))<radius_sq;
    % smaller mask around
    mm3=theimage_f>(Ifmax*FACTOR);
    % update foreg/bkg
    % fill ~bkg
    bkg_mask(mm2)=true;
    % fill foreg
    foreg_mask(mm2&mm3)=true;
  end % if

end % for c

bkg_mask=~bkg_mask;

end % function
