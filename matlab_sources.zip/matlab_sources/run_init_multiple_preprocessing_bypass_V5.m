function run_init_multiple_preprocessing_V5(save_dir,pad_dpix_str,fWFF_str,FFmini_str,deltai_str,imini_str,imaxi_str,fW1_str,fW2_str,Nsig_str,NBMAX_str)

warning off


fprintf('\n*** Please select A BUNCH of EXISTING experiments\n')
ana_path_list=uipickfiles('FilterSpec',save_dir)';
fprintf('\n');

[Nexpe,~]=size(ana_path_list);
for expe=1:Nexpe
  ana_path=ana_path_list{expe,1};
  [~,Nchar]=size(ana_path);
  if ~(strcmp(ana_path(1,Nchar),'/'))
    ana_path=cat(2,ana_path,'/');
  end % if
  ana_path_list{expe,1}=ana_path;
  fprintf(cat(2,ana_path,'\n'));
end % for exp

fprintf('\n');

fprintf('*** Please select A FILE for 1st FlatField correction (FF_NUC)\n')
FF_1st_file=uipickfiles('FilterSpec',save_dir)';
fprintf(cat(2,FF_1st_file{1,1},'\n'));
load(FF_1st_file{1,1});

fprintf('\n')

fprintf('*** Please select A FILE for BACKGROUND FlatField correction\n')
FF_bkg_file=uipickfiles('FilterSpec',save_dir)';
fprintf(cat(2,FF_bkg_file{1,1},'\n'));
load(FF_bkg_file{1,1});

fprintf('\n')

fprintf('*** Please select A FILE for FOREGROUND FlatField correction\n')
FF_foreg_file=uipickfiles('FilterSpec',save_dir)';
fprintf(cat(2,FF_foreg_file{1,1},'\n'));
load(FF_foreg_file{1,1});

fprintf('\n')


% ********************************************
% *** save current ana_path_list and NBmax ***
% ********************************************

run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if

save(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe','-v7.3','-nocompression');

NBMAX=str2double(NBMAX_str);
save(cat(2,run_path,'run_vars/cur_NBMAX.mat'),'NBMAX','-v7.3','-nocompression');



fprintf('\n\n')
fprintf('*** INTIALIZE bypass FlatField Processing ...\n');


% **********************
% *** preproc params ***
% **********************

deltai=str2double(deltai_str);
imaxi=str2double(imaxi_str);
imini=str2double(imini_str);
iedges=(imini:deltai:imaxi)';

Nsig=str2double(Nsig_str);

fW1=str2double(fW1_str);
fW2=str2double(fW2_str);

pad_dpix=str2double(pad_dpix_str);
fWFF=str2double(fWFF_str);
FFmini=str2double(FFmini_str);

for expe=1:Nexpe

  ana_path=ana_path_list{expe,1};


  % ******************
  % *** write log file
  % ******************

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- init multiple BYPASS preprocessing V5 ');
  tstart=now;
  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fclose(fid);


  % **********************
  % *** save params and FF
  % **********************

  % *** FFs

  save(cat(2,ana_path,'ori_FF_1st_file.mat'),'FF_1st_file','-v7.3','-nocompression');
  save(cat(2,ana_path,'ori_FF_foreg_file.mat'),'FF_foreg_file','-v7.3','-nocompression');
  save(cat(2,ana_path,'ori_FF_bkg_file.mat'),'FF_bkg_file','-v7.3','-nocompression');

  save(cat(2,ana_path,'FF_NUC.mat'),'FF','-v7.3','-nocompression');
  save(cat(2,ana_path,'FF_bkg.mat'),'FF_bkg','-v7.3','-nocompression');
  save(cat(2,ana_path,'FF_foreg.mat'),'FF_foreg','-v7.3','-nocompression');

  % *** params

  save(cat(2,ana_path,'deltai.mat'),'deltai','-v7.3','-nocompression');
  save(cat(2,ana_path,'imaxi.mat'),'imaxi','-v7.3','-nocompression');
  save(cat(2,ana_path,'imini.mat'),'imini','-v7.3','-nocompression');
  save(cat(2,ana_path,'iedges.mat'),'iedges','-v7.3','-nocompression');

  save(cat(2,ana_path,'Nsig.mat'),'Nsig','-v7.3','-nocompression');

  save(cat(2,ana_path,'fW1.mat'),'fW1','-v7.3','-nocompression');
  save(cat(2,ana_path,'fW2.mat'),'fW2','-v7.3','-nocompression');

  save(cat(2,ana_path,'pad_dpix.mat'),'pad_dpix','-v7.3','-nocompression');
  save(cat(2,ana_path,'fWFF.mat'),'fWFF','-v7.3','-nocompression');
  save(cat(2,ana_path,'FFmini.mat'),'FFmini','-v7.3','-nocompression');




  % ******************
  % *** write log file
  % ******************

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- init multiple BYPASS preprocessing V5 ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);



end %for expe


end % function

