function export_cellSEG(ana_path,pos,scale,nbit)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'FF_NUC.mat'));
load(cat(2,ana_path,'imoffset.mat'));
load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'pixsize.mat'),'pixsize');
load(cat(2,ana_path,'flipUD.mat'),'flipUD');
load(cat(2,ana_path,'flipLR.mat'),'flipLR');
load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');
rszNL=NL*scale;
rszNC=NC*scale;
[rszCmesh,rszLmesh]=meshgrid([1:rszNC],[1:rszNL]);

pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'));
load(cat(2,pos_ana_dir,'fileListN.mat'));

pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/cell_data/');
load(cat(2,pos_ana_dir,'boundLC_List.mat'),'boundLC_List');
load(cat(2,pos_ana_dir,'Nreg_List.mat'),'Nreg_List');
load(cat(2,pos_ana_dir,'cell_List.mat'),'cell_List');


RO_ana_dir=cat(2,ana_path,'vizu_cell_segmentation/',num2str(pos-1,'%0.5d'),'/');

if nbit==16
  n_max=65536;
  cmap=int8(randi(n_max,1000,3)-1);
else
  n_max=256;
  cmap=int16(randi(n_max,1000,3)-1);
end % if



if nbit==8
  image_cur=uint8(zeros(rszNL,rszNC,3));
elseif nbit==16
  image_cur=uint16(zeros(rszNL,rszNC,3));
else
  image_cur=uint8(zeros(rszNL,rszNC,3));
end % if

mask=logical(zeros(rszNL,rszNC));

for im=1:Nim

  idx=imidx_2_lidx(im,1);

  theimage=double(imread(fileListN{idx,1}));
  theimage=(theimage-imoffset)./FF;

  % flip ?
  if flipUD>0
    theimage=flipud(theimage);
  end % if
  % flip ?
  if flipLR>0
    theimage=fliplr(theimage);
  end % if
  theimage_rsz=imresize(theimage,scale);
  Imaxi=quantile(theimage_rsz(:),0.99);

  logiidx=(cell_List(:,3)==im);
  scdata=cell_List(logiidx,:);
  bLCl=boundLC_List(logiidx,1);
    %            1  2   3      4     5          6   7   8   9   10 
    %cell_List=[ X ,Y , imidx, Area, Intensity, L,  C,  wB, wS, p  ]
    %            um um  idx    Npix  a.u.       pix pix um  um  idx

  if nbit==8
    for cc=1:3 image_cur(:,:,cc)=uint8((255/Imaxi)*theimage_rsz); end % for cc
  elseif nbit==16
    for cc=1:3 image_cur(:,:,cc)=uint16((65535/Imaxi)*theimage_rsz); end % for cc
  else
    for cc=1:3 image_cur(:,:,cc)=uint8((255/Imaxi)*theimage_rsz); end % for cc
  end % if

  mask=logical(zeros(rszNL,rszNC));

  Ncell=Nreg_List(im,1);
  for c=1:Ncell
    rszL=scdata(c,6)*scale;
    rszC=scdata(c,7)*scale;
    rszBL=bLCl{c,1}*scale;
    [Npix,~]=size(rszBL);
    for pp=1:Npix

      % mark boundary pixels
      for cc=1:3 image_cur(rszBL(pp,1),rszBL(pp,2),cc)=cmap(c,cc); end % for cc

      % thicken boundary
      if (rszBL(pp,1)>rszL)&(rszBL(pp,1)<rszNL)
        for cc=1:3 image_cur(rszBL(pp,1)+1,rszBL(pp,2),cc)=cmap(c,cc); end % for cc
      elseif (rszBL(pp,1)<rszL)&(rszBL(pp,1)>1)
        for cc=1:3 image_cur(rszBL(pp,1)-1,rszBL(pp,2),cc)=cmap(c,cc); end % for cc
      end % if

      % thicken boundary
      if (rszBL(pp,2)>rszC)&(rszBL(pp,2)<rszNC)
        for cc=1:3 image_cur(rszBL(pp,1),rszBL(pp,2)+1,cc)=cmap(c,cc); end % for cc
      elseif (rszBL(pp,2)<rszC)&(rszBL(pp,2)>1)
        for cc=1:3 image_cur(rszBL(pp,1),rszBL(pp,2)-1,cc)=cmap(c,cc); end % for cc
      end % if

    end % for pp
  end % for c

  % !!!!!!!!!!!!! here flipping is different for imagej opening !!!!!!!
  % !!!!!!!!!!!!! if flupUD==0 then fliud !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  % this is because imagej (as matalab) shows lines 1 above line N>1
  % but it shows column1 on the left of column N>1 
  % if flipLR==0 then do not flip !
    % flip ?
  if flipUD==0
    theimage=flipud(theimage);
  end % if

  imwrite(image_cur,cat(2,RO_ana_dir,'image_',num2str(im,'%05d'),'.Tiff'));

end % for im

end % function
