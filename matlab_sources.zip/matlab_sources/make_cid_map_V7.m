function cid_map=make_cid_map_V7(Ll,Cl,NL,NC,Nreg,Cmesh,Lmesh)

% adapted from :
% $Created: 1.0 $ $Date: 2013/08/11 20:00$ $Author: Pangyu Teng $
% https://fr.mathworks.com/matlabcentral/fileexchange/43032-convert-voronoi-cells-to-region-mask

cid_map=zeros(NL,NC);
col_tol=0.001;

if Nreg >3

  % test collinearity and duplicates ??
  col_score=test_collinear(Cl,Ll,Nreg);
  dup_score=test_duplicate(Cl,Ll,Nreg,1);
  if (abs(col_score)>col_tol)&(dup_score<1)


    % create voronoi diagram and get its finite vertices
    [vl, vc] = voronoi(Ll,Cl);
    [~,Npts]=size(vl);

    % create a mask to draw the vertices
    border=logical(false(NL,NC));
    cid_map=zeros(NL,NC);

    % draw vertices on mask
    for vv=1:Npts
      % create line function between 2 points
      f = makelinefun(vl(1,vv),vc(1,vv),vl(2,vv),vc(2,vv),2);
      % get distance between 2 points
      dist=round(1.5*sqrt(diff(vl(:,vv)).^2+diff(vc(:,vv)).^2));
      % create 'dist' points on the line
      [vlLine,vcLine]=f(dist);  
      % round the line
      vlLine=round(vlLine);
      vcLine=round(vcLine);
      % constrain line to be within the image
      validInd=(vlLine>=1)&(vlLine<=NL)&(vcLine>=1)&(vcLine<=NC);
      vlLine=vlLine(validInd);
      vcLine=vcLine(validInd);
      %% draw the line to an image
      newInd=sub2ind([NL,NC],vlLine,vcLine);
      border(newInd)=true;

      %makesure vertices points are border
      fl1=floor(vl(1,vv));  if fl1>NL fl1=NL; end; if fl1<1 fl1=1; end;
      fc1=floor(vc(1,vv));  if fc1>NL fc1=NC; end; if fc1<1 fc1=1; end;
      cl1=ceil(vl(1,vv));  if cl1>NL cl1=NL; end; if cl1<1 cl1=1; end;
      cc1=ceil(vc(1,vv));  if cc1>NL cc1=NC; end; if cc1<1 cc1=1; end;

      border(fl1,fc1)=true;
      border(fl1,cc1)=true;
      border(cl1,fc1)=true;
      border(cl1,cc1)=true;

      fl1=floor(vl(2,vv));  if fl1>NL fl1=NL; end; if fl1<1 fl1=1; end;
      fc1=floor(vc(2,vv));  if fc1>NL fc1=NC; end; if fc1<1 fc1=1; end;
      cl1=ceil(vl(2,vv));  if cl1>NL cl1=NL; end; if cl1<1 cl1=1; end;
      cc1=ceil(vc(2,vv));  if cc1>NL cc1=NC; end; if cc1<1 cc1=1; end;

      border(fl1,fc1)=true;
      border(fl1,cc1)=true;
      border(cl1,fc1)=true;
      border(cl1,cc1)=true;
    
    end % for c

    % round xs and yx
    Ll=round(Ll);
    Cl=round(Cl);

    % number each region based on the index of the centroids
    for c=1:Nreg
      %bw=imfill(border,sub2ind([NL,NC],Ll(c,1),Cl(c,1)));
      bw=imfill(border,[Ll(c,1),Cl(c,1)]);
      cid_map(bw==1)=c;
    end

    % fill borders with cid
    [Lb,Cb]=find(border);
    [Nb,~]=size(Lb);
    DD=zeros(Nreg,2);
    for b=1:Nb
      DD=power(Ll-Lb(b,1),2)+power(Cl-Cb(b,1),2);
      [~,cidx]=min(DD);
      cid_map(Lb(b,1),Cb(b,1))=cidx(1,1);
    end % for b

  else % if (abs(col_score)>0)|(dup_core>0)

    % build brutal cid_map !
    for ll=1:NL
      for cc=1:NC
        DL=zeros(1,Nreg);
        for rr=1:Nreg
          DL(1,rr)=power(Cmesh(ll,cc)-Cl(rr,1),2)+power(Lmesh(ll,cc)-Ll(rr,1),2);
        end % for rr
        [~,idx]=min(DL); idx=idx(1,1);
        cid_map(ll,cc)=idx;
      end % for cc
    end % for ll

  end % if (abs(col_score)>0)|(dup_core>0)


elseif Nreg==3

  % build brutal cid_map !
  for ll=1:NL
    for cc=1:NC
      DL=zeros(1,3);
      for rr=1:3
        DL(1,rr)=power(Cmesh(ll,cc)-Cl(rr,1),2)+power(Lmesh(ll,cc)-Ll(rr,1),2);
      end % for rr
      [~,idx]=min(DL); idx=idx(1,1);
      cid_map(ll,cc)=idx;
    end % for cc
  end % for ll

elseif Nreg==2

  % find perpendicular bissector
  % slope of segment
  a=(Ll(2,1)-Ll(1,1))/(Cl(2,1)-Cl(1,1));
  bslope=-1/a; % opposite/of inverse slope of segment
  % mid point
  Lm=sum(Ll)/2;
  Cm=sum(Cl)/2;
  % get constant because mid point belong to bissector
  bB=Lm(1,1)-bslope*Cm(1,1);
  % find side of region #1
  isleft1=(Ll(1,1)>(bslope*Cl(1,1)+bB));
  if isleft1
    logiidx=Lmesh>(bslope*Cmesh+bB);
    cid_map(logiidx)=1;
    cid_map(~(logiidx))=2;
  else
    logiidx=Lmesh<=(bslope*Cmesh+bB);
    cid_map(logiidx)=1;
    cid_map(~(logiidx))=2;
  end % if

elseif Nreg==1
  cid_map=ones(NL,NC);
elseif Nreg==0
  cid_map=zeros(NL,NC);

end % if Nreg>2
  
 

end % funciton

function fun=makelinefun(x1,y1,x2,y2,o)
%ref http://stackoverflow.com/questions/13209373/matlab-straight-line-between-2-points-with-n-points-between
if nargin < 5
  o = 1;
end % if
if o == 2,
  fun  = @(N) deal(linspace(x1,x2,N), linspace(y1,y2,N));
else
  fun  = @(N) [linspace(x1,x2,N) ; linspace(y1,y2,N)];
end % if
end % funciton
    
%
% USAGE:
%
% f = makelinefun(0,0,6,9);
% xy = f(4)
% 
%   xy =
%       0     2     4     6
%       0     3     6     9
%       
%       f = makelinefun(0,0,6,9);
% [x,y] = f(4)
% 
%   x =
%       0     2     4     6
%   y =
%       0     3     6     9
