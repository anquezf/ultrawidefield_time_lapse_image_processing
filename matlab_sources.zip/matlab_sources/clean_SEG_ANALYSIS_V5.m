function clean_SEG_ANALYSIS_V5(ana_path)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'Nim.mat'));
load(cat(2,ana_path,'Npos.mat'));


% *** INIT

fprintf('clean DATA...')

if exist(cat(2,ana_path,'DATA/'))
  for pos=1:Npos
    if exist(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/','MASK_NUC/'))
      rmdir(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/','MASK_NUC/'), 's');
    end % if
    if exist(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/cell_data/'))
      rmdir(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/cell_data/'),'s');
    end %if
    delete(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/histo.mat'));
    delete(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/histo_cor.mat'));
    delete(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/iedges.mat'));
    delete(cat(2,ana_path,'DATA/',num2str(pos-1,'%05d'),'/Nim.mat'));
  end % for pos
end % if

fprintf(' DONE !\n')



% *** FFNUC estimate

fprintf('clean FFNUC_estimate...')

if exist(cat(2,ana_path,'estimate_1stFFNUC/'))
  for im=1:Nim
    if exist(cat(2,ana_path,'estimate_1stFFNUC/',num2str(im,'%05d'),'/'))
      rmdir(cat(2,ana_path,'estimate_1stFFNUC/',num2str(im,'%05d'),'/'), 's');
    end % if
  end % for im
  rmdir(cat(2,ana_path,'estimate_1stFFNUC/'), 's');
end % if

if exist(cat(2,ana_path,'NUC_BKG_FOREG/'))
  for im=1:Nim
    if exist(cat(2,ana_path,'NUC_BKG_FOREG/',num2str(im,'%05d'),'/'))
      rmdir(cat(2,ana_path,'NUC_BKG_FOREG/',num2str(im,'%05d'),'/'), 's');
    end % if
  end % for im
  rmdir(cat(2,ana_path,'NUC_BKG_FOREG/'), 's');
end % if

if exist(cat(2,ana_path,'first_seg/'))
  rmdir(cat(2,ana_path,'first_seg/'), 's');
end % if

fprintf(' DONE !\n')



% *** RMV DUP

fprintf('clean duplicate removal...')

if exist(cat(2,ana_path,'CLEANCELLDATA/'))
  for im=1:Nim
    if exist(cat(2,ana_path,'CLEANCELLDATA/',num2str(im,'%05d'),'/'))
      rmdir(cat(2,ana_path,'CLEANCELLDATA/',num2str(im,'%05d'),'/'), 's');
    end % if
  end % for im
  rmdir(cat(2,ana_path,'CLEANCELLDATA/'), 's');
end % if

if exist(cat(2,ana_path,'RMVDUP/'))
  for im=1:Nim
    if exist(cat(2,ana_path,'RMVDUP/',num2str(im,'%05d'),'/'))
      rmdir(cat(2,ana_path,'RMVDUP/',num2str(im,'%05d'),'/'),'s');
    end % if
  end % for im
  rmdir(cat(2,ana_path,'RMVDUP/'), 's');
end % if

fprintf(' DONE !\n')



% *** tracking

fprintf('clean tracking...')

if exist(cat(2,ana_path,'tracking/'))
  for im=2:Nim
    if exist(cat(2,ana_path,'tracking/',num2str(im,'%05d'),'_',num2str(im-1,'%05d'),'/'))
      rmdir(cat(2,ana_path,'tracking/',num2str(im,'%05d'),'_',num2str(im-1,'%05d'),'/'), 's');
    end % if
  end % for im
  rmdir(cat(2,ana_path,'tracking/'), 's');
end % if

fprintf(' DONE !\n')



% *** BF

fprintf('clean BF...')

if exist(cat(2,ana_path,'BFproc/'))
  rmdir(cat(2,ana_path,'BFproc/'),'s');
end % if

fprintf(' DONE !\n')




% *** tracking coll

fprintf('clean tracking_collision_feedback...')

if exist(cat(2,ana_path,'tracking_collision_feedback/'))
  if exist(cat(2,ana_path,'tracking_collision_feedback/collision_detection/'))
    rmdir(cat(2,ana_path,'tracking_collision_feedback/collision_detection/'),'s');
  end % if
  if exist(cat(2,ana_path,'tracking_collision_feedback/linkage/'))
    rmdir(cat(2,ana_path,'tracking_collision_feedback/linkage/'),'s');
  end % if
  rmdir(cat(2,ana_path,'tracking_collision_feedback/'),'s');
end % if

fprintf(' DONE !\n')




fprintf('clean combined_data...')

delete(cat(2,ana_path,'combined_data/cellboundLC_clean.mat'))
delete(cat(2,ana_path,'combined_data/cellboundLC_fp.mat'))
delete(cat(2,ana_path,'combined_data/cellboundLC.mat'))

delete(cat(2,ana_path,'combined_data/celldata_clean.mat'))
delete(cat(2,ana_path,'combined_data/celldata_fp.mat'))
delete(cat(2,ana_path,'combined_data/celldata.mat'))

delete(cat(2,ana_path,'combined_data/cellmaskLC_clean.mat'))
delete(cat(2,ana_path,'combined_data/cellmaskLC_fp.mat'))
delete(cat(2,ana_path,'combined_data/cellmaskLC.mat'))

delete(cat(2,ana_path,'combined_data/rawcellboundLC.mat'))
delete(cat(2,ana_path,'combined_data/rawcelldata.mat'))
delete(cat(2,ana_path,'combined_data/rawcellmaskLC.mat'))

fprintf(' DONE !\n')



end % funciton


