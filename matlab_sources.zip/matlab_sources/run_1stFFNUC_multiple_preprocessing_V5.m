function run_1stFFNUC_multiple_preprocessing_V5(NBMAX_str)

warning off
FS=12;

% ********************************************
% *** get  current ana_path_list and NBmax ***
% ********************************************

run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if
load(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe');




% ******************************
% *** some usefull variables ***
% ******************************
NBMAX=str2double(NBMAX_str);
POOLOBJ=parpool('local',NBMAX,'IdleTimeout',360);

% 1st FF smoothing : NL,NC
ana_path=ana_path_list{1,1};

load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

% mesh grid
[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);
padded_image=zeros(3*NL,3*NC);

% ***********************************
% *** 1st FFNUC multiple pre-proc ***
% ***********************************

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** **************************************** ***\n');
fprintf('*** MULTIPLE PRE-PROCESSING of 1st FLATFIELD ***\n');
fprintf('*** **************************************** ***\n');
fprintf('\n');



fprintf('\n')

fprintf('*** Nuclear 1st FlatField pre-estimate : \n');

for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* 1st FlatField - experiment %d : ',ana_path,'\n'),expe);


  % *** load params
  % ***************
  load(cat(2,ana_path,'deltai.mat'),'deltai');
  load(cat(2,ana_path,'imaxi.mat'),'imaxi');
  load(cat(2,ana_path,'imini.mat'),'imini');
  load(cat(2,ana_path,'iedges.mat'),'iedges');

  load(cat(2,ana_path,'Nsig.mat'),'Nsig');

  load(cat(2,ana_path,'fW1.mat'),'fW1');
  load(cat(2,ana_path,'fW2.mat'),'fW2');

  load(cat(2,ana_path,'pad_dpix.mat'),'pad_dpix');
  load(cat(2,ana_path,'fWFF.mat'),'fWFF');
  load(cat(2,ana_path,'FFmini.mat'),'FFmini');

  load(cat(2,ana_path,'pixsize.mat'));

  fWFF_pix=fWFF/pixsize;
  [Npts,~]=size(iedges);


  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- pre-processing of 1st FlatField NUC : ');

  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fprintf(fid,'\n');
  fclose(fid);


  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'1st FlatField preproc (');
  fprintf(fid,'fWFF (um) = ');
  fprintf(fid,num2str(fW2));
  fprintf(fid,';');
  fprintf(fid,'pad_dpix = ');
  fprintf(fid,num2str(pad_dpix));
  fprintf(fid,';');
  fprintf(fid,'FFmini = ');
  fprintf(fid,num2str(FFmini));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);


  % *** load infos
  % ******************
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');


  % *** INIT
  % ******************
  % dir to store data
  save_dir=cat(2,ana_path,'estimate_1stFFNUC/');
  mkdir(save_dir);
  % go !
  fprintf('INITIALIZE 1st FlatField extraction...')
  parfor im=im_start:im_stop
    init_1stflatfield_extraction(ana_path,im);
  end % for im
  fprintf(' DONE ! \n')


  % *** Averaging
  % *************
  fprintf('RUN averaging ...')
  parfor im=im_start:im_stop
    FFNUC_1stFF_rawAVG(ana_path,im);
  end % par for
  fprintf(' DONE ! \n')


  % *** estimate weight of each image
  % *********************************
  scale_vs_im=ones(1,Nim);
  fprintf('ESTIMATE flatfields weights ...');
  for im=im_start:im_stop
    im_ana_dir=cat(2,ana_path,'estimate_1stFFNUC/',num2str(im,'%05d'),'/');
    load(cat(2,im_ana_dir,'rawAVG.mat'),'rawAVG');
    w=sum(rawAVG(:));
    scale_vs_im(1,im)=w;
  end % for im
  % check for nNAN
  ll=isnan(scale_vs_im);
  ll2=(scale_vs_im<0);
  ll3=isinf(scale_vs_im);
  if sum(ll&ll2&ll3)==0
    scale_vs_im(1:im_start,1)=scale_vs_im(1,im_start);
    scale_vs_im(1,im_stop:Nim)=scale_vs_im(1,im_stop);
    scale_vs_im=smooth(scale_vs_im,10)';
    scale_vs_im=scale_vs_im/min(scale_vs_im(:));
  else
    scale_vs_im=ones(1,Nim);
  end % if sum(ll)==0
  save_dir=cat(2,ana_path,'estimate_1stFFNUC/');
  save(cat(2,save_dir,'scale_vs_im.mat'),'scale_vs_im','-v7.3','-nocompression');
  fprintf(' DONE !\n');


  % *** combine averaged images
  % ***************************
  save_dir=cat(2,ana_path,'estimate_1stFFNUC/');
  AVG=zeros(NL,NC);
  fprintf('COMBINE flatfields : image %5d of %5d',0,0)
  for im=im_start:im_stop
    % *** display status...
    for id=1:14
    fprintf('\b');
    end % for id
    fprintf('%5d of %5d',im,Nim);
    im_ana_dir=cat(2,save_dir,num2str(im,'%05d'),'/');
    load(cat(2,im_ana_dir,'rawAVG.mat'),'rawAVG');
    AVG=AVG+medfilt2(rawAVG,[3 3],'symmetric')*scale_vs_im(1,im);
  end % for im
  AVG=AVG/(im_stop-im_start+1);
  fprintf(' DONE ! \n')


  % *** smooth
  % **********
  fprintf('SMOOTH flatfield ...');
  % *** gaussian filter size FFfW
  padded_image=do_padding(AVG,pad_dpix,NL,NC,Lmesh,Cmesh);
  padded_image=imgaussfilt(padded_image,fWFF_pix);
  AVG_f=padded_image((NL+1):(2*NL),(NC+1):(2*NC));
  save_dir=cat(2,ana_path,'estimate_1stFFNUC/');
  save(cat(2,save_dir,'AVG.mat'),'AVG','-v7.3','-nocompression');
  save(cat(2,save_dir,'AVG_f.mat'),'AVG_f','-v7.3','-nocompression');
  fprintf(' DONE ! \n')

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- pre-processing of 1st FlatField NUC ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for expe


% *** combnine EXPE
% *****************

fprintf('\n\n* Combine 1st FlatFields : experiment %5d of %5d',0,0);

FF=zeros(NL,NC);

for expe=1:Nexpe

  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',expe,Nexpe);

  ana_path=ana_path_list{expe,1};
  save_dir=cat(2,ana_path,'estimate_1stFFNUC/');
  load(cat(2,save_dir,'AVG_f.mat'),'AVG_f');
  FF=FF+AVG_f;

end % for exp

% *** filter and normalize
FF=FF/max(FF(:));

fprintf(' DONE ! \n')


% *** save FF for each EXPE
% *************************

% figure
hf=figure('Units','centimeters','PaperSize', [60 60],'visible','off');
ax=subplot(1,1,1);
set(ax,'FontSize',FS,'FontWeight','Bold');
xlabel(ax,'X (\mu m)','FontSize',FS,'FontWeight','Bold');
ylabel(ax,'Y (\mu m)','FontSize',FS,'FontWeight','Bold');
imagesc(ax,'XData',[0:(NC-1)]*pixsize,'YData',[0:(NL-1)]*pixsize,'CData',FF);
axis(ax,'equal');
axis(ax,[0 (NC-1)*pixsize 0 (NL-1)*pixsize]);
caxis(ax,[0 1]);
colormap(ax,hot);
colorbar;

% save loop
fprintf('\n * save experiments %5d of %5d',0,0);
for expe=1:Nexpe

  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',expe,Nexpe);

  ana_path=ana_path_list{expe,1};
  save(cat(2,ana_path,'FF_NUC.mat'),'FF','-v7.3','-nocompression');
  print(cat(2,ana_path,'FlatFieldCorrection_1st_estimate.png'),'-dpng','-r300');

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  t=now;
  fprintf(fid,' --- combined : ');
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fclose(fid);

end % for exp
fprintf(' DONE ! \n')


close(hf);


fprintf('\n\n\n We have pre-processed %5d experiments... GOODLUCK !\n',Nexpe);
delete(POOLOBJ);
fprintf('\n\n');


end % funciton


