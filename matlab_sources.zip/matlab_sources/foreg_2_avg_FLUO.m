function foreg_2_avg_FLUO(ana_path,chanFluo,Npos,NL,NC,imoffset,flipUD,flipLR,FF_bkg,b,fluoTH_low,fluoTH_high,im);


% outputs
Nfound_FOREG2=zeros(NL,NC);
cumu_FOREG2=zeros(NL,NC);
theimage=zeros(NL,NC);
foreg_mask=zeros(NL,NC,'logical');

im_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/','images_infos/',num2str(im,'%0.5d'),'/');
load(cat(2,im_ana_dir,'fileListF_pos.mat'),'fileListF_pos');

for pos=1:Npos

  load(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/',num2str(pos-1,'%0.5d'),'/foreg_mask.mat'));

  % *** load raw data
  theimage=double(imread(fileListF_pos{pos,1}));
  % init_FLUO is preparing fileListF_pos with imdx and not lidx
  theimage=(theimage-imoffset);
  % flip ?
  if flipUD>0 theimage=flipud(theimage); end % if
  % flip ?
  if flipLR>0 theimage=fliplr(theimage); end % if

  theimage=theimage-b*FF_bkg;

  foreg_mask=foreg_mask&(theimage>fluoTH_low)&(theimage<fluoTH_high);

  cumu_FOREG2(foreg_mask)=cumu_FOREG2(foreg_mask)+theimage(foreg_mask);
  Nfound_FOREG2(foreg_mask)=Nfound_FOREG2(foreg_mask)+1;

end % for pos

save(cat(2,im_ana_dir,'cumu_FOREG2.mat'),'cumu_FOREG2','-v7.3','-nocompression');
save(cat(2,im_ana_dir,'Nfound_FOREG2.mat'),'Nfound_FOREG2','-v7.3','-nocompression');

end % function
