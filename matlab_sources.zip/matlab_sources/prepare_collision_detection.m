function prepare_collision_detection(ana_path)

fprintf('prepare collisions detection : ')

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'Nim.mat'));

ROdir=cat(2,ana_path,'tracking_collision_feedback/');
ROcoll_dir=cat(2,ROdir,'collision_detection/');
ROtrack_dir=cat(2,ROdir,'linkage/');

load(cat(2,ROdir,'sorted_celldata.mat'),'sorted_celldata');
load(cat(2,ROdir,'sorted_cellboundLC.mat'),'sorted_cellboundLC');
load(cat(2,ROdir,'sorted_cellmaskLC.mat'),'sorted_cellmaskLC');
[Nscd_tot,~]=size(sorted_celldata);
idxlist=[1:Nscd_tot]';

load(cat(2,ana_path,'combined_data/celldata_fp.mat'));
load(cat(2,ana_path,'combined_data/cellboundLC_fp.mat'));
load(cat(2,ana_path,'combined_data/cellmaskLC_fp.mat'));

for im=Nim:-1:2

  logiidx=(sorted_celldata(:,3)==im)|(sorted_celldata(:,3)==(im-1));
  short_celldata=sorted_celldata(logiidx,:);
  short_cellmaskLC=sorted_cellmaskLC(logiidx,:);
  short_cellboundLC=sorted_cellboundLC(logiidx,:);
  short_idxlist=idxlist(logiidx,:);

  logiidx=(celldata_fp(:,3)==im)|(celldata_fp(:,3)==(im-1));
  short_celldata_fp=celldata_fp(logiidx,:);
  short_cellmaskLC_fp=cellmaskLC_fp(logiidx,:);
  short_cellboundLC_fp=cellboundLC_fp(logiidx,:);

  save_path=cat(2,ROcoll_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');

  save(cat(2,save_path,'short_celldata.mat'),'short_celldata','-v7.3','-nocompression');
  save(cat(2,save_path,'short_cellmaskLC.mat'),'short_cellmaskLC','-v7.3','-nocompression');
  save(cat(2,save_path,'short_cellboundLC.mat'),'short_cellboundLC','-v7.3','-nocompression');

  save(cat(2,save_path,'short_idxlist.mat'),'short_idxlist','-v7.3','-nocompression');

  save(cat(2,save_path,'short_celldata_fp.mat'),'short_celldata_fp','-v7.3','-nocompression');
  save(cat(2,save_path,'short_cellmaskLC_fp.mat'),'short_cellmaskLC_fp','-v7.3','-nocompression');
  save(cat(2,save_path,'short_cellboundLC_fp.mat'),'short_cellboundLC_fp','-v7.3','-nocompression');

end % for im
fprintf(' DONE ! \n')

end % function
