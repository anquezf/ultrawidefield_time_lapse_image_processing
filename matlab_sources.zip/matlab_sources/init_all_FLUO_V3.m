function init_all_FLUO_V3(ana_path,NBMAX_str)

warning off

fprintf('INITIALIZE FLUO Analysis\n')

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

fluo_ana_dir=cat(2,ana_path,'Fluo_Ana/');
mkdir(fluo_ana_dir)

% ******************************
% *** prepare dir for each image
% ******************************

mkdir(cat(2,fluo_ana_dir,'cellDATA/'))

Nim=0; Npos=0;
load(cat(2,ana_path,'Nim.mat'));
load(cat(2,ana_path,'Npos.mat'));

im_start=0; im_stop=0;
load(cat(2,ana_path,'im_start.mat'));
load(cat(2,ana_path,'im_stop.mat'));

NL=0; NC=0;
load(cat(2,ana_path,'NL.mat'));
load(cat(2,ana_path,'NC.mat'));
[Cmesh,Lmesh]=meshgrid(1:NC,1:NL);

pixsize=0;
load(cat(2,ana_path,'pixsize.mat'));

fW2=0;
load(cat(2,ana_path,'fW2.mat'));
Radpix=fW2/pixsize;
Radpix_sq=power(Radpix,2);

sorted_celldata=[];
sorted_cellmaskLC=[];
sorted_cellboundLC=[];
fprintf('* load data ...')
load(cat(2,ana_path,'combined_data/sorted_celldata.mat'))
load(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'))
load(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'))
fprintf(' DONE ! \n')

[Ncell,~]=size(sorted_celldata);
logiidx=zeros(Ncell,1,'logical');

num_cellID=max(sorted_celldata(:,12));
save(cat(2,fluo_ana_dir,'num_cellID.mat'),'num_cellID','-v7.3','-nocompression');

% **********************************************************
% *** Prepare 3 masks for each images and each positions ***
% **********************************************************

fprintf('* intializing images...');
for im=1:Nim

  mkdir(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/'))
  logiidx=(sorted_celldata(:,3)==im);
  short_celldata=sorted_celldata(logiidx,:);
  short_cellmaskLC=sorted_cellmaskLC(logiidx,1);
  short_cellboundLC=sorted_cellboundLC(logiidx,1);
  save(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/','short_celldata.mat'),'short_celldata','-v7.3','-nocompression');
  save(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/','short_cellmaskLC.mat'),'short_cellmaskLC','-v7.3','-nocompression');
  save(cat(2,ana_path,'Fluo_Ana/cellDATA/',num2str(im,'%0.5d'),'/','short_cellboundLC.mat'),'short_cellboundLC','-v7.3','-nocompression');

end % for
fprintf('DONE !\n')

clear('sorted_celldata');
clear('sorted_cellmaskLC');
clear('sorted_cellboundLC');



NBMAX=str2double(NBMAX_str);
POOLOBJ=parpool('local',NBMAX,'IdleTimeout',120);

fprintf('* processing masks...');
parfor im=im_start:im_stop
  prepare_FLUO_cellDATA_V3(ana_path,Lmesh,Cmesh,NL,NC,im,Npos,pixsize,Radpix_sq);
end % for im
fprintf('DONE !\n')



delete(POOLOBJ);

end % function
