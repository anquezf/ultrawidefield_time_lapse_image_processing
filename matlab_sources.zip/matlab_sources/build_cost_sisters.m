function cost=build_cost_sisters(ss_scd,ms_scd,Lmax,Nss,Nms)

Lmax_sq=power(Lmax,2);

data=cat(1,ss_scd,ms_scd);

N1=Nss+Nms;
N2=Nss+Nms;
n1=[1:N1]';
n2=[1:N2];

cost=zeros(N1+1,N2+1,'single');
X1=zeros(N1,N2,'single');
Y1=zeros(N1,N2,'single');
X2=zeros(N1,N2,'single');
Y2=zeros(N1,N2,'single');

% last column and last line are dummy particles

X1=repmat(data(n1,1),1,N2);
Y1=repmat(data(n1,2),1,N2);
X2=repmat(data(n2,1)',N1,1);
Y2=repmat(data(n2,2)',N1,1);
cost(1:N1,1:N2)=power(X1-X2,2)+power(Y1-Y2,2);


% for dummies
% disappearing particle
cost(:,N2+1)=Lmax_sq;
% appearing particle
cost(N1+1,:)=Lmax_sq;
% dummy to dummy
cost(N1+1,N2+1)=Lmax_sq;

%Cmaxi=1e6*max(cost(:));
Cmaxi=inf;

% mother cannot be attributed to mother
for p=(Nss+1):N1
  cost(p,[(Nss+1):N2])=Cmaxi;
end % for p
for p=(Nss+1):N2
  cost([(Nss+1):N2]',p)=Cmaxi;
end % for p
% fill diag (no self attrib)
for p=1:Nss
  cost(p,p)=Cmaxi;
end % for p

end % function
