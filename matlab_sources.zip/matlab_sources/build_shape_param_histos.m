function build_shape_param_histos(ana_path,im)

clean_ana_dir=cat(2,ana_path,'CLEANCELLDATA/');
% *** load inputs
load(cat(2,clean_ana_dir,'edgesI.mat'),'edgesI');
load(cat(2,clean_ana_dir,'edgesA.mat'),'edgesA');

clean_ana_dir=cat(2,ana_path,'CLEANCELLDATA/',num2str(im,'%0.5d'),'/');
% *** load data
load(cat(2,clean_ana_dir,'short_idxlist.mat'),'short_idxlist');
load(cat(2,clean_ana_dir,'short_INTENlist.mat'),'short_INTENlist');
load(cat(2,clean_ana_dir,'short_AREAlist.mat'),'short_AREAlist');


% 1D histos
HI=histc(short_INTENlist,edgesI);

dataX=short_INTENlist;
edgesX=edgesI;

HA=histc(short_AREAlist,edgesA);

dataY=short_AREAlist;
edgesY=edgesA;

% free mem
clear('short_INTENlist','short_AREAlist','edgesA','edgesI')


% 2D histo
[NX,~]=size(edgesX);
[NY,~]=size(edgesY);
HISTO2D=zeros(NY,NX);

for px=2:NX
  for py=2:NY
    logiidx=(dataX>edgesX(px-1,1))&(dataX<=edgesX(px,1))&(dataY>edgesY(py-1,1))&(dataY<=edgesY(py,1));
    HISTO2D(py,px)=sum(logiidx(:));
  end % for py
end % for px


for px=2:NX
    logiidx=(dataX>edgesX(px-1,1))&(dataX<=edgesX(px,1))&(dataY<=edgesY(1,1));
    HISTO2D(1,px)=sum(logiidx(:));
end % for px

for py=2:NY
  logiidx=(dataX<=edgesX(1,1))&(dataY>edgesY(py-1,1))&(dataY<=edgesY(py,1));
  HISTO2D(py,px)=sum(logiidx(:));
end % for px


% *** save data
save(cat(2,clean_ana_dir,'HI.mat'),'HI','-v7.3','-nocompression');
save(cat(2,clean_ana_dir,'HA.mat'),'HA','-v7.3','-nocompression');
save(cat(2,clean_ana_dir,'HISTO2D.mat'),'HISTO2D','-v7.3','-nocompression');

end % function
