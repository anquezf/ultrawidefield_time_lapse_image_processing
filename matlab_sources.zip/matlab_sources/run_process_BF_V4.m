function run_process_BF_V3(ana_path,Nsig_BF_str,NBMAX_str)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

NBMAX=str2double(NBMAX_str);


Nsig_BF=str2num(Nsig_BF_str);
save(cat(2,ana_path,'Nsig_BF.mat'),'Nsig_BF','-v7.3','-nocompression');


% ***
% *** Load data

load(cat(2,ana_path,'Nim.mat'),'Nim')
load(cat(2,ana_path,'Npos.mat'),'Npos')
load(cat(2,ana_path,'pos_List.mat'),'pos_List');



% ***
% *** init analysis

fprintf('* INITIALIZE BrightField processing : \n');

% *** load data

fprintf('load data ...');
load(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata')

[Ncell,~]=size(sorted_celldata);
idxs=[1:Ncell]';
fprintf(' DONE!\n')

data_dir=cat(2,ana_path,'BFproc/');
mkdir(data_dir);

% *** positions
fprintf('intializing position %5d of %5d',0,Npos);
for pos=1:Npos

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',pos,Npos);

  % create ana_dir
  pos_ana_dir=cat(2,ana_path,'BFproc/',num2str(pos-1,'%0.5d'),'/');
  mkdir(pos_ana_dir);
  
  logiidx=sorted_celldata(:,10)==(pos-1);
  short_celldata=sorted_celldata(logiidx,:);

  save(cat(2,pos_ana_dir,'logiidx.mat'),'logiidx','-v7.3','-nocompression');
  save(cat(2,pos_ana_dir,'short_celldata.mat'),'short_celldata','-v7.3','-nocompression');

end % for pos
fprintf(' DONE! \n')



% ***
% *** process raw AVG

fprintf('* PROCESS BrightField Signal : \n');

POOLOBJ=parpool('local',NBMAX,'IdleTimeout',120);
parfor pos=1:Npos
 process_BF_V4(ana_path,pos);
end % par for
delete(POOLOBJ);

fprintf(' DONE!\n');


end % function



