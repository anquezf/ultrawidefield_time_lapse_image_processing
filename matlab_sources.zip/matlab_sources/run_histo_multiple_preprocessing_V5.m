function run_histo_multiple_preprocessing_V5(useFFforeg_str,RESETanapath_str,save_dir,NBMAX_str)

warning off

% ********************************************
% *** get  current ana_path_list and NBmax ***
% ********************************************

RESETanapath=str2double(RESETanapath_str);

if RESETanapath==1

  fprintf('RESET analysis paths\n');

  fprintf('*** Please select A BUNCH of EXISTING experiments\n')
  ana_path_list=uipickfiles('FilterSpec',save_dir)';
  fprintf('\n');

  [Nexpe,~]=size(ana_path_list);
  for expe=1:Nexpe
    ana_path=ana_path_list{expe,1};
    [~,Nchar]=size(ana_path);
    if ~(strcmp(ana_path(1,Nchar),'/'))
      ana_path=cat(2,ana_path,'/');
    end % if
    ana_path_list{expe,1}=ana_path;
    fprintf(cat(2,ana_path,'\n'));
  end % for exp

else

  run_path=pwd;
  [~,Nchar]=size(run_path);
  if ~(strcmp(run_path(1,Nchar),'/'))
    run_path=cat(2,run_path,'/');
  end % if
  load(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe');

end % if


% ********************************************
% *** save current ana_path_list and NBmax ***
% ********************************************

run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if

save(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe','-v7.3','-nocompression');



fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ************************************ ***\n');
fprintf('*** MULTIPLE PRE-PROCESSING of HISTOGRAM ***\n');
fprintf('*** ************************************ ***\n');
fprintf('\n');


fprintf('\n\n')


% ******************************
% *** some usefull variables ***
% ******************************
useFFforeg=str2double(useFFforeg_str);

NBMAX=str2double(NBMAX_str);
POOLOBJ=parpool('local',NBMAX,'IdleTimeout',360);

fprintf('\n')

% 1st FF smoothing : NL,NC
ana_path=ana_path_list{1,1};

load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

% mesh grid
[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);
padded_image=zeros(3*NL,3*NC);



% ************************************************************************************************************************************************

% ************************
% *** CORRECTED HISTO  ***
% ************************




fprintf('*** PROCESS corrected HISTOGRAMS  \n');


for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* corrected HISTO - experiment %d : ',ana_path,'\n\n'),expe);

  save(cat(2,ana_path,'useFFforeg.mat'),'useFFforeg','-v7.3','-nocompression');

  load(cat(2,ana_path,'deltai.mat'),'deltai');
  load(cat(2,ana_path,'imaxi.mat'),'imaxi');
  load(cat(2,ana_path,'imini.mat'),'imini');
  load(cat(2,ana_path,'iedges.mat'),'iedges');

  load(cat(2,ana_path,'Nsig.mat'),'Nsig');

  load(cat(2,ana_path,'fW1.mat'),'fW1');
  load(cat(2,ana_path,'fW2.mat'),'fW2');

  load(cat(2,ana_path,'pad_dpix.mat'),'pad_dpix');
  load(cat(2,ana_path,'fWFF.mat'),'fWFF');
  load(cat(2,ana_path,'FFmini.mat'),'FFmini');

  load(cat(2,ana_path,'pixsize.mat'));

  fWFF_pix=fWFF/pixsize;
  [Npts,~]=size(iedges);


  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');

  load(cat(2,ana_path,'b0.mat'),'b0');
  load(cat(2,ana_path,'delta_b_vsim.mat'),'delta_b_vsim');

 

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- pre-processing of corrected HISTO : ');

  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fprintf(fid,'\n');
  fclose(fid);

  % *** HISTO
  % *********

  % *** write log file

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'preproc_corrected_HISTO_V9 (');
  fprintf(fid,'deltai = ');
  fprintf(fid,num2str(deltai));
  fprintf(fid,';');
  fprintf(fid,'imini = ');
  fprintf(fid,num2str(imini));
  fprintf(fid,';');
  fprintf(fid,'imaxi = ');
  fprintf(fid,num2str(imaxi));
  fprintf(fid,';');
  fprintf(fid,'Nsig = ');
  fprintf(fid,num2str(Nsig));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** run
  fprintf('compute corrected HISTO...');
  parfor pos=1:Npos
    preproc_corrected_HISTO_V9(ana_path,pos);
  end % parfor pos
  fprintf(' DONE ! \n');

  % combine
  cor_histo_all=zeros(Npts,Nim);
  fprintf('combine corrected HISTO for position ...');
  for pos=1:Npos
    pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
    load(cat(2,pos_ana_dir,'histo_cor.mat'),'histo_cor');
    cor_histo_all=cor_histo_all+histo_cor;
  end % for pos
  fprintf(' DONE ! \n');


  % *** global mean and std per image
  % ***
  mu_cor_all=zeros(1,Nim);
  sig_cor_all=zeros(1,Nim);
  A0=0;
  fprintf('ESTIMATE corrected mu and sig for image %5d of %5d',0,Nim);
  for im=im_start:im_stop
    % *** display status...
    for id=1:14
    fprintf('\b');
    end % for id
    fprintf('%5d of %5d',im,Nim);
    % pdf
    n=cor_histo_all(:,im);
    % mean/mode
    [A0,idxm]=max(n); idxm=idxm(1,1);
    mu0=iedges(idxm,1);
    % find std : 2*std at A0*0.1353 std at A0*0.6065
    [~,idxl]=min(abs(n(1:idxm,1)-0.6065*A0)); idxl=idxl(1,1);
    sig0=abs(max(mu0-iedges(idxl,1)));
    mu_cor_all(1,im)=mu0;
    sig_cor_all(1,im)=sig0;
  end % for im
  
  % save
  save(cat(2,ana_path,'cor_histo_all.mat'),'cor_histo_all','-v7.3','-nocompression');
  save(cat(2,ana_path,'mu_cor_all.mat'),'mu_cor_all','-v7.3','-nocompression');
  save(cat(2,ana_path,'sig_cor_all.mat'),'sig_cor_all','-v7.3','-nocompression');
  fprintf(' DONE ! \n');

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- pre-processing of corrected HISTO ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for expe




fprintf('\n\n\n We have pre-processed %5d experiments... GOODLUCK !\n',Nexpe);
delete(POOLOBJ);
fprintf('\n\n');


end % funciton


