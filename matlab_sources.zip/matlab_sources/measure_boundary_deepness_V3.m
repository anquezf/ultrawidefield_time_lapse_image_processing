function [dBxB_list,dBxC_list,arcL_list,L0_list,C0_list,nidx_list,pidx_list,Lc,Cc,int_k,cvx_k]=measure_boundary_deepness_V3(BLC)

warning off

% be carrefull in defining BLC
% must contain ordered points
% use :
% BLC=bwboundaries(mm); BLC=BLC{1,1};

BLC=double(BLC);
[Nbound,~]=size(BLC);

% ****************************
% test possibility of analysis
% ****************************

dist=sqrt(power(BLC(1:(Nbound-1),1)-BLC(2:Nbound,1),2)+power(BLC(1:(Nbound-1),2)-BLC(2:Nbound,2),2));
logiidx=(dist>1);
uNbound=sum(logiidx);

score=test_collinear(BLC(1:(Nbound-1),1),BLC(1:(Nbound-1),2),Nbound-1);

dBxB_list=[];
dBxC_list=[];
arcL_list=[];
L0_list=[];
C0_list=[];
nidx_list=[];
pidx_list=[];
Lc=[];
Cc=[];

if (uNbound>5)&&(score>0.001)

  %last and first points of BLC are the same...
  bidx=[1:Nbound]';

  % ***
  % *** get cvx hull ***
  cvx_k=convhull(BLC(:,2),BLC(:,1));
  [Ncvx,~]=size(cvx_k);

  if Ncvx>2

    % cvx_k without duplicate
    if (BLC(cvx_k(1,1),1)==BLC(cvx_k(Ncvx,1),1))&&(BLC(cvx_k(1,1),2)==BLC(cvx_k(Ncvx,1),2))
      cvx_k_nod=cvx_k(1:(Ncvx-1),1);
    else
      cvx_k_nod=cvx_k;
    end

    % ***
    % *** get insides idxs ***
    int_k=[];
    for kk=1:Nbound
      [is_in,is_on]=inpolygon(BLC(kk,1),BLC(kk,2),BLC(cvx_k,1),BLC(cvx_k,2));
      if (is_in>0)&&(is_on==0)
        int_k=cat(1,int_k,kk);
      end % if is_in&&(~is_on)
    end % for kk
    [Nint,~]=size(int_k);

    is_catched=zeros(Nint,1,'logical');

    if Nint>1

      [Cc,Lc]=centroid(polyshape(BLC(cvx_k_nod,2),BLC(cvx_k_nod,1)));

      Ncatched=sum(is_catched);
      d_sq=power(BLC(int_k,1)-Lc,2)+power(BLC(int_k,2)-Cc,2);


      while Ncatched<Nint

        % *** get closest point from center to inside CVX hull
        [~,ii]=min(d_sq); ii=ii(1,1);
        L0=BLC(int_k(ii,1),1);
        C0=BLC(int_k(ii,1),2);

        % *** catch it
        is_catched(ii,1)=1;
        d_sq(ii,1)=inf;

        % next
        logiidx_n=(cvx_k>int_k(ii,1));
        logiidx_p=(cvx_k<int_k(ii,1));

        if (sum(logiidx_n(:))>0)&&(sum(logiidx_p(:))>0)

          n_idx=min(cvx_k(logiidx_n,1));
          p_idx=max(cvx_k(logiidx_p,1));

          % add to list
          L0_list=cat(1,L0_list,L0);
          C0_list=cat(1,C0_list,C0);

          nidx_list=cat(1,nidx_list,n_idx);
          pidx_list=cat(1,pidx_list,p_idx);

          % *** estimate distance to cvx hull
          dBxB=abs((BLC(n_idx,2)-BLC(p_idx,2))*(BLC(p_idx,1)-L0)-(BLC(p_idx,2)-C0)*(BLC(n_idx,1)-BLC(p_idx,1)))/sqrt(power(BLC(n_idx,2)-BLC(p_idx,2),2)+power(BLC(n_idx,1)-BLC(p_idx,1),2));
          dBxB_list=cat(1,dBxB_list,dBxB);
          % *** estimate distance betewenn center and cvx hull
          dBxC=abs((BLC(n_idx,2)-BLC(p_idx,2))*(BLC(p_idx,1)-Lc)-(BLC(p_idx,2)-Cc)*(BLC(n_idx,1)-BLC(p_idx,1)))/sqrt(power(BLC(n_idx,2)-BLC(p_idx,2),2)+power(BLC(n_idx,1)-BLC(p_idx,1),2));
          dBxC_list=cat(1,dBxC_list,dBxC);
          % *** estimate boundary distance
          arcL=sqrt(power(BLC(n_idx,1)-BLC(p_idx,1),2)+power(BLC(n_idx,2)-BLC(p_idx,2),2));
          arcL_list=cat(1,arcL_list,arcL);

          % *** mark catched
          % all interior pts in between cvxH
          ll=(int_k<=n_idx)&(int_k>=p_idx);
          is_catched=is_catched+ll;

        end % if (sum(logiidx_n(:))>0)&&(sum(logiidx_p(:))>0)

        for int=1:Nint
          if is_catched(int,1)>0
            d_sq(int,1)=inf;
          end
        end
        Ncatched=sum(is_catched);

      end % while

    end % if Nint>1

end % if Ncvx>2

end        
        
if isempty(dBxB_list)
  int_k=[];
  cvx_k=[];
end % if

end % function
