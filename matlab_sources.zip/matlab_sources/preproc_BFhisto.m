function preproc_BFhisto(ana_path,pos)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if


load(cat(2,ana_path,'deltai_bf.mat'),'deltai_bf');
load(cat(2,ana_path,'imaxi_bf.mat'),'imaxi_bf');
load(cat(2,ana_path,'imini_bf.mat'),'imini_bf');
load(cat(2,ana_path,'iedges_bf.mat'),'iedges_bf');

load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

load(cat(2,ana_path,'flipUD.mat'),'flipUD');
load(cat(2,ana_path,'flipLR.mat'),'flipLR');

load(cat(2,ana_path,'NL.mat'));
load(cat(2,ana_path,'NC.mat'));
load(cat(2,ana_path,'imoffset.mat'));

theimage=zeros(NL,NC);

% load data

pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');

save_dir=cat(2,ana_path,'BFbkg_estimate/');
pos_ana_dir=cat(2,save_dir,'POSITIONS/',num2str(pos-1,'%0.5d'),'/');
load(cat(2,pos_ana_dir,'fileListBF.mat'),'fileListBF');

mu_bf_vs_im=zeros(1,Nim);
sig_bf_vs_im=zeros(1,Nim);


for im=im_start:im_stop

  ll=imidx_2_lidx(im,1);

  % load BFavg
  im_ana_dir=cat(2,save_dir,'IMAGES/',num2str(im,'%05d'),'/');
  load(cat(2,im_ana_dir,'BFrawAVG.mat'),'BFrawAVG');

  % *** load raw data
  theimage=double(imread(fileListBF{ll,1}));
  theimage=(theimage-imoffset)-BFrawAVG;

  [n,~]=histc(theimage(:),iedges_bf);
    % mean and std
  n=smooth(n,5); % build pdf
  [A0,idxm]=max(n); idxm=idxm(1,1); % estimate mean/mode
  mu0=iedges_bf(idxm,1);
  [~,idxl]=min(abs(n(1:idxm,1)-0.6065*A0)); idxl=idxl(1,1); % find std : 2*std at A0*0.1353 std at A0*0.6065
  sig0=abs(max(mu0-iedges_bf(idxl,1)));
  mu_bf_vs_im(1,im)=mu0;
  sig_bf_vs_im(1,im)=sig0;

end % for im

save_dir=cat(2,ana_path,'BFbkg_estimate/');
pos_ana_dir=cat(2,save_dir,'POSITIONS/',num2str(pos-1,'%0.5d'),'/');
save(cat(2,pos_ana_dir,'mu_bf_vs_im.mat'),'mu_bf_vs_im','-v7.3','-nocompression');
save(cat(2,pos_ana_dir,'sig_bf_vs_im.mat'),'sig_bf_vs_im','-v7.3','-nocompression');

end % funciton
