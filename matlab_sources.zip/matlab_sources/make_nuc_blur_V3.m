function theimage_b=make_nuc_blur_V3(theimage,fW1,fW2)

  %theimage_b=medfilt2(theimage,[mfW mfW]);
  theimage_b=imgaussfilt(theimage,fW1,'Padding','symmetric')-imgaussfilt(theimage,fW2,'Padding','symmetric');
  theimage_b=theimage_b.*(theimage_b>0);

end % function
