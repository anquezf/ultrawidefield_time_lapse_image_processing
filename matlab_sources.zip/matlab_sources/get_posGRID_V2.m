function [posGRID,NposX,NposY]=get_posGRID_V2(Npos,XYlist,deltaXpos,deltaYpos,WX,WY)


% **************************
% *** find NposX ; NposY ***
% **************************

% find the center
[Yc,~]=min(abs(XYlist(:,2)));
[Xc,~]=min(abs(XYlist(:,1)));

% find number of pos right
[Xmax,~]=max(XYlist(:,1));
Npr=(Xmax-Xc)/(WX+deltaXpos);
% find number of pos right
[Xmin,~]=min(XYlist(:,1));
Npl=(Xc-Xmin)/(WX+deltaXpos);

NposX=round(Npr+Npl+1);

% find number of pos up
[Ymax,~]=max(XYlist(:,2));
Npu=(Ymax-Yc)/(WY+deltaYpos);
% find number of pos down
[Ymin,~]=min(XYlist(:,2));
Npd=(Yc-Ymin)/(WY+deltaYpos);

NposY=round(Npu+Npd+1);


% *********************
% *** build posGRID ***
% *********************

posGRID=nan(NposY,NposX);

Wminsq=power(min([WX/2,WY/2]),2);
idxs=[1:Npos]';

X0=min(XYlist(:,1)); X0=X0(1,1);
Y0=max(XYlist(:,2)); Y0=Y0(1,1);

for posX=1:NposX

  for posY=1:NposY

    Ycur=Y0-(posY-1)*(WY+deltaYpos);
    Xcur=X0+(posX-1)*(WX+deltaXpos);

    ddsq=power(XYlist(:,1)-Xcur,2)+power(XYlist(:,2)-Ycur,2);
    [dd0sq,idx]=min(ddsq);
    if dd0sq<Wminsq
      posGRID(posY,posX)=idx(1,1);
    end

  end % for posY

end % for posX


end %function


