function FFNUC_rawAVG(ana_path,im)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'Npos.mat'),'Npos');
load(cat(2,ana_path,'imoffset.mat'));

load(cat(2,ana_path,'NL.mat'));
load(cat(2,ana_path,'NC.mat'));
BFrawAVG=zeros(NL,NC);

save_dir=cat(2,ana_path,'BFbkg_estimate/');
im_ana_dir=cat(2,save_dir,'IMAGES/',num2str(im,'%05d'),'/');
load(cat(2,im_ana_dir,'fileListBF_pos.mat'),'fileListBF_pos');

for pos=1:Npos
  theimage=double(imread(fileListBF_pos{pos,1}));
  theimage=theimage-imoffset;
  BFrawAVG=BFrawAVG+theimage;
end % for pos

BFrawAVG=BFrawAVG/Npos;
save(cat(2,im_ana_dir,'BFrawAVG.mat'),'BFrawAVG','-v7.3','-nocompression');

end % function
