function [Lmask,Nreg_out]=do_watershed_seg(data,mask_ini,Nreg,NL,NC)

maxi=round(max(data(mask_ini)));
mini=round(min(data(mask_ini)));

%figure;

Nreg_out=0;
Lmask=zeros(NL,NC);
for vv=mini:maxi
  %vv
  mask=(data<=vv).*mask_ini;
  [mask,Nrg]=bwlabel(mask);
%  hold off; imagesc(mask); axis equal;
%  drawnow;
%  waitforbuttonpress
  if Nrg<=Nreg
    Lmask=mask;
    Nreg_out=Nrg;
  end
end % for vv

end % function
