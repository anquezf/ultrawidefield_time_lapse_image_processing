function [mask,Nreg_out]=split_cell(Nreg,MLC,BLC,L0,C0,NL,NC)

mask=zeros(NL,NC,'uint16');

% *** find center of mass
Lc=mean(MLC(:,1));
Cc=mean(MLC(:,2));

% ********************************
% *** find boundary from first point
% ********************************

% find its idx
ddsq=power(BLC(:,1)-L0,2)+power(BLC(:,2)-C0,2);
[~,pidx]=min(ddsq);
% compute boundary
[Lw,Cw]=walk_toward_boundary(Lc,Cc,pidx,BLC);

% *****************************
% *** find boundary from others
% *****************************

% *** params
% ref vector
v1x=C0-Cc;
v1y=L0-Lc;
nv1=sqrt(power(v1x,2)+power(v1y,2));
% all vectors
v2x=BLC(:,2)-Cc;
v2y=BLC(:,1)-Lc;
nv2=sqrt(power(v2x,2)+power(v2y,2));
% all angles
thetas=acos((v1x*v2x+v1y*v2y)./(nv1*nv2));
% all distances to center
dists_sq=power(BLC(:,1)-Lc,2)+power(BLC(:,2)-Cc,2);

% *** for each angle int
% angle to turn
dtheta=2*pi/Nreg;
% boundary points idxs
[Nbound,~]=size(BLC);
idxs=[1:Nbound]';
for r=2:Nreg
  % find bounds
  theta0=(r-1)*dtheta;
  theta_min=theta0-dtheta/2;
  theta_max=theta0+dtheta/2;
  % select boundary
  logiidx=(thetas>=theta_min)&(thetas<=theta_max);
  idxlist=idxs(logiidx,1);
  if ~isempty(idxlist)
    [~,ii]=min(dists_sq(idxlist,1));
    ii=ii(1,1);
    pidx=idxlist(ii,1);
    [Lwta,Cwta]=walk_toward_boundary(Lc,Cc,pidx,BLC);
    Lw=cat(1,Lw,Lwta);
    Cw=cat(1,Cw,Cwta);
  end % if
end % for r


% *************
% *** make mask
% *************
   
[Npix,~]=size(MLC);
for pix=1:Npix
  mask(MLC(pix,1),MLC(pix,2))=1;
end % for pix

[Npix,~]=size(Lw);
for pix=1:Npix
  mask(Lw(pix,1),Cw(pix,1))=0;
end % for pix

[mask,Nreg_out]=bwlabel(mask);

if (Nreg_out>Nreg)&(Nreg>0)
  toremove=Nreg_out-Nreg;
  for r=1:toremove

    Alist=zeros(Nreg_out,1);
    for c=1:Nreg_out
      logiidx=(mask==c);
      Alist(c,1)=sum(logiidx(:));
    end % for c
    [~,ii]=min(Alist); ii=ii(1,1);
    logiidx=(mask==ii);
    mask(logiidx)=0;
    [mask,Nreg_out]=bwlabel(mask);

  end % for toremove
end % if

end % funciton



