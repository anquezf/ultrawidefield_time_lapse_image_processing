function dup_score=test_duplicate(X,Y,Npts,dup_tol)

dup_score=0;
for p=1:Npts
  X1=X(p,1);
  Y1=Y(p,1);
  ll=(abs(X1-X)>dup_tol)&(abs(Y1-Y)>dup_tol);
  if sum(ll)<(Npts-1)
    dup_score=1;
    break;
  end %if
end % for p

end % function
