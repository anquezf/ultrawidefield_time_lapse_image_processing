function [mask_out,Nreg_out]=make_mask_merge_adj_V8(mask_in,Nreg_in,NL,NC,se,OVTH,OVTH2,deepTH)

% comparing imerode and full image works well to detect boundaries of simple objects
% it is faster that the bwboundaries function...

Nreg_out=0;
mask_out=zeros(NL,NC);

mm1=zeros(NL,NC);


% calculate boundaries and extended boundaries
Bounds=cell(Nreg_in,1);
extBounds=cell(Nreg_in,1);
Perims=zeros(Nreg_in,1);
extPerims=zeros(Nreg_in,1);
Areas=zeros(Nreg_in,1);
% init
for c=1:Nreg_in
  % bounds
  mm1=(mask_in==c);
  BLC=bwboundaries(mm1);
  if ~isempty(BLC)
    BLC=BLC{1,1};
  else
    BLC=[];
  end % if
  [Nb1,~]=size(BLC);
  Bounds{c,1}=BLC;
  Perims(c,1)=Nb1;
  Areas(c,1)=sum(mm1(:));
  % ext bounds
  mm1=imdilate(mm1,se);
  BLC=bwboundaries(mm1);
  if ~isempty(BLC)
    BLC=BLC{1,1};
  else
    BLC=[];
  end % if
  [Nb1,~]=size(BLC);
  extBounds{c,1}=BLC;
  extPerims(c,1)=Nb1;
end % for c


catched=[];
c1_catched=[];
for c1=1:(Nreg_in-1)

 c1_catched=[];
 % was catched ???
 isc1catched=(c1==catched);
 if (sum(isc1catched(:))==0)

  Nb1=Perims(c1,1);

  if Nb1>0

    % *** extend boundaries for cell 1
    Perim1=extPerims(c1,1);
    BLC1=extBounds{c1,1};

    % *** look at all other cells
    for c2=(c1+1):Nreg_in

     isc2catched=(c2==catched);
     if (sum(isc2catched(:))==0)

      % we have dilated c1, we don't for c2
      Nb2=Perims(c2,1);
      BLC2=Bounds{c2,1};

      % process
      if Nb2>0

	% find c2 perimeter
        Perim2=Nb2;

        % calculate shared region
	shared=0;
	for b2=1:Nb2
	  logiidx=(BLC1(:,1)==BLC2(b2,1))&(BLC1(:,2)==BLC2(b2,2));
	  shared=shared+sum(logiidx);
	end % for b2
        OV=max([(shared/Perim1);(shared/Perim2)]);

        if (OV>OVTH)
          c1_catched=cat(1,c1_catched,c2);
	  catched=cat(1,catched,c2);
        elseif (OV>OVTH2)
          % get deepness of merge
          mm1=(mask_in==c1)|(mask_in==c2);
          BLC=bwboundaries(mm1);
          if ~(isempty(BLC))
            BLC=BLC{1,1};
            [dBxBm,dBxCm,~,~,~,~,~,~,~,~,~]=measure_max_boundary_deepness_V3(BLC);
          else
            dBxBm=[];
            dBxCm=[];
          end % if ~(isempty(BLC))
          % check deepness
          deepNm=-1;
          if ~(isempty(dBxBm))
            deepNm=dBxBm/dBxCm;
          end
          % catch ??
          if (deepNm<deepTH)
	    c1_catched=cat(1,c1_catched,c2);
	    catched=cat(1,catched,c2);
          end % if
        end % if (OV>OVTH)

      end % if Nb2>0

     end % if ~isc2catched

    end % for c2

  end % if Nb1>0

  % *** update mask
  % c1
  Nreg_out=Nreg_out+1;
  mask_out((mask_in==c1))=Nreg_out;
  % catched
  [Ncatched,~]=size(c1_catched);
  if Ncatched>0
    for cc=1:Ncatched
      mask_out((mask_in==c1_catched(cc,1)))=Nreg_out;
    end % for cc
  end % if

 end % if ~isc1catched

end % for c1


% *** check wether the last region was catched 
c1=Nreg_in;
iscatched=(c1==catched);
if (sum(iscatched(:))==0)
  Nreg_out=Nreg_out+1;
  mask_out((mask_in==c1))=Nreg_out;
end % if

	  
end % funciton
