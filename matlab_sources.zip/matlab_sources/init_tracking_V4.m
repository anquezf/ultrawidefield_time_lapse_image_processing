function init_tracking_V4(ana_path,Nsplit_str,useWB_str,useWS_str,Lmax_str,WBSweight_str,Nitemax_str)

warning off

fprintf('intializing tracking ... \n')
% celldata=[X,Y,imidx,A,theta,L,C,wB,wS,p]
% celldata_clean=[X,Y,imidx,A,theta,L,C,wB,wS,p1,p2]

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% *** INPUTS

% load inputs
Nsplit=str2double(Nsplit_str);
useWB=str2double(useWB_str);
useWS=str2double(useWS_str);
Lmax=str2double(Lmax_str);
WBSweight=str2double(WBSweight_str);
Nitemax=str2double(Nitemax_str);


% *** load analysis params
load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');
load(cat(2,ana_path,'pixsize.mat'),'pixsize');
load(cat(2,ana_path,'NC.mat'),'NC');
load(cat(2,ana_path,'NL.mat'),'NL');
% for sorting
load(cat(2,ana_path,'XYlist.mat'),'XYlist');
Xmin=min(XYlist(:,1))-NC*pixsize;
Xmax=max(XYlist(:,1))+NC*pixsize;
Ymin=min(XYlist(:,2))-NL*pixsize;
Ymax=max(XYlist(:,2))+NL*pixsize;
DXX=(Xmax-Xmin)/Nsplit;
DYY=(Ymax-Ymin)/Nsplit;


% load celldata
dataloc=cat(2,ana_path,'combined_data/celldata_clean.mat');
load(cat(2,ana_path,'combined_data/celldata_clean.mat'),'celldata_clean');

% save inputs
save_path=cat(2,ana_path,'tracking/');
mkdir(save_path)

% change for single
% algo runs a bit less than 2 times faster in this case
% memory used is twice smaller
Lmax=single(Lmax);

save(cat(2,save_path,'dataloc.mat'),'dataloc','-v7.3','-nocompression');
save(cat(2,save_path,'useWB.mat'),'useWB','-v7.3','-nocompression');
save(cat(2,save_path,'useWS.mat'),'useWS','-v7.3','-nocompression');
save(cat(2,save_path,'Lmax.mat'),'Lmax','-v7.3','-nocompression');
save(cat(2,save_path,'WBSweight.mat'),'WBSweight','-v7.3','-nocompression');
save(cat(2,save_path,'Nitemax.mat'),'Nitemax','-v7.3','-nocompression');

save(cat(2,save_path,'celldata_IN.mat'),'celldata_clean','-v7.3','-nocompression');


[Ncell,~]=size(celldata_clean);
idxs=[1:Ncell]';


im_c=0;
im_p=0;
fprintf('intializing linkage for image %5d to %5d',0,0);
for im=im_stop:-1:(im_start+1)

  % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d to %5d',im,im-1);

  save_path=cat(2,ana_path,'tracking/',num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
  mkdir(save_path)
  im_c=im;
  im_p=im-1;

  logiidx_c=(celldata_clean(:,3)==im_c);
  logiidx_p=(celldata_clean(:,3)==im_p);

  data_c=celldata_clean(logiidx_c,:);
  data_p=celldata_clean(logiidx_p,:);

  idxc=idxs(logiidx_c,1);
  idxp=idxs(logiidx_p,1);

  N_c=sum(logiidx_c(:));
  N_p=sum(logiidx_p(:));

  short_celldata_c=zeros(N_c,11,'single');
  short_celldata_p=zeros(N_p,11,'single');
  idxlist_c=zeros(N_c,1);
  idxlist_p=zeros(N_p,1);

  % sorting celldata by regions helps
  % trackong run very much faster

  icstart=1;
  ipstart=1;
  for cx=1:Nsplit
    for cy=1:Nsplit

    % cur im
    logiidx=(data_c(:,1)>(Xmin+(cx-1)*DXX))&(data_c(:,1)<=(Xmin+cx*DXX))&(data_c(:,2)>(Ymin+(cy-1)*DYY))&(data_c(:,2)<=(Ymin+cy*DYY));
    NN=sum(logiidx);
    icstop=icstart+(NN-1);

    short_celldata_c(icstart:icstop,:)=data_c(logiidx,:);
    idxlist_c(icstart:icstop,:)=idxc(logiidx,:);

    icstart=icstop+1;

    % prev im
    logiidx=(data_p(:,1)>(Xmin+(cx-1)*DXX))&(data_p(:,1)<=(Xmin+cx*DXX))&(data_p(:,2)>(Ymin+(cy-1)*DYY))&(data_p(:,2)<=(Ymin+cy*DYY));
    NN=sum(logiidx);
    ipstop=ipstart+(NN-1);

    short_celldata_p(ipstart:ipstop,:)=data_p(logiidx,:);
    idxlist_p(ipstart:ipstop,:)=idxp(logiidx,:);

    ipstart=ipstop+1;

    end % for cy
  end % for cx

  % change for single
  % algo runs a bit less than 2 times faster in this case
  % memory used is twice smaller
  short_celldata_c=single(short_celldata_c);
  short_celldata_p=single(short_celldata_p);

  save(cat(2,save_path,'im_c.mat'),'im_c','-v7.3','-nocompression');
  save(cat(2,save_path,'idxlist_c.mat'),'idxlist_c','-v7.3','-nocompression');
  save(cat(2,save_path,'im_p.mat'),'im_p','-v7.3','-nocompression');
  save(cat(2,save_path,'idxlist_p.mat'),'idxlist_p','-v7.3','-nocompression');

  save(cat(2,save_path,'short_celldata_p.mat'),'short_celldata_p','-v7.3','-nocompression');
  save(cat(2,save_path,'short_celldata_c.mat'),'short_celldata_c','-v7.3','-nocompression');

end % for im
fprintf('\n')
fprintf('tracking initialization DONE ! \n')

end % funciton
