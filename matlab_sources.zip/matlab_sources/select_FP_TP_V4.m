function [IMAXI_list,AMAXI_list,AFP_list,IFP_list,C_list]=select_FP_TP_V4(ana_path,Nbunch,IMAXI0,AMAXI0,AFP0,IFP0,C0)

FS=15;
warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% **********
% *** inputs
% **********

load(cat(2,ana_path,'CLEANCELLDATA/HISTO1D_I.mat'),'HISTO1D_I')
load(cat(2,ana_path,'CLEANCELLDATA/HISTO1D_A.mat'),'HISTO1D_A')
load(cat(2,ana_path,'CLEANCELLDATA/HISTO2D_IA.mat'),'HISTO2D_IA')

load(cat(2,ana_path,'CLEANCELLDATA/edgesI.mat'),'edgesI')
load(cat(2,ana_path,'CLEANCELLDATA/edgesA.mat'),'edgesA')
load(cat(2,ana_path,'CLEANCELLDATA/IBS.mat'),'IBS')
load(cat(2,ana_path,'CLEANCELLDATA/ABS.mat'),'ABS')

load(cat(2,ana_path,'CLEANCELLDATA/imaxi.mat'),'imaxi')
load(cat(2,ana_path,'CLEANCELLDATA/amaxi.mat'),'amaxi')

load(cat(2,ana_path,'Nim.mat'),'Nim')
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

Ngroup=floor((im_stop-im_start+1)/Nbunch);
Nrest=(im_stop-im_start+1)-Ngroup*Nbunch;

% *********************
% *** init params   ***
% *********************

% AFP0 ; IFP0
[HAmax,idxma]=max(HISTO1D_A); idxma=idxma(1,1);
AFP0=edgesA(idxma,1)+ABS/2;
[HImax,idxmi]=max(HISTO1D_I); idxmi=idxmi(1,1);
IFP0=edgesI(idxmi,1)+IBS/2;

% AREA MAXI init
load(cat(2,ana_path,'fW2.mat'),'fW2');
if nargin<3
  AMAXI0=pi*power(fW2,2)/3;
end % if

% dI;dA
dI0=IBS/2; dA0=ABS/2;


% hmax we need to guess where starts stop FP
[~,idx]=min(abs(HISTO1D_A-HAmax/2)); idx=idx(1,1);
if idx==idxma idx=idxma+1; end
AFP_std=edgesA(idx,1)+ABS/2-AFP0;
[~,idxATH]=min(abs(edgesA+ABS/2-(AFP0+6*AFP_std)));

[~,idx]=min(abs(HISTO1D_I-HImax)); idx=idx(1,1);
if idx==idxma idx=idxma+1; end
IFP_std=edgesI(idx,1)+IBS/2-IFP0;
[~,idxITH]=min(abs(edgesI+IBS/2-(IFP0+6*IFP_std)));

data=HISTO2D_IA(idxITH:end,idxATH:end);
data=data(:);
logiidx=data>0;
data=data(logiidx,1);
[NN,~]=size(data);
if NN>0
  hmax0=quantile(data(:),0.85);
else
  hmax0=max(HISTO2D_IA(:))/2;
end % if

% IMAXI
CDFI=cumsum(HISTO1D_I(idxITH:end))/sum(HISTO1D_I(idxITH:end));
[~,idx]=min(abs(CDFI-0.99)); idx=idx(1,1);
if nargin<3
  IMAXI0=edgesI(idx,1)+IBS/2;
end % if

% C0
ATP0=sum(edgesA(idxATH:end).*HISTO1D_A(idxATH:end))/sum(HISTO1D_A);
ITP0=sum(edgesI(idxITH:end).*HISTO1D_I(idxITH:end))/sum(HISTO1D_I);
if nargin<3
  C0=(ATP0-3*AFP0/2)*(ITP0-3*IFP0/2);
end % if

if nargin<3
  IFP0=0;
  AFP0=0;
end % if

% ***************************
% *** process all bunches ***
% ***************************

LW0=6;

hf=figure;
ax=subplot(1,1,1);

[NptsI,~]=size(edgesI);
[NptsA,~]=size(edgesA);

IMAXI_list=zeros(Nim,1);
AMAXI_list=zeros(Nim,1);
AFP_list=zeros(Nim,1);
IFP_list=zeros(Nim,1);
C_list=zeros(Nim,1);

fprintf('***     actions :               ---   buttons :\n')
fprintf('move                 up/down    ---   up   /   down\n')
fprintf('move               left/right   ---   left / right\n')
fprintf('Int. max       : higher/lower   ---   i    /   o\n')
fprintf('Area max       : higher/lower   ---   a    /   z\n')
fprintf('sharpness      : higher/lower   ---   s    /   d\n')
fprintf('contrast       : higher/lower   ---   c    /   v\n')
fprintf('displacement   : smaller/bigger ---   r    /   t\n')
fprintf('line thickness : smaller/bigger ---   l    /   m\n');
fprintf('\n')
fprintf('press q to save and quit...\n')
fprintf('\n')

for g=1:Ngroup

  H2D=zeros(NptsA,NptsI);
  for b=1:Nbunch
    im=(im_start-1)+(g-1)*Nbunch+b;
    load(cat(2,ana_path,'CLEANCELLDATA/',num2str(im,'%05d'),'/HISTO2D.mat'));
    H2D=H2D+HISTO2D;
  end % for b

  imagesc(ax,'XData',edgesI,'YData',edgesA,'CData',H2D); colormap(ax,hot); colorbar(ax); axis(ax,[0 IMAXI0 0 AMAXI0]);
  xlabel(ax,'Intensity (U.A.)','FontSize',FS,'FontWeight','Bold');
  ylabel(ax,'Nucleus Area (\mu m^2)','FontSize',FS,'FontWeight','Bold');
  [IMAXI,AMAXI,AFP,IFP,C,dI,dA,hmax,LW]=display_and_move_FPbounds_V3(ax,hmax0,dI0,dA0,IMAXI0,AMAXI0,IFP0,AFP0,C0,LW0);
  IMAXI0=IMAXI;
  AMAXI0=AMAXI;
  AFP0=AFP;
  IFP0=IFP;
  C0=C;
  dI0=dI;
  dA0=dA;
  hmax0=hmax;
  LW0=LW;

  for b=1:Nbunch
    im=(im_start-1)+(g-1)*Nbunch+b;
    IMAXI_list(im,1)=IMAXI;
    AMAXI_list(im,1)=AMAXI;
    AFP_list(im,1)=AFP;
    IFP_list(im,1)=IFP;
    C_list(im,1)=C;
  end % for b

end % for g

% ***************************
% *** process rest ***
% ***************************
H2D=zeros(NptsA,NptsI);
for r=1:Nrest
  im=(im_start-1)+Ngroup*Nbunch+r;
  load(cat(2,ana_path,'CLEANCELLDATA/',num2str(im,'%05d'),'/HISTO2D.mat'));
  H2D=H2D+HISTO2D;
end % for r

imagesc(ax,'XData',edgesI,'YData',edgesA,'CData',H2D); colormap(ax,hot); colorbar(ax); axis(ax,[0 IMAXI0 0 AMAXI0]);
xlabel(ax,'Intensity (U.A.)','FontSize',FS,'FontWeight','Bold');
ylabel(ax,'Nucleus Area (\mu m^2)','FontSize',FS,'FontWeight','Bold');
[IMAXI,AMAXI,AFP,IFP,C,dI,dA,hmax,LW]=display_and_move_FPbounds_V3(ax,hmax0,dI0,dA0,IMAXI0,AMAXI0,IFP0,AFP0,C0,LW0);
IMAXI0=IMAXI;
AMAXI0=AMAXI;
AFP0=AFP;
IFP0=IFP;
C0=C;
dI0=dI;
dA0=dA;
hmax0=hmax;
LW0=LW;

for r=1:Nrest
  im=(im_start-1)+Ngroup*Nbunch+r;
  IMAXI_list(im,1)=IMAXI;
  AMAXI_list(im,1)=AMAXI;
  AFP_list(im,1)=AFP;
  IFP_list(im,1)=IFP;
  C_list(im,1)=C;
end % for r

close(hf);

end % function
