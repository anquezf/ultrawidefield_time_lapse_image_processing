function run_NUCsignal_multiple_FLUO_V3(chanFluo,NBMAX_str)


warning off

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** *********************************** ***\n');
fprintf('*** MULTIPLE processing of nuclear Fluo ***\n');
fprintf('*** *********************************** ***\n');
fprintf('\n');

% ********************************************
% *** get  current ana_path_list and NBmax ***
% ********************************************

run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if
load(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe');

[Nexpe,~]=size(ana_path_list);
for expe=1:Nexpe
  ana_path=ana_path_list{expe,1};
  [~,Nchar]=size(ana_path);
  if ~(strcmp(ana_path(1,Nchar),'/'))
    ana_path=cat(2,ana_path,'/');
  end % if
  ana_path_list{expe,1}=ana_path;
  fprintf(cat(2,ana_path,'\n'));
end % for exp
fprintf('\n');

% *******************************************************************************************************************************************************************

% *****************************
% *** PROCESS multiple Fluo ***
% *****************************
NBMAX=str2double(NBMAX_str);
fprintf('\n\n')
POOLOBJ=parpool('local',NBMAX,'IdleTimeout',560);
fprintf('\n\n')


for expe=1:Nexpe

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'* process FLUO NUC - ',chanFluo,' - experiment %d : ',ana_path,'\n'),expe);

  % *************************

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- Fluo Analysis ');
  fprintf(fid,chanFluo);
  fprintf(fid,' - extract NUC Signal : ');
  tstart=now;
  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fclose(fid);



  % ***********************************
  % *** process Fluo NUC for each frame
  % ***********************************

  fprintf('RUN Nuclear FLUO procesing ... \n');

  fluo_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/');

  Nim=0; im_start=0; im_stop=0; Npos=0;
  load(cat(2,ana_path,'Nim.mat'));
  load(cat(2,ana_path,'Npos.mat'));
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');

  NL=0; NC=0;
  load(cat(2,ana_path,'NL.mat'));
  load(cat(2,ana_path,'NC.mat'));
  imoffset=zeros(NL,NC);
  load(cat(2,ana_path,'imoffset.mat'));

  flipUD=0; flipLR=0;
  load(cat(2,ana_path,'flipUD.mat'),'flipUD');
  load(cat(2,ana_path,'flipLR.mat'),'flipLR');

  FF_bkg=zeros(NL,NC); FF_foreg=zeros(NL,NC); b0=0; delta_b_vsim=zeros(1,Nim);
  fluo_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/');
  load(cat(2,fluo_ana_dir,'FF_bkg.mat'),'FF_bkg');
  load(cat(2,fluo_ana_dir,'FF_foreg.mat'),'FF_foreg');
  load(cat(2,fluo_ana_dir,'b0.mat'),'b0');
  load(cat(2,fluo_ana_dir,'delta_b_vsim.mat'),'delta_b_vsim');

  num_cellID=0;
  load(cat(2,ana_path,'Fluo_Ana/','num_cellID.mat'),'num_cellID');

  %for im=im_start:im_stop
  parfor im=im_start:im_stop
    process_fluoNUC_V4(ana_path,chanFluo,NL,NC,imoffset,flipUD,flipLR,FF_bkg,FF_foreg,b0+delta_b_vsim(1,im),num_cellID,Npos,im);
  end % par for
  fprintf(' DONE ! \n')


  % **********************
  % *** combine all images
  % **********************

  fprintf('COMBINE Nuclear FLUO procesing ... ');

  INTEN_raw_VST=nan(num_cellID,Nim);
  INTEN_sub_VST=nan(num_cellID,Nim);
  INTEN_cor_VST=nan(num_cellID,Nim);
  INTEN_dns_VST=nan(num_cellID,Nim);
  BKG_raw_VST=nan(num_cellID,Nim);
  BKG_sub_VST=nan(num_cellID,Nim);
  BKG_cor_VST=nan(num_cellID,Nim);
  BKG_dns_VST=nan(num_cellID,Nim);
  AREA_VST=nan(num_cellID,Nim);
  TIMES=nan(num_cellID,Nim);

  for im=im_start:im_stop

    im_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/','images_infos/',num2str(im,'%0.5d'),'/');

    load(cat(2,im_ana_dir,'INTEN_raw_im.mat'),'INTEN_raw_im');
    load(cat(2,im_ana_dir,'INTEN_sub_im.mat'),'INTEN_sub_im');
    load(cat(2,im_ana_dir,'INTEN_cor_im.mat'),'INTEN_cor_im');
    load(cat(2,im_ana_dir,'INTEN_dns_im.mat'),'INTEN_dns_im');
    load(cat(2,im_ana_dir,'BKG_raw_im.mat'),'BKG_raw_im');
    load(cat(2,im_ana_dir,'BKG_sub_im.mat'),'BKG_sub_im');
    load(cat(2,im_ana_dir,'BKG_cor_im.mat'),'BKG_cor_im');
    load(cat(2,im_ana_dir,'BKG_dns_im.mat'),'BKG_dns_im');
    load(cat(2,im_ana_dir,'AREA_im.mat'),'AREA_im');
    load(cat(2,im_ana_dir,'TIMES_im.mat'),'TIMES_im');

    INTEN_raw_VST(:,im)=INTEN_raw_im;
    INTEN_sub_VST(:,im)=INTEN_sub_im;
    INTEN_cor_VST(:,im)=INTEN_cor_im;
    INTEN_dns_VST(:,im)=INTEN_dns_im;
    BKG_raw_VST(:,im)=BKG_raw_im;
    BKG_sub_VST(:,im)=BKG_sub_im;
    BKG_cor_VST(:,im)=BKG_cor_im;
    BKG_dns_VST(:,im)=BKG_dns_im;
    AREA_VST(:,im)=AREA_im;
    TIMES(:,im)=TIMES_im;

  end % for im
  fprintf(' DONE !\n')


  % *** save data
  % *************

  fluo_ana_dir=cat(2,ana_path,'Fluo_Ana/',chanFluo,'/');

  fprintf('SAVE data ... ');

  save(cat(2,fluo_ana_dir,'INTEN_raw_VST.mat'),'INTEN_raw_VST','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'INTEN_sub_VST.mat'),'INTEN_sub_VST','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'INTEN_cor_VST.mat'),'INTEN_cor_VST','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'INTEN_dns_VST.mat'),'INTEN_dns_VST','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'BKG_raw_VST.mat'),'BKG_raw_VST','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'BKG_sub_VST.mat'),'BKG_sub_VST','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'BKG_cor_VST.mat'),'BKG_cor_VST','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'BKG_dns_VST.mat'),'BKG_dns_VST','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'AREA_VST.mat'),'AREA_VST','-v7.3','-nocompression');
  save(cat(2,fluo_ana_dir,'TIMES.mat'),'TIMES','-v7.3','-nocompression');

  fprintf(' DONE !\n');

  % *************************

  % *** write log file
  % ******************

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- Fluo Analysis ');
  fprintf(fid,chanFluo);
  fprintf(fid,' - extract NUC Signal : ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for exp
fprintf(' DONE ! \n')

delete(POOLOBJ);

fprintf('\n\n\n We have pre-processed %5d experiments... GOODLUCK !\n',Nexpe);
delete(POOLOBJ);
fprintf('\n\n');

