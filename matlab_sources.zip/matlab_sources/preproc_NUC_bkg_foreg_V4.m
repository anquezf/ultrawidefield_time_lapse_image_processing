function preproc_NUC_bkg_foreg_V4(ana_path,pos)

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'fW1.mat'),'fW1');
load(cat(2,ana_path,'fW2.mat'),'fW2');
load(cat(2,ana_path,'Nsig.mat'),'Nsig');


% analysis infos (global)
% *** load analysis infos
% FFcor
load(cat(2,ana_path,'FF_NUC.mat'),'FF');
load(cat(2,ana_path,'imoffset.mat'),'imoffset');
load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');
% image sizing
load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');


[Cmesh,Lmesh]=meshgrid(1:NC,1:NL);
% image positionning
load(cat(2,ana_path,'pixsize.mat'),'pixsize');


pos_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/');
mask_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/MASK_NUC/');
mkdir(mask_ana_dir);
bkg_mask_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/MASK_NUC/bkg_masks/');
mkdir(bkg_mask_ana_dir);
foreg_mask_ana_dir=cat(2,ana_path,'DATA/',num2str(pos-1,'%0.5d'),'/MASK_NUC/foreg_masks/');
mkdir(foreg_mask_ana_dir);


% *** load position infos
load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');
load(cat(2,pos_ana_dir,'fileListN.mat'),'fileListN');

% load bkg pdf
load(cat(2,ana_path,'first_seg/','mu_all.mat'),'mu_all');
load(cat(2,ana_path,'first_seg/','sig_all.mat'),'sig_all');

theimage=zeros(NL,NC);

bkg_mask=zeros(NL,NC,'logical');
foreg_mask=zeros(NL,NC,'logical');

mask_ini_neighbhd=zeros(NL,NC);

Nreg=0;

for im=im_start:im_stop

  % *** find idx
  idx=imidx_2_lidx(im,1);

  % *** load raw data
  theimage=double(imread(fileListN{idx,1}));
  theimage=(theimage-imoffset)./FF;
  theimage=theimage-mu_all(1,im);

  % *** detect local maximas
  theimage_f=make_nuc_blur_V3(theimage,fW1,fW2);
  ITH=Nsig*sig_all(1,im);

  [bkg_mask,foreg_mask]=make_1st_foregbkgmask(theimage_f,theimage,NL,NC,Lmesh,Cmesh,ITH,2,fW2/pixsize);
 
  % save mask
  save(cat(2,bkg_mask_ana_dir,'mask_im',num2str(im,'%05d'),'.mat'),'bkg_mask','-v7.3','-nocompression');
  save(cat(2,foreg_mask_ana_dir,'mask_im',num2str(im,'%05d'),'.mat'),'foreg_mask','-v7.3','-nocompression');

end %for im

end % function
