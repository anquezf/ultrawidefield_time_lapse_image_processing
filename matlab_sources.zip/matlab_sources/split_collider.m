function [mask,Nreg_out]=split_collider(Nreg,MLC,BLC,L0,C0,Lc,Cc,NL,NC,searchSCALE)

mask=zeros(NL,NC,'uint16');


% ********************************
% *** find boundary from first point
% ********************************

[Lw,Cw]=walk_toward_boundary_V2(Lc,Cc,L0,C0,BLC);

% *****************************
% *** find boundary from others
% *****************************

% *** params
% ref vector
v1x=C0-Cc;
v1y=L0-Lc;
nv1=sqrt(power(v1x,2)+power(v1y,2));
% all vectors
v2x=BLC(:,2)-Cc;
v2y=BLC(:,1)-Lc;
nv2=sqrt(power(v2x,2)+power(v2y,2));
% all angles
thetas=acos((v1x*v2x+v1y*v2y)./(nv1*nv2));
% all distances to center
dists_sq=power(BLC(:,1)-Lc,2)+power(BLC(:,2)-Cc,2);

% *** for each angle int
% angle to turn
dtheta=2*pi/Nreg;
% boundary points idxs
[Nbound,~]=size(BLC);
idxs=[1:Nbound]';
if Nreg==2

  theta0=dtheta;
  theta_min=theta0-dtheta/(2*searchSCALE);
  theta_max=theta0+dtheta/(2*searchSCALE);
  % select boundary
  logiidx=(thetas>=theta_min)&(thetas<=theta_max);
  idxlist=idxs(logiidx,1);
  if ~isempty(idxlist)
    [~,ii]=min(dists_sq(idxlist,1));
    ii=ii(1,1);
    pidx=idxlist(ii,1);
    [Lw,Cw]=walk_toward_boundary_V2(L0,C0,BLC(pidx,1),BLC(pidx,2),BLC);
  end % if

else

  for r=2:Nreg
    % find bounds
    theta0=(r-1)*dtheta;
    theta_min=theta0-dtheta/(2*searchSCALE);
    theta_max=theta0+dtheta/(2*searchSCALE);
    % select boundary
    logiidx=(thetas>=theta_min)&(thetas<=theta_max);
    idxlist=idxs(logiidx,1);
    if ~isempty(idxlist)
      [~,ii]=min(dists_sq(idxlist,1));
      ii=ii(1,1);
      pidx=idxlist(ii,1);
      [Lwta,Cwta]=walk_toward_boundary_V2(Lc,Cc,BLC(pidx,1),BLC(pidx,2),BLC);
      Lw=cat(1,Lw,Lwta);
      Cw=cat(1,Cw,Cwta);
    end % if
  end % for r

end % if Nreg<3

% *************
% *** make mask
% *************
   
[Npix,~]=size(MLC);
for pix=1:Npix
  mask(MLC(pix,1),MLC(pix,2))=1;
end % for pix

[Npix,~]=size(Lw);
for pix=1:Npix
  mask(Lw(pix,1),Cw(pix,1))=0;
end % for pix

[mask,Nreg_out]=bwlabel(mask);

if (Nreg_out>Nreg)&(Nreg>0)
  toremove=Nreg_out-Nreg;
  for r=1:toremove

    Alist=zeros(Nreg_out,1);
    for c=1:Nreg_out
      logiidx=(mask==c);
      Alist(c,1)=sum(logiidx(:));
    end % for c
    [~,ii]=min(Alist); ii=ii(1,1);
    logiidx=(mask==ii);
    mask(logiidx)=0;
    [mask,Nreg_out]=bwlabel(mask);

  end % for toremove
end % if

%{
figure; plot(BLC(:,2),BLC(:,1));
hold on; plot(Cw,Lw,'.r');
axis equal;
%}

end % funciton



