function re_run_detect_mitosis(ana_path,new_mitoCONTRAST_TH_str,Lmax2_str,Nitemax_str)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

new_mitoCONTRAST_TH=str2double(new_mitoCONTRAST_TH_str);
save(cat(2,ana_path,'new_mitoCONTRAST_TH.mat'),'new_mitoCONTRAST_TH','-v7.3','-nocompression');

Nitemax=str2double(Nitemax_str);
Lmax2=str2double(Lmax2_str);


fprintf('* re-detect mitosis : \n');

% *****************
% *** load data ***
% *****************

fprintf('load data ...');

load(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata')
load(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF')
load(cat(2,ana_path,'combined_data/cellLINES.mat'),'cellLINES');


% *** find date
date_str=datestr(datetime('now'));
startIndex = regexp(date_str,'-');
[~,Nsi]=size(startIndex);
for nn=1:Nsi
  date_str(1,startIndex(1,nn))='_';
end % for nn
startIndex = regexp(date_str,' ');
date_str(1,startIndex(1,1))='_';
startIndex = regexp(date_str,':');
date_str(1,startIndex(1,1))='h';
date_str(1,startIndex(1,2))='m';

% *** backup olds
save(cat(2,ana_path,'combined_data/sorted_celldata_backup_rerun_mitosis_',date_str,'.mat'),'sorted_celldata','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellLINES_backup_rerun_mitosis_',date_str,'.mat'),'cellLINES','-v7.3','-nocompression');

sorted_cellCONTRAST=sorted_cellBF(:,6)./sorted_cellBF(:,8)+sorted_cellBF(:,4)./sorted_cellBF(:,8);

load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

fprintf('DONE !\n');






% **********************
% *** detect mitosis ***
% **********************

% cellLINES = [ mother_CID , daughter1_CID , daughter2_CID , im]

fprintf('detect mitosis for image %5d of %5d',0,Nim);
for im=(im_start+1):im_stop

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',im,Nim);

  [mothers_sisters,NMS]=detect_mitosis_V3(im,sorted_celldata,Lmax2,Nitemax,sorted_cellCONTRAST,new_mitoCONTRAST_TH);

  for ms=1:NMS
    idxm=mothers_sisters(ms,1);
    idxs=mothers_sisters(ms,2);
    m_CID=sorted_celldata(idxm,12);
    d2_CID=sorted_celldata(idxs,12);
    cellLINES=cat(1,cellLINES,[m_CID,m_CID,d2_CID,im]);
  end % for ms

end % for im
fprintf(' DONE !\n');

fprintf('remove too short mitosis events...');
load(cat(2,ana_path,'mito_miniD.mat'),'mito_miniD');
cellLINES_old=cellLINES;
cellLINES=clean_short_mitosis_events(cellLINES,mito_miniD,sorted_celldata,sorted_cellCONTRAST,im_start,im_stop);
fprintf(' DONE!\n');





% ******************************
% *** combine mitosis events ***
% ******************************

fprintf('combine mitosis for image %5d of %5d',0,Nim);
maxCID=max(sorted_celldata(:,12));

% backup old CID number
maxCID_old=maxCID;
% prepare intensity corrections
% to_correct_list=[cid_old,cid_new,im1]
to_correct_list=[];

[NCL,~]=size(cellLINES);
idxs=[1:NCL]';
for im=(im_start+1):im_stop

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',im,Nim);

  logiidx=cellLINES(:,4)==im;
  NN=sum(logiidx);
  if NN>0

    idxlist=idxs(logiidx,1);
    for ii=1:NN

      idx=idxlist(ii,1);

      m_CID=cellLINES(idx,1);
      d2_CID=cellLINES(idx,3);

      % create new CID for mother-daughter
      d1_CID=maxCID+1;
      ll1=(sorted_celldata(:,12)==m_CID)&(sorted_celldata(:,3)>(im-1));

      if sum(ll1)>0
      
        maxCID=maxCID+1;
        cellLINES(idx,2)=d1_CID;

        % correct sorted_celldata for frame>=im
        sorted_celldata(ll1,12)=d1_CID;

        im1=min(sorted_celldata(ll1,3));
        to_correct_list=cat(1,to_correct_list,[m_CID,d1_CID,im1]);

        % correct cellLINEs for next frames M
        ll=(cellLINES(:,1)==m_CID)&(cellLINES(:,4)>im);
        if sum(ll)>0 cellLINES(ll,1)=d1_CID; end%if
        % correct cellLINEs for next frames D1
        ll=(cellLINES(:,2)==m_CID)&(cellLINES(:,4)>im);
        if sum(ll)>0 cellLINES(ll,2)=d1_CID; end%if
        % correct cellLINEs for next frames D2
        ll=(cellLINES(:,3)==m_CID)&(cellLINES(:,4)>im);
        if sum(ll)>0 cellLINES(ll,3)=d1_CID; end%if

      end % if sum(ll1)>0

    end % for idx

  end % if NN>0

end % for im

save(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellLINES_old.mat'),'cellLINES_old','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/cellLINES.mat'),'cellLINES','-v7.3','-nocompression');

fprintf(' DONE!\n');




% ********************************
% *** correct Fluo Intensities ***
%*********************************

% search chanels
chanlist=utils_DIRList(cat(2,ana_path,'Fluo_Ana'));
[Nchan,~]=size(chanlist);

fprintf('correct Fluo NUC for chanel %5d of %5d',0,Nchan);

for chan=1:Nchan

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',chan,Nchan);


  % test wether it contains INTEN_xxx_VST data
  if  exist(cat(2,chanlist{chan,1},'INTEN_dns_VST.mat'))

    load(cat(2,chanlist{chan,1},'AREA_VST.mat'))
    load(cat(2,chanlist{chan,1},'BKG_cor_VST.mat'))
    load(cat(2,chanlist{chan,1},'BKG_dns_VST.mat'))
    load(cat(2,chanlist{chan,1},'BKG_raw_VST.mat'))
    load(cat(2,chanlist{chan,1},'BKG_sub_VST.mat'))
    load(cat(2,chanlist{chan,1},'INTEN_cor_VST.mat'))
    load(cat(2,chanlist{chan,1},'INTEN_dns_VST.mat'))
    load(cat(2,chanlist{chan,1},'INTEN_raw_VST.mat'))
    load(cat(2,chanlist{chan,1},'INTEN_sub_VST.mat'))

    save(cat(2,chanlist{chan,1},'AREA_VST_backup_rerun_mitosis_',date_str,'.mat'),'AREA_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'BKG_cor_VST_backup_rerun_mitosis_',date_str,'.mat'),'BKG_cor_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'BKG_dns_VST_backup_rerun_mitosis_',date_str,'.mat'),'BKG_dns_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'BKG_raw_VST_backup_rerun_mitosis_',date_str,'.mat'),'BKG_raw_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'BKG_sub_VST_backup_rerun_mitosis_',date_str,'.mat'),'BKG_sub_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'INTEN_cor_VST_backup_rerun_mitosis_',date_str,'.mat'),'INTEN_cor_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'INTEN_dns_VST_backup_rerun_mitosis_',date_str,'.mat'),'INTEN_dns_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'INTEN_raw_VST_backup_rerun_mitosis_',date_str,'.mat'),'INTEN_raw_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'INTEN_sub_VST_backup_rerun_mitosis_',date_str,'.mat'),'INTEN_sub_VST','-v7.3','-nocompression');

    AREA_VST=cat(1,AREA_VST,nan(maxCID-maxCID_old,Nim));
    BKG_cor_VST=cat(1,BKG_cor_VST,nan(maxCID-maxCID_old,Nim));
    BKG_dns_VST=cat(1,BKG_dns_VST,nan(maxCID-maxCID_old,Nim));
    BKG_raw_VST=cat(1,BKG_raw_VST,nan(maxCID-maxCID_old,Nim));
    BKG_sub_VST=cat(1,BKG_sub_VST,nan(maxCID-maxCID_old,Nim));
    INTEN_cor_VST=cat(1,INTEN_cor_VST,nan(maxCID-maxCID_old,Nim));
    INTEN_dns_VST=cat(1,INTEN_dns_VST,nan(maxCID-maxCID_old,Nim));
    INTEN_raw_VST=cat(1,INTEN_raw_VST,nan(maxCID-maxCID_old,Nim));
    INTEN_sub_VST=cat(1,INTEN_sub_VST,nan(maxCID-maxCID_old,Nim));

    % to_correct_list=[cid_old,cid_new,im1]
    [Ntocor,~]=size(to_correct_list);

    for c=1:Ntocor

      old_cid=to_correct_list(c,1);
      new_cid=to_correct_list(c,2);
      im1=to_correct_list(c,3);

      AREA_VST(new_cid,im1:Nim)=AREA_VST(old_cid,im1:Nim);
      AREA_VST(old_cid,im1:Nim)=nan;
      BKG_cor_VST(new_cid,im1:Nim)=BKG_cor_VST(old_cid,im1:Nim);
      BKG_cor_VST(old_cid,im1:Nim)=nan;
      BKG_dns_VST(new_cid,im1:Nim)=BKG_dns_VST(old_cid,im1:Nim);
      BKG_dns_VST(old_cid,im1:Nim)=nan;
      BKG_raw_VST(new_cid,im1:Nim)=BKG_raw_VST(old_cid,im1:Nim);
      BKG_raw_VST(old_cid,im1:Nim)=nan;
      BKG_sub_VST(new_cid,im1:Nim)=BKG_sub_VST(old_cid,im1:Nim);
      BKG_sub_VST(old_cid,im1:Nim)=nan;
      INTEN_cor_VST(new_cid,im1:Nim)=INTEN_cor_VST(old_cid,im1:Nim);
      INTEN_cor_VST(old_cid,im1:Nim)=nan;
      INTEN_dns_VST(new_cid,im1:Nim)=INTEN_dns_VST(old_cid,im1:Nim);
      INTEN_dns_VST(old_cid,im1:Nim)=nan;
      INTEN_raw_VST(new_cid,im1:Nim)=INTEN_raw_VST(old_cid,im1:Nim);
      INTEN_raw_VST(old_cid,im1:Nim)=nan;
      INTEN_sub_VST(new_cid,im1:Nim)=INTEN_sub_VST(old_cid,im1:Nim);
      INTEN_sub_VST(old_cid,im1:Nim)=nan;

    end % for c

    save(cat(2,chanlist{chan,1},'AREA_VST.mat'),'AREA_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'BKG_cor_VST.mat'),'BKG_cor_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'BKG_dns_VST.mat'),'BKG_dns_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'BKG_raw_VST.mat'),'BKG_raw_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'BKG_sub_VST.mat'),'BKG_sub_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'INTEN_cor_VST.mat'),'INTEN_cor_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'INTEN_dns_VST.mat'),'INTEN_dns_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'INTEN_raw_VST.mat'),'INTEN_raw_VST','-v7.3','-nocompression');
    save(cat(2,chanlist{chan,1},'INTEN_sub_VST.mat'),'INTEN_sub_VST','-v7.3','-nocompression');

  end % if exist ....

end % for chan

fprintf(' DONE!\n');

end % function
