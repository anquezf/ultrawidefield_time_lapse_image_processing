function run_repair_oversplit_V5(ana_path,dpix_tol_str,mitoCONTRAST_TH1_str,deepTH_repairSPLIT_str,NBMAX_str)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

fprintf('* repairing of oversplitting : \n');

% ***
% *** load data

fprintf('load data ...');

NBMAX=str2double(NBMAX_str);
dpix_tol=str2double(dpix_tol_str);
deepTH_repairSPLIT=str2double(deepTH_repairSPLIT_str);
mitoCONTRAST_TH1=str2double(mitoCONTRAST_TH1_str);

save(cat(2,ana_path,'dpix_tol.mat'),'dpix_tol','-v7.3','-nocompression');
save(cat(2,ana_path,'deepTH_repairSPLIT.mat'),'deepTH_repairSPLIT','-v7.3','-nocompression');
save(cat(2,ana_path,'mitoCONTRAST_TH1.mat'),'mitoCONTRAST_TH1','-v7.3','-nocompression');

load(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata')
load(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC')
load(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC')
load(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF')

load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');
load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

load(cat(2,ana_path,'tracking/Nitemax.mat'),'Nitemax');
load(cat(2,ana_path,'tracking/Lmax.mat'),'Lmax');

fprintf('DONE !\n');

idxlist_modif=[];
cellMLC_modif={};
cellBLC_modif={};
cellID_modif=[];
idxlist_rmvd=[];



% ***
% *** detect oversplitting

fprintf('detect oversplitting for image %5d of %5d',0,Nim-1);
for im=(im_start+1):(im_stop-1)

    % *** display status...
  for id=1:14
  fprintf('\b');
  end % for id
  fprintf('%5d of %5d',im,Nim-1);

 [idxlist_modif_t,cellMLC_modif_t,cellBLC_modif_t,cellID_modif_t,idxlist_rmvd_t]=repair_oversplit_V2(im,sorted_celldata,sorted_cellboundLC,sorted_cellBF,sorted_cellmaskLC,Lmax,Nitemax,dpix_tol,mitoCONTRAST_TH1,deepTH_repairSPLIT,NL,NC);
  sorted_celldata(idxlist_modif_t,12)=cellID_modif_t;
  idxlist_modif=cat(1,idxlist_modif,idxlist_modif_t);
  cellMLC_modif=cat(1,cellMLC_modif,cellMLC_modif_t);
  cellBLC_modif=cat(1,cellBLC_modif,cellBLC_modif_t);
  cellID_modif=cat(1,cellID_modif,cellID_modif_t);
  idxlist_rmvd=cat(1,idxlist_rmvd,idxlist_rmvd_t);

end % for im
fprintf(' DONE !\n');



% ***
% *** repair celldata

[Nmodif,~]=size(idxlist_modif);
fprintf('---> Detected %d oversplited cells\n',Nmodif);

POOLOBJ=parpool('local',NBMAX,'IdleTimeout',120);

new_scd_list=zeros(Nmodif,12);
NL=NL; % this is there for NL and NC to exist
NC=NC;
fprintf('* repair cell data ...\n')
parfor modi=1:Nmodif
  idx=idxlist_modif(modi,1);
  new_scd=repair_cellFEAT_V10(ana_path,sorted_celldata(idx,:),cellMLC_modif{modi,1},NL,NC);
  new_scd_list(modi,:)=new_scd;
end % par for
fprintf(' DONE !\n');

for modi=1:Nmodif
  idx=idxlist_modif(modi,1);
  sorted_celldata(idx,:)=new_scd_list(modi,:);
  sorted_celldata(idx,12)=cellID_modif(modi,1);
  sorted_cellmaskLC{idx,1}=cellMLC_modif{modi,1};
  sorted_cellboundLC{idx,1}=cellBLC_modif{modi,1};
end % for modi

% ***
% *** repair cellBF

fprintf('* repair cell BF ...\n')
new_BF_list=zeros(Nmodif,8);
parfor modi=1:Nmodif
  idx=idxlist_modif(modi,1);
  newBF=repair_cellBF_V3(ana_path,sorted_celldata,idx,idxlist_rmvd);
  new_BF_list(modi,:)=newBF;
end % par for
fprintf(' DONE !\n');

for modi=1:Nmodif
  idx=idxlist_modif(modi,1);
  sorted_cellBF(idx,:)=new_BF_list(modi,:);
end % for modi



delete(POOLOBJ);
fprintf('* save data ...\n')
% ***
% ***  remove cells

sorted_celldata(idxlist_rmvd,:)=[];
sorted_cellmaskLC(idxlist_rmvd,:)=[];
sorted_cellboundLC(idxlist_rmvd,:)=[];
sorted_cellBF(idxlist_rmvd,:)=[];



% ***
% *** repair cellBF time series
%  we do not use stdBF nor meanBF ...
%  so we do not repair it...

save(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF','-v7.3','-nocompression');

fprintf('DONE !\n');

end % function


