function cost=build_cost_V4(data1,data2,Lmax,useWB,useWS,WBSweight)

Lmax_sq=power(Lmax,2);

[N1,~]=size(data1);
[N2,~]=size(data2);
n1=[1:N1]';
n2=[1:N2];

cost=zeros(N1+1,N2+1,'single');
X1=zeros(N1,N2,'single');
Y1=zeros(N1,N2,'single');
X2=zeros(N1,N2,'single');
Y2=zeros(N1,N2,'single');

% last column and last line are dummy particles

X1=repmat(data1(n1,1),1,N2);
Y1=repmat(data1(n1,2),1,N2);
X2=repmat(data2(n2,1)',N1,1);
Y2=repmat(data2(n2,2)',N1,1);
cost(1:N1,1:N2)=power(X1-X2,2)+power(Y1-Y2,2);


% build data in case of useWB
if useWB>0
  % WB is 8th column !!
  X1=repmat(data1(n1,8),1,N2);
  X2=repmat(data2(n2,8)',N1,1);
  cost(1:N1,1:N2)=cost(1:N1,1:N2)+WBSweight*power(X1-X2,2);
end % if


% build data in case of useWB
if useWS>0
  % WS is 9th column !!
  X1=repmat(data1(n1,9),1,N2);
  X2=repmat(data2(n2,9)',N1,1);
  cost(1:N1,1:N2)=cost(1:N1,1:N2)+WBSweight*power(X1-X2,2);
end % if


% for dummies
% disappearing particle
cost(:,N2+1)=Lmax_sq;
% appearing particle
cost(N1+1,:)=Lmax_sq;
% dummy to dummy
cost(N1+1,N2+1)=Lmax_sq;

end % function
