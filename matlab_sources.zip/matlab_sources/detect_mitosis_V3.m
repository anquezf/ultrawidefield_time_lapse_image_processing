function [mothers_sisters,NMS]=detect_mitosis_V3(im,sorted_celldata,Lmax,Nitemax,sorted_cellCONTRAST,mitoCONTRAST_TH1)


% *** params
Lmax_sq=power(Lmax,2);


% *** raw data

[Ncell,~]=size(sorted_celldata);
idxs=[1:Ncell]';

logiidx_cur=sorted_celldata(:,3)==im;
logiidx_prev=sorted_celldata(:,3)==(im-1);

cur_scd=sorted_celldata(logiidx_cur,:);
prev_scd=sorted_celldata(logiidx_prev,:);

idxlist_cur=idxs(logiidx_cur,1);
idxlist_prev=idxs(logiidx_prev,1);



% ***********************
% *** find single_sisters
% exists at frame im
% but not at im-1
ss_scd_cand=[];
ss_cand_idxlist=[];
% *** find mother_sisters
% exists at frame im
% and also at im-1
ms_scd_cand=[];
ms_cand_idxlist=[];

[NN,~]=size(cur_scd);
for c=1:NN
  ID=cur_scd(c,12);
  logiidx=(prev_scd(:,12)==ID);
  if sum(logiidx)==0
    ss_scd_cand=cat(1,ss_scd_cand,cur_scd(c,:));
    ss_cand_idxlist=cat(1,ss_cand_idxlist,idxlist_cur(c,1));
  else
    ms_scd_cand=cat(1,ms_scd_cand,cur_scd(c,:));
    ms_cand_idxlist=cat(1,ms_cand_idxlist,idxlist_cur(c,1));
  end % if
end % for c



% ***********************************
% *** attribute mothers-sisters pairs

[Nss,~]=size(ss_scd_cand);
[Nms,~]=size(ms_scd_cand);

% LINKAGE :
cost=build_cost_sisters(single(ss_scd_cand),single(ms_scd_cand),single(Lmax),Nss,Nms);
attrib=seed_attrib_sisters(cost,single(Lmax),Nss);
[attrib,nit]=linkage_V10(cost,attrib,single(Lmax),Nitemax);

mothers_sisters=[];
sisters1=[];
sisters2=[];

% COMBINE :
ss_catched=[];
ss_lost=[];
N1=Nss+Nms;
N2=Nss+Nms;
% single sisters
for p=1:Nss
  if isempty(find(ss_catched==p))

    [L,~]=find(attrib(:,p)==single(1));
    if L==(N1+1)
      ss_lost=cat(1,ss_lost,ss_cand_idxlist(p,1));
    elseif (L>Nss)&&(L<(N1+1))
      motherIDX=ms_cand_idxlist(L-Nss,1);
      sisterIDX=ss_cand_idxlist(p,1);
      mothers_sisters=cat(1,mothers_sisters,[motherIDX,sisterIDX]);
      ss_catched=cat(1,ss_catched,p);
    elseif (L<(Nss+1))
      if isempty(find(ss_catched==L))
        sisters1=cat(1,sisters1,ss_cand_idxlist(p,:));
        sisters2=cat(1,sisters2,ss_cand_idxlist(L,:));
        ss_catched=cat(1,ss_catched,p,L);
      end % if isempty(ss_catched==L)
    end % if L==(N1+1)

  end % if isempty(ss_catched==p)
end % for p
% mother sisters
for p=(Nss+1):N1
    [L,~]=find(attrib(:,p)==single(1));
    if L<(Nss+1)&&(isempty(find(ss_catched==L)))
      motherIDX=ms_cand_idxlist(p-Nss,1);
      sisterCID=ss_cand_idxlist(L,1);
      mothers_sisters=cat(1,mothers_sisters,[motherIDX,sisterIDX]);
      ss_catched=cat(1,ss_catched,L);
    end % if L<(Nss+1)
end % for p

[NMS,~]=size(mothers_sisters);

% ***********************
% *** check mitotic cells

% criteria :
% if M+D > 0.03
%  mito
%if D<0.03
%  if M>0.09
%  mito

ismitotic=zeros(NMS,1);

for ms=1:NMS

  idx1=mothers_sisters(ms,1);
  idx2=mothers_sisters(ms,2);

  % *** is it mitotic ?

  % BF contrast of mother at im
  CBF_d1=sorted_cellCONTRAST(idx1,1);
  % BF contrast of mother at im-1
  CID1=sorted_celldata(idx1,12);
  lo_1=prev_scd(:,12)==CID1;
  idx1p=idxlist_prev(lo_1,1);
  CBF_m=sorted_cellCONTRAST(idx1p,1);
  % BF contrast of sister
  CBF_d2=sorted_cellCONTRAST(idx2,1);

  % compute criteria
  if (CBF_d1>mitoCONTRAST_TH1)|(CBF_m>mitoCONTRAST_TH1)|(CBF_d2>mitoCONTRAST_TH1)
    ismitotic(ms,1)=1;
  end % if

end % for ms



% ****************************
% *** mitotic cells

logiidx=(ismitotic==1);
mothers_sisters=mothers_sisters(logiidx,:);
[NMS,~]=size(mothers_sisters);





end % function


