function run_avgBKGFOREG_multiple_preprocessing_V5(NBMAX_str)

warning off


% ********************************************
% *** get  current ana_path_list and NBmax ***
% ********************************************

run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if
load(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe');




% ******************************
% *** some usefull variables ***
% ******************************
NBMAX=str2double(NBMAX_str);
POOLOBJ=parpool('local',NBMAX,'IdleTimeout',360);

% 1st FF smoothing : NL,NC
ana_path=ana_path_list{1,1};

load(cat(2,ana_path,'NL.mat'),'NL');
load(cat(2,ana_path,'NC.mat'),'NC');

% mesh grid
[Cmesh,Lmesh]=meshgrid([1:NC],[1:NL]);
padded_image=zeros(3*NL,3*NC);


% ***************************************************************
% *** 1st SEGMENTATION : HISTO, image processing of bkg/foreg ***
% ***************************************************************

fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ****************************************** ***\n');
fprintf('*** MULTIPLE PRE-PROCESSING BKG/FOREG Averages ***\n');
fprintf('*** ****************************************** ***\n');
fprintf('\n');


for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* 1st segmentation - experiment %d : ',ana_path,'\n'),expe);

  % *** load params
  % ***************
  load(cat(2,ana_path,'deltai.mat'),'deltai');
  load(cat(2,ana_path,'imaxi.mat'),'imaxi');
  load(cat(2,ana_path,'imini.mat'),'imini');
  load(cat(2,ana_path,'iedges.mat'),'iedges');

  load(cat(2,ana_path,'Nsig.mat'),'Nsig');

  load(cat(2,ana_path,'fW1.mat'),'fW1');
  load(cat(2,ana_path,'fW2.mat'),'fW2');

  load(cat(2,ana_path,'pad_dpix.mat'),'pad_dpix');
  load(cat(2,ana_path,'fWFF.mat'),'fWFF');
  load(cat(2,ana_path,'FFmini.mat'),'FFmini');

  load(cat(2,ana_path,'pixsize.mat'));

  fWFF_pix=fWFF/pixsize;
  [Npts,~]=size(iedges);


  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'Nim.mat'),'Nim');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');


  % *************************

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- pre-processing bkg/foreg averages : ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fclose(fid);

  % *************************

  % *** HISTO
  % *********

  % *** write log file
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'pre_proc_HISTO_V8 (');
  fprintf(fid,'deltai = ');
  fprintf(fid,num2str(deltai));
  fprintf(fid,';');
  fprintf(fid,'imini = ');
  fprintf(fid,num2str(imini));
  fprintf(fid,';');
  fprintf(fid,'imaxi = ');
  fprintf(fid,num2str(imaxi));
  fprintf(fid,';');
  fprintf(fid,'Nsig = ');
  fprintf(fid,num2str(Nsig));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** RUN histo pre_proc
  fprintf('RUN pre-processing of histograms...')
  parfor pos=1:Npos
    pre_proc_HISTO_V8(ana_path,pos);
  end % for pos
  fprintf(' DONE ! \n')

  % *** COMBINE
  histo_all=zeros(Npts,Nim);
  fprintf('COMBINE histograms from position ...');
  for p=0:(Npos-1)
    pos_ana_dir=cat(2,ana_path,'DATA/',num2str(p,'%0.5d'),'/');
    load(cat(2,pos_ana_dir,'histo.mat'),'histo')
    histo_all=histo_all+histo;
  end % for p
  fprintf('DONE ! \n');

  % *** global mean and std per image
  mu_all=zeros(1,Nim);
  mu_foreg_all=zeros(1,Nim);
  sig_all=zeros(1,Nim);
  A0=0;
  fprintf('ESTIMATE mu and sig for image ...');
  for im=im_start:im_stop
    % pdf
    n=histo_all(:,im);
    % mean/mode
    [A0,idxm]=max(n); idxm=idxm(1,1);
    mu0=iedges(idxm,1);
    % find std : 2*std at A0*0.1353 std at A0*0.6065
    [~,idxl]=min(abs(n(1:idxm,1)-0.6065*A0)); idxl=idxl(1,1);
    sig0=abs(max(mu0-iedges(idxl,1)));
    mu_all(1,im)=mu0;
    sig_all(1,im)=sig0;
    % *** get foreground mean
    ITH=mu0+Nsig*sig0;
    logiidx=iedges>ITH;
    mu0_foreg=sum(iedges(logiidx,1).*histo_all(logiidx,im))/sum(histo_all(logiidx,im));
    mu_foreg_all(1,im)=mu0_foreg;
  end % for im
  fprintf(' DONE ! \n');
  save_dir=cat(2,ana_path,'first_seg/');
  mkdir(save_dir);
  save(cat(2,save_dir,'histo_all.mat'),'histo_all','-v7.3','-nocompression');
  save(cat(2,save_dir,'mu_all.mat'),'mu_all','-v7.3','-nocompression');
  save(cat(2,save_dir,'mu_foreg_all.mat'),'mu_foreg_all','-v7.3','-nocompression');
  save(cat(2,save_dir,'sig_all.mat'),'sig_all','-v7.3','-nocompression');



  % *************************

  % *** 1st CELL SEG
  % ****************

  % *** write log file
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'preproc_NUC_bkg_foreg_V4 (');
  fprintf(fid,'fW1 = ');
  fprintf(fid,num2str(fW1));
  fprintf(fid,';');
  fprintf(fid,'fW2 = ');
  fprintf(fid,num2str(fW2));
  fprintf(fid,';');
  fprintf(fid,'Nsig = ');
  fprintf(fid,num2str(Nsig));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** pre-processing
  fprintf('RUN pre-processing of BKG/FOREG...')
  parfor pos=1:Npos
    preproc_NUC_bkg_foreg_V4(ana_path,pos);
  end % parfor
  fprintf(' DONE !\n');

  % *** combine
  save_dir=cat(2,ana_path,'NUC_BKG_FOREG/');
  mkdir(save_dir);

  fprintf('combine BKG/FOREG for all positions ...')
  parfor im=im_start:im_stop
    combine_nuc_bkg_foreg_V2(ana_path,im);
  end % parfor
  fprintf(' DONE !\n');


  % *************************

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   -------------  pre-processing bkg/foreg averages ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for exp


fprintf('\n\n\n We have pre-processed %5d experiments... GOODLUCK !\n',Nexpe);
delete(POOLOBJ);
fprintf('\n\n');


end % funciton

