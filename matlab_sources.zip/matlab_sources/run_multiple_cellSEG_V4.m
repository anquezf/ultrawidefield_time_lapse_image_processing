function run_multiple_cellSEG_V4(save_dir,fWmf_str,scale_str,Nite_str,deepTH_SPLIT_str,Nloop_str,IBS_str,ABS_str,NBMAX_str)

warning off
FS=12;


run_path=pwd;
[~,Nchar]=size(run_path);
if ~(strcmp(run_path(1,Nchar),'/'))
  run_path=cat(2,run_path,'/');
end % if
load(cat(2,run_path,'run_vars/cur_ana_path_list.mat'),'ana_path_list','Nexpe');

[Nexpe,~]=size(ana_path_list);
for expe=1:Nexpe
  ana_path=ana_path_list{expe,1};
  [~,Nchar]=size(ana_path);
  if ~(strcmp(ana_path(1,Nchar),'/'))
    ana_path=cat(2,ana_path,'/');
  end % if
  ana_path_list{expe,1}=ana_path;
  fprintf(cat(2,ana_path,'\n'));
end % for exp


fprintf('\n');
fprintf('\n');
fprintf('\n');
fprintf('*** ************************** ***\n');
fprintf('*** MULTIPLE cell SEGMENTATION ***\n');
fprintf('*** ************************** ***\n');
fprintf('\n');



NBMAX=str2double(NBMAX_str);
POOLOBJ=parpool('local',NBMAX,'IdleTimeout',360);

fprintf('\n')


% ************************************************************************************************************************************************


fWmf=str2double(fWmf_str);
scale=str2double(scale_str);
Nite=str2double(Nite_str);
deepTH_SPLIT=str2double(deepTH_SPLIT_str);
Nloop=str2double(Nloop_str);


IBS=str2double(IBS_str);
ABS=str2double(ABS_str);




fprintf('\n\n')

fprintf('*** process cell SEGMENTATION  \n');


for expe=1:Nexpe

  tstart=now;

  ana_path=ana_path_list{expe,1};
  fprintf(cat(2,'\n* cell SEG - experiment %d : ',ana_path,'\n\n'),expe);

  load(cat(2,ana_path,'Npos.mat'),'Npos');
  load(cat(2,ana_path,'im_start.mat'),'im_start');
  load(cat(2,ana_path,'im_stop.mat'),'im_stop');


  save(cat(2,ana_path,'fWmf.mat'),'fWmf','-v7.3','-nocompression');
  save(cat(2,ana_path,'scale.mat'),'scale','-v7.3','-nocompression');
  save(cat(2,ana_path,'Nite.mat'),'Nite','-v7.3','-nocompression');
  save(cat(2,ana_path,'deepTH_SPLIT.mat'),'deepTH_SPLIT','-v7.3','-nocompression');
  save(cat(2,ana_path,'Nloop.mat'),'Nloop','-v7.3','-nocompression');



  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' START ------------- cell SEGMENTATION : ');

  fprintf(fid,datestr(tstart));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'* Analyzed with :\n');
  for ee=1:Nexpe
    fprintf(fid,ana_path_list{ee,1});
    fprintf(fid,'\n');
  end % for ee
  fprintf(fid,'\n');
  fclose(fid);

  % *** write log file

  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'pre_proc_cellFEAT23 (');
  fprintf(fid,'fWmf = ');
  fprintf(fid,num2str(fWmf));
  fprintf(fid,';');
  fprintf(fid,'scale = ');
  fprintf(fid,num2str(scale));
  fprintf(fid,';');
  fprintf(fid,'Nite = ');
  fprintf(fid,num2str(Nite));
  fprintf(fid,';');
  fprintf(fid,'deepTH_SPLIT = ');
  fprintf(fid,num2str(deepTH_SPLIT));
  fprintf(fid,';');
  fprintf(fid,'Nloop = ');
  fprintf(fid,num2str(Nloop));
  fprintf(fid,') : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);


  % *** PROCESS
  % ***********

  % *** write log file
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'pre_proc_cellFEAT_V23 : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** run
  fprintf('COMPUTE cell SEG ...');
  parfor pos=1:Npos
      pre_proc_cellFEAT_V23(ana_path,pos);
  end % parfor pos
  fprintf(' DONE ! \n');


  % *** COMBINE
  % ***********

  % *** write log file
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'combine_raw_data_V2 : ');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** run
  fprintf('COMBINING cell SEG ...');
  combine_raw_data_V2(ana_path)
  fprintf(' DONE !\n')

  % *** CLEANCELLDATA
  % **********************

  % *** write log file
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,'init_clean_celldata_V3 ( ');
  fprintf(fid,num2str(IBS));
  fprintf(fid,';');
  fprintf(fid,num2str(ABS));
  fprintf(fid,') :');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,'\n');
  fclose(fid);

  % *** run
  fprintf('INTIALIZING cleaning of celldata...');
  init_clean_celldata_V3(ana_path,IBS,ABS);
  fprintf(' DONE !\n');

  fprintf('BUILD Intensity vs Area histograms ...')
  parfor im=im_start:im_stop
    build_shape_param_histos(ana_path,im);
  end % for im
  fprintf(' DONE !\n')
  combine_build_shape_param_histos(ana_path);

  % *** write log file
  % ******************
  fid = fopen(cat(2,ana_path,'what_was_done.log'), 'at' );
  fprintf(fid,' END   ------------- cell SEGMENTATION ');
  fprintf(fid,datestr(tstart));
  fprintf(fid,'->');
  t=now;
  fprintf(fid,datestr(t));
  fprintf(fid,' --- \n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fprintf(fid,'\n');
  fclose(fid);

end % for expe




fprintf('\n\n\n We have pre-processed %5d experiments... GOODLUCK !\n',Nexpe);
delete(POOLOBJ);
fprintf('\n\n');

end % function


