function run_finish_tracking_V2(ana_path,Lmax2_str,NBMAX_str)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

load(cat(2,ana_path,'Nim.mat'));
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');


NBMAX=str2double(NBMAX_str);
Lmax2=str2double(Lmax2_str);

save(cat(2,ana_path,'tracking/','Lmax2.mat'),'Lmax2','-v7.3','-nocompression');


% *** load data
% ****************

fprintf('* load data ...')
load(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata');
celldata_FT=sorted_celldata(:,1:11);
clear sorted_celldata;
fprintf(' DONE ! \n')


fprintf('* init tracking ...')
% *** init tracking ***
% *********************

% save inputs
ROtrack_dir=cat(2,ana_path,'tracking/');

[Ncell,~]=size(celldata_FT);
idxs=[1:Ncell]';

im_p=im_stop;
logiidx_p=(celldata_FT(:,3)==im_p);
Np=sum(logiidx_p(:));
short_celldata_p=zeros(Np,11,'single');
idxlist_p=zeros(Np,1);
idxlist_p=idxs(logiidx_p,1);
short_celldata_p=single(celldata_FT(logiidx_p,:));
%short_celldata_p=single(short_celldata_p);
for im=(im_stop):-1:(im_start+1)
  save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
  im_c=im;
  im_p=im-1;
  % init short_celldata_c
  short_celldata_c=zeros(Np,11,'single');
  idxlist_c=zeros(Np,1);
  % c = p from loop before
  short_celldata_c=short_celldata_p;
  idxlist_c=idxlist_p;
  Nc=Np;
  % select data prev
  logiidx_p=(celldata_FT(:,3)==im_p);
  Np=sum(logiidx_p(:));
  short_celldata_p=zeros(Np,11,'single');
  idxlist_p=zeros(Np,1);
  short_celldata_p=single(celldata_FT(logiidx_p,:));
  idxlist_p=idxs(logiidx_p,1);
  save(cat(2,save_path,'short_celldata_c.mat'),'short_celldata_c','-v7.3','-nocompression');
  save(cat(2,save_path,'short_celldata_p.mat'),'short_celldata_p','-v7.3','-nocompression');
  save(cat(2,save_path,'idxlist_c.mat'),'idxlist_c','-v7.3','-nocompression');
  save(cat(2,save_path,'idxlist_p.mat'),'idxlist_p','-v7.3','-nocompression');
  save(cat(2,save_path,'Nc.mat'),'Nc','-v7.3','-nocompression');
  save(cat(2,save_path,'Np.mat'),'Np','-v7.3','-nocompression');
end % for im
fprintf(' DONE ! \n')


% 
% *** do tracking feedback ***
% ****************************
fprintf('* do tracking : \n')
% *** create parallel computing
POOLOBJ=parpool('local',NBMAX-1,'IdleTimeout',240);

optim_reached=0;
parfor im=(im_start+1):im_stop
  [isoptim,~]=do_finish_tracking(ana_path,im);
  optim_reached=optim_reached+isoptim;
end % parfor im
fprintf('---> Optimum reached for %4f %% of image pairs\n',100*optim_reached/(im_stop-im_start));
delete(POOLOBJ);


% *** combine tracking data ****
% ******************************

fprintf('* combine tracking : \n')

% *** load data
fprintf('load data ...')
load(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC');
load(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC');
load(cat(2,ana_path,'combined_data/sorted_cellAP.mat'),'sorted_cellAP');
load(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF');
cellmaskLC_FT=sorted_cellmaskLC;
cellboundLC_FT=sorted_cellboundLC;
cellAP_FT=sorted_cellAP;
cellBF_FT=sorted_cellBF;
clear sorted_cellmaskLC;
clear sorted_cellboundLC;
clear sorted_cellAP;
clear sorted_cellBF;
fprintf(' DONE !')


fprintf('link images pairs ...')
% *** init last frame
im=im_stop;
save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
load(cat(2,save_path,'idxlist_c.mat'),'idxlist_c');
[Nc,~]=size(idxlist_c);
ID_list=[1:Nc]';
maxID=Nc;

[Ncell,~]=size(celldata_FT);

cellsID=zeros(Ncell,1);
cellsID(1:Nc,1)=ID_list;

cellidx=zeros(Ncell,1);
cellidx(1:Nc)=idxlist_c;

  % OUTPUTS
  nit_avg=0;
  optim_reached=0;

  cidx=Nc;

  for im=im_stop:-1:(im_start+1)

    save_path=cat(2,ROtrack_dir,num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
    load(cat(2,save_path,'idxlist_p.mat'),'idxlist_p');
    load(cat(2,save_path,'idxlist_c.mat'),'idxlist_c');

    [Nc,~]=size(idxlist_c);
    [Np,~]=size(idxlist_p);

    load(cat(2,save_path,'attrib.mat'),'attrib');

    next_ID_list=zeros(Np,1);

    % link to previous frame
    for np=1:Np
      cidx=cidx+1;
      cellidx(cidx,1)=idxlist_p(np,1);
      [L,~]=find(attrib(:,np)==single(1));
      if L==(Nc+1)
        maxID=maxID+1;
        cellsID(cidx,1)=maxID;
        next_ID_list(np,1)=maxID;
      else
        cellsID(cidx,1)=ID_list(L,1);
        next_ID_list(np,1)=ID_list(L,1);
      end % if
    end % for n2

    ID_list=next_ID_list;

  end % for im

sorted_celldata=cat(2,celldata_FT(cellidx,:),cellsID);
sorted_cellmaskLC=cellmaskLC_FT(cellidx,:);
sorted_cellboundLC=cellboundLC_FT(cellidx,:);
sorted_cellAP=cellAP_FT(cellidx,:);
sorted_cellBF=cellBF_FT(cellidx,:);

fprintf(' DONE !')


fprintf('* SAVE data ...')
save(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellAP.mat'),'sorted_cellAP','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellBF.mat'),'sorted_cellBF','-v7.3','-nocompression');
fprintf(' DONE !\n')

end % function
