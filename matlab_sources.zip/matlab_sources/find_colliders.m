function colliders=find_colliders(im,sorted_celldata)

colliders=[];

% search for cells found at frame im-1
logiidx=(sorted_celldata(:,3)==(im-1));
candidates=sorted_celldata(logiidx,:);

[Ncand,~]=size(candidates);
% look wether candidates are lost at frame im
for cc=1:Ncand
  id=candidates(cc,12);
  logiidx=( (sorted_celldata(:,12)==id)&(sorted_celldata(:,3)==im) );
  if sum(logiidx)==0
    colliders=cat(1,colliders,candidates(cc,:));
  end % if
end % for cc

end % function
