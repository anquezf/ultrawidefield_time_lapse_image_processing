function run_bypass_tracking_collision_feedback_V13(ana_path,deepTH_str,deepTH_2_str,AREArelinc_str,NloopFB_str,rscAREA_tol_str,RSCOVTH_str,Lmax2_str)

warning off

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if



% *** prepare dat
% ****************

fprintf('load and save params ...')

deepTH=str2double(deepTH_str);
deepTH_2=str2double(deepTH_2_str);
NloopFB=str2double(NloopFB_str);
AREArelinc=str2double(AREArelinc_str);
rscAREA_tol=str2double(rscAREA_tol_str);
RSCOVTH=str2double(RSCOVTH_str);
Lmax2=str2double(Lmax2_str);

save(cat(2,ana_path,'deepTH.mat'),'deepTH','-v7.3','-nocompression');
save(cat(2,ana_path,'deepTH_2.mat'),'deepTH_2','-v7.3','-nocompression');
save(cat(2,ana_path,'AREArelinc.mat'),'AREArelinc','-v7.3','-nocompression');
save(cat(2,ana_path,'NloopFB.mat'),'NloopFB','-v7.3','-nocompression');
save(cat(2,ana_path,'rscAREA_tol.mat'),'rscAREA_tol','-v7.3','-nocompression');
save(cat(2,ana_path,'RSCOVTH.mat'),'RSCOVTH','-v7.3','-nocompression');
save(cat(2,ana_path,'Lmax2.mat'),'Lmax2','-v7.3','-nocompression');
save(cat(2,ana_path,'tracking/','Lmax2.mat'),'Lmax2','-v7.3','-nocompression');

fprintf(' DONE !\n')

% *** load data
% ****************

fprintf('load data ...')

load(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC');
load(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC');

fprintf(' DONE !\n')

fprintf('*** BUILD cell Area and Perimeter data ...')

[Ncell,~]=size(sorted_cellmaskLC);
sorted_cellAP=zeros(Ncell,2);
for ce=1:Ncell
  MLC=sorted_cellmaskLC{ce,1};
  BLC=sorted_cellboundLC{ce,1};
  [AA,~]=size(MLC);
  [PP,~]=size(BLC);
  sorted_cellAP(ce,1)=AA;
  sorted_cellAP(ce,2)=PP;
end % for ce

fprintf(' DONE !\n')



% *** load data
% ****************

fprintf('*** SAVE data ...')

save(cat(2,ana_path,'combined_data/sorted_cellAP.mat'),'sorted_cellAP','-v7.3','-nocompression');

fprintf(' DONE !\n')

end % function
