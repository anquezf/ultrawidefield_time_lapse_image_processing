function time_s=get_time_s(fileList)

[Nfile,~]=size(fileList);


monthlist=zeros(Nfile,1);
% check if day change
for f=1:Nfile
  file=fileList{f,1};
  [~,stsi]=size(file);
  monthlist(f,1)=str2num(file(1,stsi-16:stsi-15));
end % for f


daylist=zeros(Nfile,1);
% check if day change
for f=1:Nfile
  file=fileList{f,1};
  [~,stsi]=size(file);
  daylist(f,1)=str2num(file(1,stsi-19:stsi-18));
end % for f

FileInfo = dir(fileList{1,1}');
[YYY, ~, ~, ~, ~, ~] = datevec(FileInfo.datenum);

yearlist=ones(Nfile,1)*YYY;

TT=datenum(cat(2,yearlist,monthlist,daylist));
TT=TT-min(TT(:));

time_s=zeros(Nfile,1);
for f=1:Nfile
  file=fileList{f,1};
  [~,stsi]=size(file);
  thetime=str2double(file(1,stsi-13:stsi-12))*3600+str2double(file(1,stsi-11:stsi-10))*60+str2double(file(1,stsi-9:stsi-8))+str2double(file(1,stsi-6:stsi-4))/1000;
  thetime=thetime+3600*24*TT(f,1);
  time_s(f,1)=thetime;
end % for f

end % function
