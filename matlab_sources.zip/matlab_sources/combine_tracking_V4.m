function combine_tracking_V4(ana_path)

warning off

% *** INPUTS

[~,Nchar]=size(ana_path);
if ~(strcmp(ana_path(1,Nchar),'/'))
ana_path=cat(2,ana_path,'/');
end % if

% analysis params
load(cat(2,ana_path,'Nim.mat'),'Nim');
load(cat(2,ana_path,'im_start.mat'),'im_start');
load(cat(2,ana_path,'im_stop.mat'),'im_stop');

% tracking params
save_path=cat(2,ana_path,'tracking/');
load(cat(2,save_path,'Nitemax.mat'),'Nitemax');

% load celldata
load(cat(2,ana_path,'combined_data/celldata_clean.mat'),'celldata_clean');

if im_stop>im_start

  % *** init last frame
  im=im_stop;
  save_path=cat(2,ana_path,'tracking/',num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
  load(cat(2,save_path,'idxlist_c.mat'),'idxlist_c');

  [Nc,~]=size(idxlist_c);
  ID_list=[1:Nc]';
  maxID=Nc;

  [Ncell,~]=size(celldata_clean);
  cellsID=zeros(Ncell,1);
  cellsID(1:Nc,1)=ID_list;
  cellidx=zeros(Ncell,1);
  cellidx(1:Nc,1)=idxlist_c;

  % OUTPUTS
  nit_avg=0;
  optim_reached=0;

  cidx=Nc;
  fprintf('combine tracking for image %5d to %5d',0,0);
  for im=im_stop:-1:(im_start+1)

    % *** display status...
    for id=1:14
    fprintf('\b');
    end % for id
    fprintf('%5d to %5d',im,im-1);
  
    save_path=cat(2,ana_path,'tracking/',num2str(im,'%0.5d'),'_',num2str(im-1,'%0.5d'),'/');
    load(cat(2,save_path,'idxlist_p.mat'),'idxlist_p');
    load(cat(2,save_path,'idxlist_c.mat'),'idxlist_c');

    [Nc,~]=size(idxlist_c);
    [Np,~]=size(idxlist_p);

    load(cat(2,save_path,'attrib.mat'),'attrib');

    next_ID_list=zeros(Np,1);

    % link to previous frame
    for np=1:Np

      cidx=cidx+1;
      cellidx(cidx,1)=idxlist_p(np,1);

      [L,~]=find(attrib(:,np)==single(1));

      if L==(Nc+1)
        maxID=maxID+1;
        cellsID(cidx,1)=maxID;
        next_ID_list(np,1)=maxID;
      else
        cellsID(cidx,1)=ID_list(L,1);
        next_ID_list(np,1)=ID_list(L,1);
      end % if

    end % for n2

    ID_list=next_ID_list;

  end % for im
  fprintf('\n')

else

  [Ncell,~]=size(celldata_clean);
  ID_list=[1:Ncell]';
  cellsID=[1:Ncell]';
  cellidx=[1:Ncell]';

end % if im_stop>im_start

% *** SAVE

% tracking params
save_path=cat(2,ana_path,'tracking/');
load(cat(2,save_path,'Nitemax.mat'),'Nitemax');

fprintf('load data...\n')
% load celldata
  load(cat(2,ana_path,'combined_data/cellmaskLC_clean.mat'),'cellmaskLC_clean');
  load(cat(2,ana_path,'combined_data/cellboundLC_clean.mat'),'cellboundLC_clean');

sorted_celldata=cat(2,celldata_clean(cellidx,:),cellsID);
sorted_cellmaskLC=cellmaskLC_clean(cellidx,:);
sorted_cellboundLC=cellboundLC_clean(cellidx,:);

fprintf('save data...\n')
save(cat(2,ana_path,'combined_data/sorted_celldata.mat'),'sorted_celldata','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellmaskLC.mat'),'sorted_cellmaskLC','-v7.3','-nocompression');
save(cat(2,ana_path,'combined_data/sorted_cellboundLC.mat'),'sorted_cellboundLC','-v7.3','-nocompression');


fprintf('DONE!\n')

end % function

