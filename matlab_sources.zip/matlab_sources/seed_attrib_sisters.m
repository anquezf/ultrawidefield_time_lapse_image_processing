function attrib=seed_attrib_sisters(cost,Lmax,Nss)

% Lmax typical maximum displacement between to frames
Lmax_sq=power(Lmax,2);

% last column and last line are dummy particles
[N1,N2]=size(cost);
N1=N1-1;
N2=N2-1;

% *** attrib
attrib=zeros(N1+1,N2+1,'single');
catched=zeros(N2,1,'logical');

% ***sequentially attribute the closest
% start with single_sisters
for n1=1:Nss

  the_n2=0;

  n2=[1:N2];
  [dsqmini,ii2]=min(cost(n1,n2));
  if (dsqmini<Lmax_sq)&&(~(catched(ii2,1)))
    the_n2=ii2;
    attrib(n1,the_n2)=1;
    catched(the_n2,1)=true;
  end % if

  % if still not assigned -> assign to dummy
  if the_n2==0
    attrib(n1,N2+1)=1;
  end % if % the_n2==0

end % for n1

% attribute mother_sisters
for n1=(Nss+1):N1

  the_n2=0;

  n2=[1:N2];
  [dsqmini,ii2]=min(cost(n1,n2));
  if (dsqmini<Lmax_sq)&&(~(catched(ii2,1)))&&(ii2<(Nss+1))
    the_n2=ii2;
    attrib(n1,the_n2)=1;
    catched(the_n2,1)=true;
  end % if

  % if still not assigned -> assign to dummy
  if the_n2==0
    attrib(n1,N2+1)=1;
  end % if % the_n2==0

end % for n1


% *** check non attrib
for n1=1:N1
  [~,K]=find(attrib(n1,:)==1);
  if isempty(K)
    attrib(n1,N2+1)=1;
  end % if
end % for n1
for n2=1:N2
  [L,~]=find(attrib(:,n2)==1);
  if isempty(L)
    attrib(N1+1,n2)=1;
  end % if
end % for n
%attrib

end % function

