function pre_proc_HISTO_V8(ana_dir,pos)

warning off

[~,Nchar]=size(ana_dir);
if ~(strcmp(ana_dir(1,Nchar),'/'))
ana_dir=cat(2,ana_dir,'/');
end % if

pos_ana_dir=cat(2,ana_dir,'DATA/',num2str(pos-1,'%0.5d'),'/');

% ***************************
% *** GET intensity histogram
% ***************************

load(cat(2,ana_dir,'FF_NUC.mat'),'FF');
load(cat(2,ana_dir,'imoffset.mat'),'imoffset');
load(cat(2,ana_dir,'Nim.mat'),'Nim');
load(cat(2,ana_dir,'im_start.mat'),'im_start');
load(cat(2,ana_dir,'im_stop.mat'),'im_stop');
load(cat(2,ana_dir,'NL.mat'),'NL');
load(cat(2,ana_dir,'NC.mat'),'NC');

load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');
load(cat(2,pos_ana_dir,'fileListN.mat'),'fileListN');

load(cat(2,ana_dir,'iedges.mat'),'iedges');
[Npts,~]=size(iedges);

% some variables
n=zeros(Npts,1);
theimageN=zeros(NL,NC);
A0=0;


% OUTPUTS

histo=zeros(Npts,Nim);

% get data for all images

for im=im_start:im_stop

  % *** find idx
  idx=imidx_2_lidx(im,1);

  % load image
  theimageN=double(imread(fileListN{idx,1}));
  theimageN=(theimageN-imoffset)./FF;
  % build histo
  n=(histc(theimageN(:),iedges));
  histo(:,im)=n;

end % for im

save(cat(2,pos_ana_dir,'iedges.mat'),'iedges','-v7.3','-nocompression');
save(cat(2,pos_ana_dir,'histo.mat'),'histo','-v7.3','-nocompression');

end % functiyon
