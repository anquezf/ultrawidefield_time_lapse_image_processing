function preproc_corrected_HISTO_V9(ana_dir,pos)

warning off

[~,Nchar]=size(ana_dir);
if ~(strcmp(ana_dir(1,Nchar),'/'))
ana_dir=cat(2,ana_dir,'/');
end % if

pos_ana_dir=cat(2,ana_dir,'DATA/',num2str(pos-1,'%0.5d'),'/');

% ***************************
% *** GET intensity histogram
% ***************************

load(cat(2,ana_dir,'useFFforeg.mat'),'useFFforeg');

load(cat(2,ana_dir,'FF_foreg.mat'),'FF_foreg');
load(cat(2,ana_dir,'FF_bkg.mat'),'FF_bkg');

load(cat(2,ana_dir,'b0.mat'),'b0');
load(cat(2,ana_dir,'delta_b_vsim.mat'),'delta_b_vsim');

load(cat(2,ana_dir,'imoffset.mat'),'imoffset');
load(cat(2,ana_dir,'Nim.mat'),'Nim');
load(cat(2,ana_dir,'im_start.mat'),'im_start');
load(cat(2,ana_dir,'im_stop.mat'),'im_stop');

load(cat(2,ana_dir,'NL.mat'),'NL');
load(cat(2,ana_dir,'NC.mat'),'NC');


load(cat(2,pos_ana_dir,'imidx_2_lidx.mat'),'imidx_2_lidx');
load(cat(2,pos_ana_dir,'fileListN.mat'),'fileListN');

load(cat(2,ana_dir,'iedges.mat'),'iedges');
[Npts,~]=size(iedges);

% some variables
n=zeros(Npts,1);
theimageN=zeros(NL,NC);



% OUTPUTS

histo_cor=zeros(Npts,Nim);
for im=im_start:im_stop

  % *** find idx
  idx=imidx_2_lidx(im,1);

  % load image
  theimageN=double(imread(fileListN{idx,1}));
  theimageN=(theimageN-imoffset);

  theimageN=theimageN-(b0+delta_b_vsim(1,im))*FF_bkg;

  if useFFforeg==1
    theimageN=theimageN./FF_foreg;
  end % if

  % build histo
  n=(histc(theimageN(:),iedges));
  histo_cor(:,im)=n;

end % for im

save(cat(2,pos_ana_dir,'histo_cor.mat'),'histo_cor','-v7.3','-nocompression');


end % functiyon
