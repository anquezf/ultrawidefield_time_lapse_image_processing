#!/bin/bash
chanF=$1
quantileFF_low=$2
quantileFF_high=$3

echo ''
echo ''
echo ''

echo "Fluorescence Chanel : "$chanF


. PG_config.bash


echo '*** ***************** ***'
echo '*** RUN FLuo ANALYSIS ***'
echo '*** ***************** ***'
echo ''

$PROGLOC$EXERUN"run_init_multiple_bypass_FLUO_V3" $DIRANA $chanF $NBmax

$PROGLOC$EXERUN"run_avgBKGFOREG_multiple_FLUO_V3" $chanF $NBmax

$PROGLOC$EXERUN"run_FFbkg_multiple_FLUO_bypass_V3" $chanF

$PROGLOC$EXERUN"run_NUCsignal_multiple_FLUO_V3" $chanF $NBmax
