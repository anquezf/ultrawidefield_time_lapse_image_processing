#!/bin/bash

echo 'Be carreful to source this script (use . SET_params.bash instead of ./SET_params.bash)'
echo ''




# ************
# *** INTI ANA

export pixsize='0.4333333'



# ****************************
# *** multiple FNUC processing

export fWFF='6.5' # in um
export pad_dpix='50'
export FFmini='0.005'

export deltai='1'
export imini='-7000'
export imaxi='70000'

export fW1='3' # in um
export fW2='22' # in um
export Nsig='3'


# ****************************
# *** multiple cell SEG params

export fWmf='1.5' # in um
export scale='0.5'
export Nite='100'
export deepTH_SPLIT='0.2'
export Nloop='4'

export IBS='25'
export ABS='10'
# Good values for IBS and ABS
# IBS='25'
# ABS='10'


# ********************
# *** GUI select TP/FP

export Nbunch='10'



# *********************************
# *** tracking, tracking FB, params

export deltaXpos='-10' # in um
export deltaYpos='-10' # in um

export Dborder='20' # in um
export SOVTH='0.01'

export Nsplit='10'
export useWB='1'
export useWS='1'
export Lmax='30'
export WBSweight='0.12'
export Nitemax='10000'

export imaxi_bf='70000'
export imini_bf='-7000'
export deltai_bf='1'

export Nsig_BF='6'

export dpix_tol='2'
# Good values mitoCONTRAST_TH1
# use 0.05 prior to march 9th 2022
# use 0.185 after march 9th 2022
export mitoCONTRAST_TH1='0.185'
export deepTH_repairSPLIT='0.2'

export Lmax2='60'

export deepTH='0.075'
export deepTH_2='0.2'
export AREArelinc='0.5'
export NloopFB='6'
export rscAREA_tol='0.3'
export RSCOVTH='0'

export mem='4'

export mito_miniD='10'

export disp_mem='6'
