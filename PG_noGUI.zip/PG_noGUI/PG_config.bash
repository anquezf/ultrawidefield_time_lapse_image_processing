#!/bin/bash

SOFTVERSION="V14"

# define some variables that will be usefull
# for fdysco
#PROGLOC="/home/anquez/CSCproject_soft/CSCsoft"$SOFTVERSION"/"
#EXERUN="PG_noGUI/compiled/./"
# for the NAS
PROGLOC="/usr/local/bin/CSCsoft"$SOFTVERSION"/"
EXERUN="PG_noGUI/compiled/./"


# define LD_LIBRARY_PATH for matla compiled files
MCRpath="/usr/local/MATLAB/MATLAB_Runtime/v96/"
LDLPATH1=$MCRpath"runtime/glnxa64"
LDLPATH2=$MCRpath"bin/glnxa64"
LDLPATH3=$MCRpath"sys/os/glnxa64"
LDLPATH4=$MCRpath"sys/opengl/lib/glnxa64"
LD_LIBRARY_PATH="${LDLPATH1}:${LDLPATH2}:${LDLPATH3}:${LDLPATH4}"

# export these
export PROGLOC
export EXERUN

export LD_LIBRARY_PATH


# for fdysco
#export DIRANA="/DATA2/"
#export DIRDATA="/DATA1/DATA_CSC/"
# for NAS
export DIRANA="/ANALYSIS/"
export DIRDATA="/REDOX/"


# data for prallel computing
NBproc=$(grep -c ^processor /proc/cpuinfo)

# for fdysco
#NBmax=$(($NBproc/2))
#NBmax2=$(($NBproc/4))
# for NAS
NBmax=$(($NBproc))
NBmax2=$(($NBproc/2))

echo 'CSCTLsoft version 1.'$SOFTVERSION
echo ''

echo 'found '$NBproc' cores'
echo ' will launch maximum '$NBmax' or '$NBmax2' processes at once'
echo ''
export NBmax
export NBmax2

echo ''
echo ''
echo ''

