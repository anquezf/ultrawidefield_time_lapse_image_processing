#!/bin/bash

. PG_config.bash


echo ''
echo ''
echo ' ***********************************'
echo ' *** run MULTIPLE pre-processing ***'
echo ' ***********************************'
echo ''


$PROGLOC$EXERUN"run_init_multiple_preprocessing_bypass_V5" $DIRANA $pad_dpix $fWFF $FFmini $deltai $imini $imaxi $fW1 $fW2 $Nsig $NBmax

$PROGLOC$EXERUN"run_avgBKGFOREG_multiple_preprocessing_V5" $NBmax

$PROGLOC$EXERUN"run_FFbkg_multiple_preprocessing_bypass_V5"

$PROGLOC$EXERUN"run_FFforeg_multiple_preprocessing_bypass_V5"

echo ''
echo ''
echo ''
