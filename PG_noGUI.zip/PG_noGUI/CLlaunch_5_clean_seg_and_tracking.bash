#!/bin/bash
ana_dir=$1
echo $ana_dir

echo ''
echo ''
echo ''

. PG_config.bash

echo ''
echo ''
echo ''




echo '*** ************** ***'
echo '*** CLEAN ANALYSIS ***'
echo '*** ************** ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- clean Analysis : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "clean_SEG_ANALYSIS_V5 : "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"clean_SEG_ANALYSIS_V5" $ana_dir | tee $ana_dir"/LOGS/clean_SEG_ANALYSIS_V5.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- clean Analysis : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"

echo ''
echo ''
echo ''


