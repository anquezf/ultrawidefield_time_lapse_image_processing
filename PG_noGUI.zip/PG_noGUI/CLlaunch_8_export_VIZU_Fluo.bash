#!/bin/bash
ana_dir=$1
chanF=$2
Imini=$3
Imaxi=$4
useFF=$5
useDNS=$6

echo ''
echo ''
echo ''

echo $ana_dir
echo "data : "$chanF
echo "Intensity Min : "$Imini
echo "Intensity Max : "$Imaxi
echo "use FlatField : "$useFF
echo "use Denoising : "$useDNS


echo ''
echo ''
echo ''

. PG_config.bash

echo ''
echo ''
echo ''




echo '*** ************** ***'
echo '*** EXPORT TL VIZU ***'
echo '*** ************** ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- export VIZU FluoChan V6 ("$chanF";"$Imini";"$Imaxi";"$useFF";"$useDNS") : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_VIZU_export_Fluo_V6 : "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"run_VIZU_export_FluoChan_V6" $ana_dir $chanF $Imini $Imaxi $useFF $useDNS $NBmax | tee $ana_dir"/LOGS/export_"$chanF"_VIZU_V6.log"


TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- export VIZU FluoChan V6 : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"

echo ''
echo ''
echo ''


