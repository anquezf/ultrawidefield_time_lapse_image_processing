#!/bin/bash
ana_dir=$1
Imaxi_nuc=$2

echo ''
echo ''
echo ''

echo $ana_dir
echo "Nuc Intensity Max : "$Imaxi

echo ''
echo ''
echo ''

. PG_config.bash

echo ''
echo ''
echo ''




echo '*** ************** ***'
echo '*** EXPORT TL VIZU ***'
echo '*** ************** ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- export VIZU V6 : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_VIZU_init_export_seg_and_tracking_V6 : "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"run_VIZU_init_export_seg_and_tracking_V6" $ana_dir $NBmax | tee $ana_dir"/LOGS/export_VIZU_V6.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_VIZU_export_FluoNuc_V6 : "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"run_VIZU_export_FluoNuc_V6" $ana_dir $NBmax $Imaxi_nuc | tee $ana_dir"/LOGS/export_VIZU_V6.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_VIZU_export_BF_V6 : "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"run_VIZU_export_BF_V6" $ana_dir $NBmax | tee $ana_dir"/LOGS/export_VIZU_V6.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- export VIZU V6 : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"

echo ''
echo ''
echo ''


