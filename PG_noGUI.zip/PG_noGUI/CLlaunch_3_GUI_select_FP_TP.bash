#!/bin/bash
ana_dir=$1
loadPINI=$2
echo $ana_dir
echo $loadPINI

echo ''
echo ''
echo ''

. PG_config.bash


echo '*** *************************** ***'
echo '*** SELECT FALSE/TRUE POSITIVES ***'
echo '*** *************************** ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- selecting FP and TP : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

echo "select_FP_TP_V5(Nbunch="$Nbunch") : "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"run_select_FP_TP_V5" $ana_dir $Nbunch $loadPINI $DIRANA | tee $ana_dir"/LOGS/run_select_FP_TP_V5.log"

echo ''
echo ''
echo ''

