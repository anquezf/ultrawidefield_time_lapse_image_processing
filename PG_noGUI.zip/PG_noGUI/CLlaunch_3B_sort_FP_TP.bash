#!/bin/bash
ana_dir=$1

echo ''
echo ''
echo ''
echo $ana_dir


. PG_config.bash



echo '*** ************* ***'
echo '*** SORTING TP/FP ***'
echo '*** ************* ***'
echo ''

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_sort_FP_TP_V4 : "$TT >> $ana_dir"/what_was_done.log"
# RUN 
$PROGLOC$EXERUN"run_sort_FP_TP_V4" $ana_dir | tee $ana_dir"/LOGS/run_sort_FP_TP_V4.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- selecting FP and TP : ""->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"





