#!/bin/bash
useFFforeg=$1
RESETanapath=$2

echo 'use foreground FlatField :'$useFFforeg
echo 're-set analysis paths : '$RESETanapath


. PG_config.bash






echo ''
echo ''
echo ' ***********************************'
echo ' *** run MULTIPLE pre-processing ***'
echo ' ***********************************'
echo ''


nohup $PROGLOC$EXERUN"run_histo_multiple_preprocessing_V5" $useFFforeg $RESETanapath $DIRANA $NBmax

nohup $PROGLOC$EXERUN"run_multiple_cellSEG_V4" $DIRANA $fWmf $scale $Nite $deepTH_SPLIT $Nloop $IBS $ABS $NBmax

echo ''
echo ''
echo ''
