#!/bin/bash
ana_dir=$1


echo ''
echo ''
echo ''

. PG_config.bash

echo ''
echo ''
echo ''




echo '*** ************** ***'
echo '*** CLEAN FLUO ANA ***'
echo '*** ************** ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- clean FLUO ANA : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "clean_FLUO_ANALYSIS : "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"clean_FLUO_ANALYSIS" $ana_dir | tee $ana_dir"/LOGS/clean_FLUO_ANALYSIS.log"


TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- clean FLUO ANA : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"

echo ''
echo ''
echo ''


