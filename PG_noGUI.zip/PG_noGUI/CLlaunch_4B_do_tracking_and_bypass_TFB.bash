#!/bin/bash
ana_dir=$1
chanBF=$2

echo ''
echo ''
echo ''
echo $ana_dir
echo "BrightField Chanel : "$chanBF

. PG_config.bash



echo '*** ************* ***'
echo '*** SORTING TP/FP ***'
echo '*** ************* ***'
echo ''

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_sort_FP_TP_V4 : "$TT >> $ana_dir"/what_was_done.log"
# RUN 
$PROGLOC$EXERUN"run_sort_FP_TP_V4" $ana_dir | tee $ana_dir"/LOGS/run_sort_FP_TP_V4.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- selecting FP and TP : ""->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"





echo ''
echo ''
echo ''


echo '*** ***************** ***'
echo '*** REMOVE DUPLICATES ***'
echo '*** ***************** ***'
echo ''


TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- remove duplicates : "$TSTART" --- " >> $ana_dir"/what_was_done.log"


echo " init_remove_duplicate_V3( deltaXpos = "$deltaXpos"; deltaYpos = "$deltaYpos") : "$TT" --- " >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"init_remove_duplicate_V3" $ana_dir $deltaXpos $deltaYpos | tee $ana_dir"/LOGS/init_remove_duplicate_V3.log"

# RUN combine HISTO
TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_duplicate_removal_V6 ( Dborder = "$Dborder"; Lmax = "$Lmax"; SOVTH = "$SOVTH"; NBmax = "$NBmax"): "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"run_duplicate_removal_V6" $ana_dir $Dborder $Lmax $SOVTH $NBmax | tee $ana_dir"/LOGS/run_duplicate_removal_V6.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "combine_duplicates_removal_V3 : "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"combine_duplicates_removal_V3" $ana_dir | tee $ana_dir"/LOGS/combine_duplicates_removal_V3.log"

echo ''

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- remove duplicates : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"



echo ''
echo ''
echo ''


echo '*** ******** ***'
echo '*** TRACKING ***'
echo '*** ******** ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- tracking : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "init_tracking_V4 ( Nplit = "$Nsplit"; useWB = "$useWB"; useWS = "$useWS"; Lmax = "$Lmax"; WBEweight = "$WBSweight"; Nitemax = "$Nitemax"): "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"init_tracking_V4" $ana_dir $Nsplit $useWB $useWS $Lmax $WBSweight $Nitemax | tee $ana_dir"/LOGS/init_tracking_V4.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_do_tracking_V4 : "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"run_do_tracking_V4" $ana_dir $NBmax2 | tee $ana_dir"/LOGS/run_do_tracking_V4.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "combine_tracking_V4 : "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"combine_tracking_V4" $ana_dir | tee $ana_dir"/LOGS/combine_tracking_V4.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- tracking : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"



echo ''
echo ''
echo ''


echo '*** *********** ***'
echo '*** BRIGHTFIELD ***'
echo '*** *********** ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- brightfield processing : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_estimate_BFbkg_V2 ( BF chanel : "$chanBF"): "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"run_estimate_BFbkg_V2" $ana_dir $chanBF $NBmax | tee $ana_dir"/LOGS/run_estimate_BFbkg_V2.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_preproc_BFhisto ( imaxi_bf = "$imaxi_bf"; imini_bd = "$imini_bf"; deltai_bf = "$deltai_bf"): "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"run_preproc_BFhisto" $ana_dir $imaxi_bf $imini_bf $deltai_bf $NBmax | tee $ana_dir"/LOGS/run_preproc_BFhisto.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_process_BF_V4 ( Nsig_BF = "$Nsig_BF") : "$TT >> $ana_dir"/what_was_done.log"
$PROGLOC$EXERUN"run_process_BF_V4" $ana_dir $Nsig_BF $NBmax | tee $ana_dir"/LOGS/run_process_BF_V4.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "combine_BFprocessing_V4 : "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"combine_BFprocessing_V4" $ana_dir | tee $ana_dir"/LOGS/combine_BFprocessing_V4.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- brightfield processing : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"



echo ''
echo ''
echo ''


echo '*** ***************** ***'
echo '*** REPAIR OVERSPLITS ***'
echo '*** ***************** ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- repair oversplitting : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_repair_oversplit_V5 ( dpix_tol = "$dpix_tol"; mitoCONTAST_TH1 = "$mitoCONTRAST_TH1"; deepTH_repair_SPLIT = "$deepTH_repairSPLIT"): "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"run_repair_oversplit_V5" $ana_dir $dpix_tol $mitoCONTRAST_TH1 $deepTH_repairSPLIT $NBmax | tee $ana_dir"/LOGS/run_repair_oversplit_V4.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- repair oversplitting  : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"




echo ''
echo ''
echo ''


echo '*** ************************ ***'
echo '*** BYPASS TRACKING FEEDBACK ***'
echo '*** ************************ ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- BYPASS collision-tracking feedback : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_bypass_tracking_collision_feedback_V13 ( deepTH = "$deepTH"; deepTH_2 = "$deepTH_2"; AREArelinc = "$AREArelinc"; NloopFB = "$NloopFB"; rscAREA_tol = "$rscAREA_tol"; RSCOVTH = "$RSCOVTH"; Lmax2 = "$Lmax2"): "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"run_bypass_tracking_collision_feedback_V13" $ana_dir $deepTH $deepTH_2 $AREArelinc $NloopFB $rscAREA_tol $RSCOVTH $Lmax2 | tee $ana_dir"/LOGS/run_bypass_tracking_collision_feedback_V12.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- BYPASS collision-tracking feedback : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"




echo '*** ******************** ***'
echo '*** CONNECT TRAJECTORIES ***'
echo '*** ******************** ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- connect trajectories : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_connect_traj_V4 ( mem = "$mem") : "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"run_connect_traj_V4" $ana_dir $mem $NBmax | tee $ana_dir"/LOGS/connect_traj_V4.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- connect trajectories : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"

echo ''
echo ''
echo ''



echo '*** ************ ***'
echo '*** CELL LINEAGE ***'
echo '*** ************ ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- cell lineage : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "run_detect_mitosis_V4 ( mito_miniD = "$mito_miniD") : "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"run_detect_mitosis_V4" $ana_dir $mito_miniD | tee $ana_dir"/LOGS/detect_mitosis_V4.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- cell lineage : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"

echo ''
echo ''
echo ''



echo '*** ************** ***'
echo '*** INTIALIZE FLUO ***'
echo '*** ************** ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- initialize all FLUO Analysis : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "init_all_FLUO_V3 : "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"init_all_FLUO_V3" $ana_dir $NBmax | tee $ana_dir"/LOGS/init_all_FLUO_V3.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- initialize all FLUO Analysis : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"







#echo ''
#echo ''
echo ''



