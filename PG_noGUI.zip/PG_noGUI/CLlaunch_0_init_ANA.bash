#!/bin/bash

motif=$1
flipUD=$2
flipLR=$3
swapXY=$4
chanFluoH=$5
im_start=$6
im_stop=$7

echo ''
echo ''
echo ' **************************'
echo ' *** INTIALIZE ANALYSIS ***'
echo ' **************************'
echo ''

echo 'motif :'$motif
echo 'flipUD : '$flipUD' flipLR : '$flipLR' swapXY : '$swapXY
echo 'fluo. chanel for nuclear stainning : '$chanFluoH
echo 'im start : '$im_start' im stop : '$im_stop

echo 'directory of DATA :'$DIRDATA
echo 'directory of ANALYSIS :'$DIRANA

echo ''
echo ''
echo ''

. PG_config.bash

# "flip Up-Down : flipUD use 0 before january 20th 2020 and use 1 after january 20th 2020
# "flip Left-Right : flipLR use 1 before january 20th 2020 and use 0 after january 20th 2020

$PROGLOC$EXERUN"init_ANA_V8" $SOFTVERSION $DIRANA $motif $DIRDATA $chanFluoH $pixsize $flipUD $flipLR $swapXY $im_start $im_stop

echo 'intialization DONE !'
echo ''
echo ''
echo ''

