#!/bin/bash
ana_dir=$1
new_mitoCONTRAST_TH=$2

echo ''
echo ''
echo ''
echo $ana_dir
echo $new_mitoCONTRAST_TH

. PG_config.bash






echo '*** ******************* ***'
echo '*** RE-RUN CELL LINEAGE ***'
echo '*** ******************* ***'
echo ''

TSTART=$(date +%Y/%m/%d-%H:%M:%S);
echo '' >> $ana_dir"/what_was_done.log"
echo " START ------------- re-run cell lineage : "$TSTART" --- " >> $ana_dir"/what_was_done.log"

TT=$(date +%Y/%m/%d-%H:%M:%S);
echo "re_run_detect_mitosis ( mito_miniD = "$new_mitoCONTRAST_TH","$Lmax2","$Nitemax") : "$TT >> $ana_dir"/what_was_done.log"
# RUN pre_proc cell FEAT (segmentation)
$PROGLOC$EXERUN"re_run_detect_mitosis" $ana_dir $new_mitoCONTRAST_TH $Lmax2 $Nitemax | tee $ana_dir"/LOGS/re_run_detect_mitosis.log"

TSTOP=$(date +%Y/%m/%d-%H:%M:%S);
echo " END   ------------- re-run cell lineage : "$TSTART"->"$TSTOP" --- " >> $ana_dir"/what_was_done.log"
echo '' >> $ana_dir"/what_was_done.log"

echo ''
echo ''
echo ''



#echo ''
#echo ''
echo ''



